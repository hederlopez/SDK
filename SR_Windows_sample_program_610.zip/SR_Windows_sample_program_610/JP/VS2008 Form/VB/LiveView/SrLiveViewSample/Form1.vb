﻿Imports System.Collections.Generic
Imports System.Windows.Forms
Imports Keyence.AutoID

Public Class Form1

    Private ReadOnly readerTable As New Dictionary(Of String, ReaderType)()

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        readerTable.Add("SR-D100", ReaderType.SR_D100)
        readerTable.Add("SR-750", ReaderType.SR_750)
        readerTable.Add("SR-700", ReaderType.SR_700)
        readerTable.Add("SR-1000", ReaderType.SR_1000)
        readerTable.Add("SR-2000", ReaderType.SR_2000)

        ComboBoxReader.Items.Clear()
        For Each reader As KeyValuePair(Of String, ReaderType) In readerTable
            ComboBoxReader.Items.Add(reader.Key)
        Next
        ComboBoxReader.SelectedIndex = readerTable.Count - 1
        '
        ' 接続リーダのインタフェースを指定します
        '
        barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.Ethernet
        '
        ' 接続リーダのIPアドレスを指定します
        '
        barcodeReaderControl1.IpAddress = "192.168.100.100"
        '
        ' 接続リーダのポート番号を指定します
        ' コマンドポートとデータポートは異なる値を設定して下さい
        '
        barcodeReaderControl1.Ether.CommandPort = 9003
        barcodeReaderControl1.Ether.DataPort = 9004
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        Try
            '
            ' リーダに接続します
            '
            barcodeReaderControl1.Connect()
            textBox1.Text = "Connected successfulllly"
            If barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.USB Then
                '
                ' データポートを占有するためにSKCLOSEを送信する
                '
                barcodeReaderControl1.SKCLOSE()
            Else
                '
                ' コマンドのレスポンスを有りに設定しているか確認する
                '
                Dim val As String = barcodeReaderControl1.RP("610")
                Select Case barcodeReaderControl1.ReaderType
                    Case Keyence.AutoID.ReaderType.SR_2000
                        If val.Equals("1") = False Then
                            textBox1.Text = "基本コマンドのレスポンス文字列を詳細返信に設定して下さい。"
                        End If
                    Case Keyence.AutoID.ReaderType.SR_1000
                        If val.Equals("1") = False Then
                            textBox1.Text = "基本コマンドのレスポンス文字列を詳細返信に設定して下さい。"
                        End If
                    Case Keyence.AutoID.ReaderType.SR_700
                        If val.Equals("1") = False Then
                            textBox1.Text = "基本コマンドのレスポンス文字列を詳細返信に設定して下さい。"
                        End If
                    Case Keyence.AutoID.ReaderType.SR_750
                        If val.Equals("0") = False Then
                            textBox1.Text = "レスポンス文字列の指定を無効に設定して下さい。"
                        End If
                    Case Keyence.AutoID.ReaderType.SR_D100
                        If val.Equals("0") = False Then
                            textBox1.Text = "レスポンス文字列の指定を無効に設定して下さい。"
                        End If
                End Select
            End If
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        textBox1.Text = ""
        Try
            '
            ' LONコマンドを送信します
            '
            barcodeReaderControl1.LON()
        Catch cex As Keyence.AutoID.CommandException
            '
            ' コマンドエラー番号は、ExtErrCodeにセットされます
            '
            textBox1.Text = "Command err," & cex.ExtErrCode
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        textBox1.Text = ""
        Try
            '
            ' LOFFコマンドを送信します
            '
            barcodeReaderControl1.LOFF()
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button6.Click
        '
        ' ライブビューを開始します
        '
        Try
            '
            ' ライブビューを開始します
            '
            barcodeReaderControl1.StartLiveView()
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub OnDataReceived(ByVal sender As System.Object, ByVal e As Keyence.AutoID.OnDataReceivedEventArgs) Handles barcodeReaderControl1.OnDataReceived
        '
        ' 受信データの表示処理をTextBoxにデリゲートします
        '
        textBox2.Invoke(New updateTextBoxDelegate(AddressOf updateTextBox), e.data)
    End Sub

    Private Delegate Sub updateTextBoxDelegate(ByVal data As Byte())

    Private Sub updateTextBox(ByVal data As Byte())
        '
        ' 受信データをSHIFT_JISに変換してTextBoxに表示します
        '
        textBox2.Text = System.Text.Encoding.GetEncoding("Shift_JIS").GetString(data)

        '
        ' 画像ファイル保存処理
        '
        Dim saveImage As Boolean
        If textBox2.Text.StartsWith("ERROR") Then
            saveImage = radioButtonImageErrSave.Checked
        Else
            saveImage = radioButtonImageOkSave.Checked
        End If
        If (saveImage) Then
            Try
                '
                ' 保存ファイルのパス取得
                '
                Dim srcFile As String = barcodeReaderControl1.LSIMG()
                Dim dstFile As String = srcFile.Split("\")(2)
                '
                ' 画像ファイル取得
                '
                barcodeReaderControl1.GetFile(srcFile, dstFile)
                MessageBox.Show(dstFile, "画像ファイル取得")
            Catch ex As Exception
                textBox1.Text = ex.Message
            End Try
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        If (RadioButton4.Checked) Then
            barcodeReaderControl1.StopLiveView()
            barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.Ethernet
        End If
    End Sub

    Private Sub RadioButton5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton5.CheckedChanged
        If (RadioButton5.Checked) Then
            barcodeReaderControl1.StopLiveView()
            barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.USB
        End If
    End Sub


    Private Sub ComboBoxReader_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxReader.SelectedIndexChanged
        barcodeReaderControl1.StopLiveView()

        Dim readerType As ReaderType
        readerType = readerTable(ComboBoxReader.Text)

        '
        ' 接続リーダ種別を指定します
        '
        barcodeReaderControl1.ReaderType = readerType

        groupBox3.Enabled = ((readerType <> readerType.SR_D100) And (readerType <> readerType.SR_750))

    End Sub
End Class
