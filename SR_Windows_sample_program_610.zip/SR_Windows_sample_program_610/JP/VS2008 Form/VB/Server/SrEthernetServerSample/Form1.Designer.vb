﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.receive = New System.Windows.Forms.Button
        Me.disconnect = New System.Windows.Forms.Button
        Me.connect = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'receive
        '
        Me.receive.Location = New System.Drawing.Point(10, 57)
        Me.receive.Name = "receive"
        Me.receive.Size = New System.Drawing.Size(260, 42)
        Me.receive.TabIndex = 11
        Me.receive.Text = "データ受信"
        Me.receive.UseVisualStyleBackColor = True
        '
        'disconnect
        '
        Me.disconnect.Location = New System.Drawing.Point(276, 9)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(260, 42)
        Me.disconnect.TabIndex = 10
        Me.disconnect.Text = "待ち受け終了"
        Me.disconnect.UseVisualStyleBackColor = True
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(10, 9)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(260, 42)
        Me.connect.TabIndex = 9
        Me.connect.Text = "待ち受け開始"
        Me.connect.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(547, 109)
        Me.Controls.Add(Me.receive)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents receive As System.Windows.Forms.Button
    Private WithEvents disconnect As System.Windows.Forms.Button
    Private WithEvents connect As System.Windows.Forms.Button

End Class
