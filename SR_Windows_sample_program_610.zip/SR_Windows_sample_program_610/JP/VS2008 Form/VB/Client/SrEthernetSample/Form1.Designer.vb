﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.receive = New System.Windows.Forms.Button()
        Me.loff = New System.Windows.Forms.Button()
        Me.lon = New System.Windows.Forms.Button()
        Me.disconnect = New System.Windows.Forms.Button()
        Me.connect = New System.Windows.Forms.Button()
        Me.CommandPortInput = New System.Windows.Forms.TextBox()
        Me.DataPortInput = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(279, 128)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.ReadOnly = True
        Me.textBox1.Size = New System.Drawing.Size(260, 19)
        Me.textBox1.TabIndex = 17
        '
        'receive
        '
        Me.receive.Location = New System.Drawing.Point(13, 106)
        Me.receive.Name = "receive"
        Me.receive.Size = New System.Drawing.Size(260, 42)
        Me.receive.TabIndex = 16
        Me.receive.Text = "データ受信"
        Me.receive.UseVisualStyleBackColor = True
        '
        'loff
        '
        Me.loff.Location = New System.Drawing.Point(279, 58)
        Me.loff.Name = "loff"
        Me.loff.Size = New System.Drawing.Size(260, 42)
        Me.loff.TabIndex = 15
        Me.loff.Text = "トリガOFF"
        Me.loff.UseVisualStyleBackColor = True
        '
        'lon
        '
        Me.lon.Location = New System.Drawing.Point(13, 58)
        Me.lon.Name = "lon"
        Me.lon.Size = New System.Drawing.Size(260, 42)
        Me.lon.TabIndex = 14
        Me.lon.Text = "トリガON"
        Me.lon.UseVisualStyleBackColor = True
        '
        'disconnect
        '
        Me.disconnect.Location = New System.Drawing.Point(279, 10)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(260, 42)
        Me.disconnect.TabIndex = 13
        Me.disconnect.Text = "切断"
        Me.disconnect.UseVisualStyleBackColor = True
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(13, 10)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(260, 42)
        Me.connect.TabIndex = 12
        Me.connect.Text = "接続"
        Me.connect.UseVisualStyleBackColor = True
        '
        'CommandPortInput
        '
        Me.CommandPortInput.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.CommandPortInput.Location = New System.Drawing.Point(363, 103)
        Me.CommandPortInput.MaxLength = 5
        Me.CommandPortInput.Name = "CommandPortInput"
        Me.CommandPortInput.Size = New System.Drawing.Size(51, 19)
        Me.CommandPortInput.TabIndex = 18
        '
        'DataPortInput
        '
        Me.DataPortInput.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.DataPortInput.Location = New System.Drawing.Point(488, 103)
        Me.DataPortInput.MaxLength = 5
        Me.DataPortInput.Name = "DataPortInput"
        Me.DataPortInput.Size = New System.Drawing.Size(51, 19)
        Me.DataPortInput.TabIndex = 19
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(289, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 12)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "コマンドポート"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(420, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 12)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "データポート"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(553, 159)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataPortInput)
        Me.Controls.Add(Me.CommandPortInput)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.receive)
        Me.Controls.Add(Me.loff)
        Me.Controls.Add(Me.lon)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents textBox1 As System.Windows.Forms.TextBox
    Private WithEvents receive As System.Windows.Forms.Button
    Private WithEvents loff As System.Windows.Forms.Button
    Private WithEvents lon As System.Windows.Forms.Button
    Private WithEvents disconnect As System.Windows.Forms.Button
    Private WithEvents connect As System.Windows.Forms.Button
    Private WithEvents CommandPortInput As System.Windows.Forms.TextBox
    Private WithEvents DataPortInput As System.Windows.Forms.TextBox
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label

End Class
