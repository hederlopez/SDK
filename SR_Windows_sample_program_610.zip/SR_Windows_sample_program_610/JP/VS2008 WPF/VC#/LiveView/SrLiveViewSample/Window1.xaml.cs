﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Keyence.AutoID;
using MessageBox = System.Windows.MessageBox;

namespace SrLiveViewSample
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class Window1 : Window
    {
        private Keyence.AutoID.BarcodeReaderControl barcodeReaderControl1 = new Keyence.AutoID.BarcodeReaderControl();

        public Window1()
        {
            InitializeComponent();

            DataTable dt = new DataTable("ReaderTable");
            dt.Columns.Add("Text", typeof(string));
            dt.Columns.Add("Value", typeof(ReaderType));
            dt.Rows.Add("SR-D100", ReaderType.SR_D100);
            dt.Rows.Add("SR-750", ReaderType.SR_750);
            dt.Rows.Add("SR-1000", ReaderType.SR_1000);
            dt.Rows.Add("SR-2000", ReaderType.SR_2000);

            this.comboBoxReader.ItemsSource = ((IListSource)dt).GetList();
            this.comboBoxReader.DisplayMemberPath = "Text";
            this.comboBoxReader.SelectedValuePath = "Value";

            this.comboBoxReader.SelectedIndex = this.comboBoxReader.Items.Count - 1;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.barcodeReaderControl1.BackColor = System.Drawing.Color.Lime;
            this.barcodeReaderControl1.IpAddress = "0.0.0.0";
            this.barcodeReaderControl1.LiveView.ImageType = Keyence.AutoID.ImageType.JEPG_IMAGE;
            this.barcodeReaderControl1.LiveView.WindowScale = 2;
            this.barcodeReaderControl1.Location = new System.Drawing.Point(12, 12);
            this.barcodeReaderControl1.Name = "barcodeReaderControl1";
            this.barcodeReaderControl1.Size = new System.Drawing.Size(400, 300);
            this.barcodeReaderControl1.TabIndex = 29;

            this.windowsFormsHost1.Child = this.barcodeReaderControl1;

            //
            // 読み取りデータ受信イベントを処理するハンドラを登録します
            //
            this.barcodeReaderControl1.OnDataReceived +=new Keyence.AutoID.BarcodeReaderControl.OnDataReceivedEventHandler(barcodeReaderControl1_OnDataReceived);
            //
            // 接続リーダのインタフェースを指定します
            //
            this.barcodeReaderControl1.Comm.Interface = Interface.Ethernet;
            //
            // 接続リーダのIPアドレスを指定します
            //
            this.barcodeReaderControl1.IpAddress = "192.168.100.100";
            //
            // 接続リーダのポート番号を指定します
            // コマンドポートとデータポートは異なる値を設定して下さい
            //
            this.barcodeReaderControl1.Ether.CommandPort = 9003;
            this.barcodeReaderControl1.Ether.DataPort = 9004;
        }

        void barcodeReaderControl1_OnDataReceived(object sender, OnDataReceivedEventArgs e)
        {
            //
            // 受信データの表示処理をTextBoxにデリゲートします
            //
            this.textBox2.Dispatcher.Invoke(new updateTextBoxDelegate(updateTextBox), e.data);
        }

        //
        // TextBoxデリゲートメソッド
        //
        private delegate void updateTextBoxDelegate(byte[] data);
        private void updateTextBox(byte[] data)
        {
            //
            // 受信データをSHIFT_JISに変換してTextBoxに表示します
            //
            this.textBox2.Text = Encoding.GetEncoding("Shift_JIS").GetString(data);

            //
            // 画像ファイル保存処理
            //
            bool saveImage;
            if (this.textBox2.Text.StartsWith("ERROR"))
            {
                saveImage = this.radioButtonImageErrSave.IsChecked.Value;

            }
            else
            {
                saveImage = this.radioButtonImageOkSave.IsChecked.Value;
            }
            if (saveImage)
            {
                try
                {
                    //
                    // 保存ファイルのパス取得
                    //
                    string srcFile = this.barcodeReaderControl1.LSIMG();
                    string dstFile = srcFile.Split('\\')[2];
                    //
                    // 画像ファイル取得
                    //
                    this.barcodeReaderControl1.GetFile(srcFile, dstFile);
                    MessageBox.Show(dstFile, "画像ファイル取得");
                }
                catch (Exception ex)
                {
                    this.textBox1.Text = ex.Message;
                }
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //
                // リーダに接続します
                //
                this.barcodeReaderControl1.Connect();
                this.textBox1.Text = "Connected successfully";
                if (this.barcodeReaderControl1.Comm.Interface == Interface.USB)
                {
                    //
                    // データポートを占有するためにSKCLOSEを送信する
                    //
                    this.barcodeReaderControl1.SKCLOSE();
                }
                else
                {
                    //
                    // コマンドのレスポンスを有りに設定しているか確認する
                    //
                    string val = this.barcodeReaderControl1.RP("610");
                    switch (this.barcodeReaderControl1.ReaderType)
                    {
                        case ReaderType.SR_2000:
                        case ReaderType.SR_1000:
                        case ReaderType.SR_700:
                            if (!val.Equals("1"))
                            {
                                this.textBox1.Text = "基本コマンドのレスポンス文字列を詳細返信に設定して下さい。";
                            }
                            break;
                        case ReaderType.SR_D100:
                        case ReaderType.SR_750:
                            if (!val.Equals("0"))
                            {
                                this.textBox1.Text = "レスポンス文字列の指定を無効に設定して下さい。";
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                this.textBox1.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            this.textBox1.Text = "";
            try
            {
                //
                // ライブビューを開始します
                //
                this.barcodeReaderControl1.StartLiveView();
            }
            catch (Exception ex)
            {
                this.textBox1.Text = ex.Message;
            }
        }

        private void radioButton5_Checked_1(object sender, RoutedEventArgs e)
        {
            this.barcodeReaderControl1.StopLiveView();
            this.barcodeReaderControl1.Comm.Interface = Interface.USB;
        }

        private void radioButton6_Checked_1(object sender, RoutedEventArgs e)
        {
            this.barcodeReaderControl1.StopLiveView();
            this.barcodeReaderControl1.Comm.Interface = Interface.Ethernet;
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            this.textBox1.Text = "";
            try
            {
                //
                // LONコマンドを送信します
                //
                this.barcodeReaderControl1.LON();
            }
            catch (CommandException cex)
            {
                //
                // コマンドエラー番号は、ExtErrCodeにセットされます
                //
                this.textBox1.Text = "Command err," + cex.ExtErrCode;
            }
            catch (Exception ex)
            {
                this.textBox1.Text = ex.Message;
            }
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            this.textBox1.Text = "";
            try
            {
                //
                // LOFFコマンドを送信します
                //
                this.barcodeReaderControl1.LOFF();
            }
            catch (Exception ex)
            {
                this.textBox1.Text = ex.Message;
            }
        }

        private void comboBoxReader_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.barcodeReaderControl1.StopLiveView();

            //
            // 接続リーダの種別を指定します
            //
            this.barcodeReaderControl1.ReaderType = (ReaderType)comboBoxReader.SelectedValue;
        }
    }
}
