﻿Imports System.IO
Imports System.IO.Ports
Imports System.Text

'
' RS-232CでSRシリーズと通信するサンプルプログラム
'
Public Class Form1
    Private Const bySTX As Byte = &H2
    Private Const byETX As Byte = &H3
    Private Const byCR As Byte = &HD


    Private Const SERIAL_PORT_COUNT As Integer = 2  ' 使用するCOMポート数
    Private Const RECV_DATA_MAX As Integer = 10240  ' 受信データ最大長
    Private Const binaryDataMode As Integer = False ' バイナリデータ受信モードを使うかどうか
    Private serialPortInstance() As SerialPort      ' 使用するCOMポートインスタンスを格納する配列

    '
    ' コンストラクタ
    '
    Public Sub New()
        InitializeComponent()

        '
        ' RS-232C通信パラメータを指定します
        '
        SerialPort1.BaudRate = 115200           ' 9600, 19200, 38400, 57600 or 115200
        SerialPort1.DataBits = 8                ' 7 or 8
        SerialPort1.Parity = Parity.Even        ' Even or Odd
        SerialPort1.StopBits = StopBits.One     ' One or Two
        SerialPort1.PortName = "COM1"

        SerialPort2.BaudRate = 115200           ' 9600, 19200, 38400, 57600 or 115200
        SerialPort2.DataBits = 8                ' 7 or 8
        SerialPort2.Parity = Parity.Even        ' Even or Odd
        SerialPort2.StopBits = StopBits.One     ' One or Two
        SerialPort2.PortName = "COM2"

        '
        ' COMポートインスタンスを配列に格納します
        '
        serialPortInstance = New SerialPort(SERIAL_PORT_COUNT - 1) {SerialPort1, SerialPort2}
    End Sub

    '
    ' 接続ボタンが押された時に実行される関数
    '
    Private Sub connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connect.Click
        For i = 0 To SERIAL_PORT_COUNT - 1
            Try
                '
                ' COMポートがオープン中であればクローズします
                '
                If serialPortInstance(i).IsOpen Then
                    serialPortInstance(i).Close()
                End If

                '
                ' COMポートをオープンします
                '
                serialPortInstance(i).Open()
                '
                ' 受信タイムアウト時間を100msecに設定します
                '
                serialPortInstance(i).ReadTimeout = 100
            Catch ex As Exception
                MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' ポートが存在しない or 消失
            End Try
        Next i
    End Sub

    '
    ' 切断ボタンが押された時に実行される関数
    '
    Private Sub disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles disconnect.Click
        For i = 0 To SERIAL_PORT_COUNT - 1
            Try
                serialPortInstance(i).Close()
            Catch ex As IOException
                MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' ポートが消失した
            End Try
        Next i
    End Sub

    '
    ' トリガONボタンが押された時に実行される関数
    '
    Private Sub lon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lon.Click
        '
        ' "LON"コマンドを送信します
        ' コマンドのレスポンを読取りデータと区別するために,ヘッダは<STX>, ターミネータは<ETX>とします
        '
        Dim lon As String = vbCr + "LON" + vbCr     ' <CR>LON<CR>
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(lon)
        command(0) = bySTX      ' <STX>LON<CR>
        command(4) = byETX      ' <STX>LON<ETX>

        For i = 0 To SERIAL_PORT_COUNT - 1
            If serialPortInstance(i).IsOpen Then
                Try
                    serialPortInstance(i).Write(command, 0, command.Length)
                Catch ex As IOException
                    MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' ポートが消失した
                End Try
            Else
                MessageBox.Show(serialPortInstance(i).PortName + "は切断中です")
            End If
        Next i
    End Sub

    '
    ' トリガOFFボタンが押された時に実行される関数
    '
    Private Sub loff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loff.Click
        '
        ' "LOFF"コマンドを送信します
        ' コマンドのレスポンを読取りデータと区別するために,ヘッダは<STX>, ターミネータは<ETX>とします
        '
        Dim loff As String = vbCr + "LOFF" + vbCr     ' <CR>LOFF<CR>
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(loff)
        command(0) = bySTX      ' <STX>LOFF<CR>
        command(5) = byETX      ' <STX>LOFF<ETX>

        For i = 0 To SERIAL_PORT_COUNT - 1
            If serialPortInstance(i).IsOpen Then
                Try
                    serialPortInstance(i).Write(command, 0, command.Length)
                Catch ex As IOException
                    MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' ポートが消失した
                End Try
            Else
                MessageBox.Show(serialPortInstance(i).PortName + "は切断中です")
            End If
        Next i
    End Sub

    '
    ' データ受信ボタンが押された時に実行される関数
    '
    Private Sub receive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles receive.Click
        Dim recvBytes As Byte() = New Byte(RECV_DATA_MAX) {}    ' 受信バッファ
        Dim recvSize As Integer ' 受信データサイズ

        For i = 0 To SERIAL_PORT_COUNT - 1
            If serialPortInstance(i).IsOpen Then
                While (True)
                    recvSize = 0
                    Try
                        readDataSub(recvSize, recvBytes, serialPortInstance(i))
                    Catch ex As IOException
                        MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' ポートが消失した
                    End Try
                    If recvSize = 0 Then
                        MessageBox.Show(serialPortInstance(i).PortName + "に受信データはありません")
                        Exit While
                    End If
                    If recvBytes(0) = bySTX Then
                        '
                        ' コマンドのレスポンスは読み飛ばします
                        '
                        Continue While
                    Else
                        '
                        ' 受信データをShift JISに変換してメッセージボックスで表示します
                        ' 文字列として表示するので\0終端します
                        '
                        recvBytes(recvSize) = 0
                        MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes, 0, recvBytes.Length))
                        Exit While
                    End If
                End While
            Else
                MessageBox.Show(serialPortInstance(i).PortName + "は切断中です")
                Continue For
            End If
        Next i
    End Sub

    '
    ' データ受信処理
    '
    Private Sub readDataSub(ByRef recvSize As Integer, ByVal recvBytes() As Byte, ByVal serialPortInstance As SerialPort)
        Dim isCommandRes As Boolean
        Dim d As Byte

        '
        ' コマンドレスポンスか読取りデータかを判別します
        '
        Try
            d = serialPortInstance.ReadByte()
            recvBytes(recvSize) = d
            recvSize += 1
            If d = bySTX Then
                isCommandRes = True ' STXで始まるデータはコマンドレスポンス
            End If
        Catch ex As TimeoutException
            '
            ' 受信データが無い
            '
            Return
        End Try

        '
        ' ターミネータまで受信します
        '
        While (True)
            Try
                d = serialPortInstance.ReadByte()
                recvBytes(recvSize) = d
                recvSize += 1
                If isCommandRes And (d = byETX) Then
                    '
                    ' コマンドレスポンス受信完了
                    '
                    Exit Sub
                ElseIf d = byCR Then
                    Dim complete As Boolean
                    checkDataSize(complete, recvBytes, recvSize)
                    If complete Then
                        Exit Sub ' 読取りデータ受信完了
                    End If
                End If
            Catch ex As TimeoutException
                '
                ' 通信異常(ターミネータが見つからない)
                '
                MessageBox.Show(ex.Message)
                Return
            End Try
        End While
    End Sub

    '
    ' 受信データサイズチェック処理
    '
    Private Sub checkDataSize(ByRef complete As Boolean, ByVal recvBytes() As Byte, ByVal recvsize As Integer)
        Dim dataSizeLen As Integer = 4
        Dim asc0 As Integer = &H30

        If (binaryDataMode = False) Then
            complete = True
            Exit Sub
        End If

        If (recvsize < dataSizeLen) Then
            complete = False
            Exit Sub
        End If

        Dim dataSize As Integer = 0
        Dim mul As Integer = 1

        For i = 0 To dataSizeLen - 1
            dataSize += (recvBytes(dataSizeLen - 1 - i) - asc0) * mul
            mul *= 10
        Next
        If (dataSize + 1 = recvsize) Then
            complete = True
        Else
            complete = False
        End If
    End Sub
End Class
