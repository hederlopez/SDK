﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form1
    Inherits System.Windows.Forms.Form

    'Form は、コンポーネント一覧に後処理を実行するために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer
    private mainMenu1 As System.Windows.Forms.MainMenu

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタでこのプロシージャを変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.receive = New System.Windows.Forms.Button
        Me.loff = New System.Windows.Forms.Button
        Me.lon = New System.Windows.Forms.Button
        Me.disconnect = New System.Windows.Forms.Button
        Me.connect = New System.Windows.Forms.Button
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort2 = New System.IO.Ports.SerialPort(Me.components)
        Me.SuspendLayout()
        '
        'receive
        '
        Me.receive.Location = New System.Drawing.Point(35, 169)
        Me.receive.Name = "receive"
        Me.receive.Size = New System.Drawing.Size(260, 42)
        Me.receive.TabIndex = 24
        Me.receive.Text = "データ受信"
        '
        'loff
        '
        Me.loff.Location = New System.Drawing.Point(301, 98)
        Me.loff.Name = "loff"
        Me.loff.Size = New System.Drawing.Size(260, 42)
        Me.loff.TabIndex = 23
        Me.loff.Text = "トリガOFF"
        '
        'lon
        '
        Me.lon.Location = New System.Drawing.Point(35, 98)
        Me.lon.Name = "lon"
        Me.lon.Size = New System.Drawing.Size(260, 42)
        Me.lon.TabIndex = 22
        Me.lon.Text = "トリガON"
        '
        'disconnect
        '
        Me.disconnect.Location = New System.Drawing.Point(301, 32)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(260, 42)
        Me.disconnect.TabIndex = 21
        Me.disconnect.Text = "切断"
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(35, 32)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(260, 42)
        Me.connect.TabIndex = 20
        Me.connect.Text = "接続"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(638, 254)
        Me.Controls.Add(Me.receive)
        Me.Controls.Add(Me.loff)
        Me.Controls.Add(Me.lon)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents receive As System.Windows.Forms.Button
    Private WithEvents loff As System.Windows.Forms.Button
    Private WithEvents lon As System.Windows.Forms.Button
    Private WithEvents disconnect As System.Windows.Forms.Button
    Private WithEvents connect As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents SerialPort2 As System.IO.Ports.SerialPort

End Class
