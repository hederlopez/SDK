﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

/// <summary>
/// EthernetでSRシリーズと通信するサンプルプログラム(クライアント動作)
/// </summary>
namespace SrEthernetSample
{
    public partial class Form1 : Form
    {
        private const int READER_COUNT = 2;          // 接続するリーダ数
        private const int RECV_DATA_MAX = 10240;    // 受信データ最大長
        private ClientSocket[] clientSocketInstance;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            //
            // ClientSocketインスタンスを確保し, 接続するリーダのIPアドレス, コマンドポート番号
            // データポート番号を指定します
            //
            clientSocketInstance = new ClientSocket[READER_COUNT];

            int readerIndex = 0;
            int CommandPort = 9003;
            int DataPort = 9004;
            CommandPortInput.Text = Convert.ToString(CommandPort);
            DataPortInput.Text = Convert.ToString(DataPort);

            //
            // 1台目のリーダ
            //
            byte[] ip1 = { 192, 168, 100, 100 };
            clientSocketInstance[readerIndex++] = new ClientSocket(ip1, CommandPort, DataPort);  // コマンドポート=9003, データポート=9004

            //
            // 2台目のリーダ
            //
            byte[] ip2 = { 192, 168, 100, 101 };
            clientSocketInstance[readerIndex++] = new ClientSocket(ip2, CommandPort, DataPort);  // コマンドポート=9003, データポート=9004
        }

        /// <summary>
        /// 接続ボタンが押された時に実行される関数
        /// </summary>
        private void connect_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < READER_COUNT; i++)
            {
                //
                // コマンド通信ポートに接続します
                //
                try
                {
                    clientSocketInstance[i].readerCommandEndPoint.Port = Convert.ToInt32(CommandPortInput.Text);
                    clientSocketInstance[i].readerDataEndPoint.Port = Convert.ToInt32(DataPortInput.Text);
                    //
                    // オープン中のソケットがあればクローズします
                    //
                    if (clientSocketInstance[i].commandSocket != null)
                    {
                        clientSocketInstance[i].commandSocket.Close();
                    }

                    //
                    // 新規ソケットを作成します
                    //
                    clientSocketInstance[i].commandSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    textBox1.Text = clientSocketInstance[i].readerCommandEndPoint.ToString() + "接続中";
                    textBox1.Update();

                    clientSocketInstance[i].commandSocket.Connect(clientSocketInstance[i].readerCommandEndPoint);

                    textBox1.Text = clientSocketInstance[i].readerCommandEndPoint.ToString() + "接続成功";
                    textBox1.Update();
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    //
                    // 接続に失敗すると例外が発生しますのでキャッチしてメッセージを表示します
                    //
                    textBox1.Text = clientSocketInstance[i].readerCommandEndPoint.ToString() + "接続失敗";
                    textBox1.Update();
                    MessageBox.Show(ex.Message);
                    clientSocketInstance[i].commandSocket = null;
                    continue;
                }
                catch (SocketException ex)
                {
                    //
                    // 接続に失敗すると例外が発生しますのでキャッチしてメッセージを表示します
                    //
                    textBox1.Text = clientSocketInstance[i].readerCommandEndPoint.ToString() + "接続失敗";
                    textBox1.Update();
                    MessageBox.Show(ex.Message);
                    clientSocketInstance[i].commandSocket = null;
                    continue;
                }

               //
               // データ通信ポートに接続します
               //
               try
               {
                   //
                   // オープン中のソケットがあればクローズします
                   //
                   if (clientSocketInstance[i].dataSocket != null)
                   {
                       clientSocketInstance[i].dataSocket.Close();
                   }

            //
            //コマンド通信ポートとデータ通信ポートに分かれていない場合、2つのポートを統一し、新たな接続をスキップします
            //
            if (clientSocketInstance[i].readerCommandEndPoint.Port == clientSocketInstance[i].readerDataEndPoint.Port)
            {
                    clientSocketInstance[i].dataSocket = clientSocketInstance[i].commandSocket;
           }else{
                   //
                   // 新規ソケットを作成して接続します
                   //
                   clientSocketInstance[i].dataSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                   textBox1.Text = clientSocketInstance[i].readerDataEndPoint.ToString() + "接続中";
                   textBox1.Update();

                   clientSocketInstance[i].dataSocket.Connect(clientSocketInstance[i].readerDataEndPoint);

                   textBox1.Text = clientSocketInstance[i].readerDataEndPoint.ToString() + "接続成功";
                   textBox1.Update();
            }

                   //
                   // 受信タイムアウト時間を100msecに設定します
                   //
                   //clientSocketInstance[i].dataSocket.ReceiveTimeout = 100;
               }

               catch (SocketException ex)
               {
                   //
                   // 接続に失敗すると例外が発生しますのでキャッチしてメッセージを表示します
                   //
                   textBox1.Text = clientSocketInstance[i].readerDataEndPoint.ToString() + "接続失敗";
                   textBox1.Update();
                   MessageBox.Show(ex.Message);
                   clientSocketInstance[i].dataSocket = null;
                   continue;
               }
            }
            
        }

        /// <summary>
        /// 切断ボタンが押された時に実行される関数
        /// </summary>
        private void disconnect_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < READER_COUNT; i++)
            {
                //
                // コマンド通信ソケットをクローズします
                //
                if (clientSocketInstance[i].commandSocket != null)
                {
                    clientSocketInstance[i].commandSocket.Close();
                    clientSocketInstance[i].commandSocket = null;
                    textBox1.Text = clientSocketInstance[i].readerCommandEndPoint.ToString() + "切断";
                    textBox1.Update();
                }

                //
                //データ通信ソケットをクローズします
                //
                if (clientSocketInstance[i].dataSocket != null)
                {
                    clientSocketInstance[i].dataSocket.Close();
                    clientSocketInstance[i].dataSocket = null;
                    textBox1.Text = clientSocketInstance[i].readerDataEndPoint.ToString() + "切断";
                    textBox1.Update();
                }
            }

        }

        /// <summary>
        /// トリガONボタンが押された時に実行される関数
        /// </summary>
        private void lon_Click(object sender, EventArgs e)
        {
            //
            // "LON"コマンドをByte配列で送信します
            // 
            string lon = "LON\r";   // ターミネータはCR
            Byte[] command = ASCIIEncoding.ASCII.GetBytes(lon);

            for (int i = 0; i < READER_COUNT; i++)
            {
                if (clientSocketInstance[i].commandSocket != null)
                {
                    clientSocketInstance[i].commandSocket.Send(command);
                }
                else
                {
                    MessageBox.Show(clientSocketInstance[i].readerCommandEndPoint.ToString() + "は切断中です");
                }
            }
        }

        /// <summary>
        /// トリガOFFボタンが押された時に実行される関数
        /// </summary>
        private void loff_Click(object sender, EventArgs e)
        {
            //
            // "LOFF"コマンドをByte配列で送信します
            // 
            string loff = "LOFF\r"; // ターミネータはCR
            Byte[] command = ASCIIEncoding.ASCII.GetBytes(loff);

            for (int i = 0; i < READER_COUNT; i++)
            {
                if (clientSocketInstance[i].commandSocket != null)
                {
                    clientSocketInstance[i].commandSocket.Send(command);
                }
                else
                {
                    MessageBox.Show(clientSocketInstance[i].readerCommandEndPoint.ToString() + "は切断中です");
                }
            }
        }

        /// <summary>
        /// データ受信ボタンが押された時に実行される関数
        /// </summary>
        private void receive_Click(object sender, EventArgs e)
        {
            Byte[] recvBytes = new Byte[RECV_DATA_MAX];  // 受信バッファ
            int recvSize = 0;               // 受信データサイズ

            for (int i = 0; i < READER_COUNT; i++)
            {
                if (clientSocketInstance[i].dataSocket != null)
                {
                    try
                    {
                        recvSize = clientSocketInstance[i].dataSocket.Receive(recvBytes);
                    }
                    catch (SocketException)
                    {
                        //
                        // 受信できない時は例外が発生するのでキャッチします
                        //
                        recvSize = 0;
                    }
                }
                else
                {
                    MessageBox.Show(clientSocketInstance[i].readerDataEndPoint.ToString() + "は切断中です");
                    continue;
                }

                if (recvSize == 0)
                {
                    MessageBox.Show(clientSocketInstance[i].readerDataEndPoint.ToString() + "に受信データはありません");
                }
                else
                {
                    //
                    // 受信データをShift JISに変換してメッセージボックスで表示します
                    // 文字列として表示するので\0終端します
                    //
                    recvBytes[recvSize] = 0;
                    MessageBox.Show(clientSocketInstance[i].readerDataEndPoint.ToString() + "\r\n" + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes, 0, recvBytes.Length));
                }
            }
        }
        //
        // ポート番号入力の際に数値以外受け付けないようにします
        //
        private void PortInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }        


    }

    /// <summary>
    /// 各リーダの接続ソケットを保持するクラス
    /// </summary>
    class ClientSocket
    {
        public Socket commandSocket;   // コマンド通信用ソケット
        public Socket dataSocket;      // データ通信用ソケット
        public IPEndPoint readerCommandEndPoint;
        public IPEndPoint readerDataEndPoint;

        public ClientSocket(byte[] ipAddress, int readerCommandPort, int readerDataPort)
        {
            IPAddress readerIpAddress = new IPAddress(ipAddress);
            readerCommandEndPoint = new IPEndPoint(readerIpAddress, readerCommandPort);
            readerDataEndPoint = new IPEndPoint(readerIpAddress, readerDataPort);
            commandSocket = null;
            dataSocket = null;
        }
    }
}
