﻿namespace SrEthernetServerSample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.receive = new System.Windows.Forms.Button();
            this.disconnect = new System.Windows.Forms.Button();
            this.connect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // receive
            // 
            this.receive.Location = new System.Drawing.Point(14, 92);
            this.receive.Name = "receive";
            this.receive.Size = new System.Drawing.Size(260, 42);
            this.receive.TabIndex = 11;
            this.receive.Text = "データ受信";
            this.receive.Click += new System.EventHandler(this.receive_Click);
            // 
            // disconnect
            // 
            this.disconnect.Location = new System.Drawing.Point(280, 29);
            this.disconnect.Name = "disconnect";
            this.disconnect.Size = new System.Drawing.Size(260, 42);
            this.disconnect.TabIndex = 10;
            this.disconnect.Text = "待ち受け終了";
            this.disconnect.Click += new System.EventHandler(this.disconnect_Click);
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(14, 29);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(260, 42);
            this.connect.TabIndex = 9;
            this.connect.Text = "待ち受け開始";
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(553, 171);
            this.Controls.Add(this.receive);
            this.Controls.Add(this.disconnect);
            this.Controls.Add(this.connect);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button receive;
        private System.Windows.Forms.Button disconnect;
        private System.Windows.Forms.Button connect;
    }
}

