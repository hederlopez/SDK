﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

/// <summary>
/// EthernetでSRシリーズと通信するサンプルプログラム(サーバ動作)
/// </summary>
namespace SrEthernetServerSample
{
    public partial class Form1 : Form
    {
        private const int READER_COUNT = 10;        // 接続可能なリーダ数
        private const int RECV_DATA_MAX = 10240;    // 受信データ最大長
        private const int LISTEN_PORT = 9004;       // 待ち受けポート番号
        private Socket listenSocket = null;         // Listen用ソケット
        private Socket[] dataSocket;                // データ通信用ソケット

        public Form1()
        {
            InitializeComponent();
            dataSocket = new Socket[READER_COUNT];
        }

        /// <summary>
        /// 待ち受け開始ボタンが押された時に実行される関数
        /// </summary>
        private void connect_Click(object sender, EventArgs e)
        {
            IPEndPoint hostDataEndPoint = new IPEndPoint(IPAddress.Any, LISTEN_PORT);

            if (listenSocket != null)
            {
                MessageBox.Show("待ち受け中です");
                return;
            }

            //
            // 新規ソケットを作成してListenを開始します
            //
            listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listenSocket.Bind(hostDataEndPoint);
            listenSocket.Listen(5);     // 保留できる接続要求数は5

            //
            // 非同期でAccept処理を開始します
            //
            try
            {
                listenSocket.BeginAccept(new AsyncCallback(acceptCallback), listenSocket);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // エラー
            }
        }

        /// <summary>
        /// Accept可能時に呼び出されるコールバック関数
        /// </summary>
        /// <param name="ar"></param>
        private void acceptCallback(IAsyncResult ar)
        {
            if (listenSocket == null)
            {
                return;
            }

            try
            {
                //
                // Accept処理を完了させます
                //
                Socket newSocket = listenSocket.EndAccept(ar);

                //
                // 受信タイムアウト時間を100msecに設定します
                //
                //newSocket.ReceiveTimeout = 100;

                MessageBox.Show(newSocket.RemoteEndPoint.ToString() + "が接続しました");

                for (int i = 0; i < dataSocket.Length; i++)
                {
                    if (dataSocket[i] == null)
                    {
                        dataSocket[i] = newSocket;
                        //
                        // 非同期でAccept処理を開始します
                        //
                        listenSocket.BeginAccept(new AsyncCallback(acceptCallback), listenSocket);
                        return;
                    }
                }

                newSocket.Close();
            }
            catch (ObjectDisposedException)
            {
                //
                // Accept処理中に切断すると,この例外が発生します
                //
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // エラー
            }
        }

        /// <summary>
        /// 待ち受け終了ボタンが押された時に実行される関数
        /// </summary>
        private void disconnect_Click(object sender, EventArgs e)
        {
            //
            //データ通信ソケットをクローズします
            //
            for (int i = 0; i < dataSocket.Length; i++)
            {
                if (dataSocket[i] != null)
                {
                    dataSocket[i].Close();
                    dataSocket[i] = null;
                }
            }

            //
            // Listenソケットをクローズします
            //
            if (listenSocket != null)
            {
                listenSocket.Close();
                listenSocket = null;
            }
        }

        /// <summary>
        /// データ受信ボタンが押された時に実行される関数
        /// </summary>
        private void receive_Click(object sender, EventArgs e)
        {
            Byte[] recvBytes = new Byte[RECV_DATA_MAX];  // 受信バッファ
            int recvSize = 0;                           // 受信データサイズ

            for (int i = 0; i < dataSocket.Length; i++)
            {
                if (dataSocket[i] != null)
                {
                    try
                    {
                        recvSize = dataSocket[i].Receive(recvBytes);
                    }
                    catch (SocketException)
                    {
                        //
                        // 受信できない時は例外が発生するのでキャッチします
                        //
                        recvSize = 0;
                    }
                }
                else
                {
                    continue;
                }

                if (recvSize == 0)
                {
                    MessageBox.Show(dataSocket[i].RemoteEndPoint.ToString() + "に受信データはありません");
                }
                else
                {
                    //
                    // 受信データをShift JISに変換してメッセージボックスで表示します
                    // 文字列として表示するので\0終端します
                    //
                    recvBytes[recvSize] = 0;
                    MessageBox.Show(dataSocket[i].RemoteEndPoint.ToString() + "\r\n" + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes, 0, recvBytes.Length));
                }
            }
        }
    }
}
