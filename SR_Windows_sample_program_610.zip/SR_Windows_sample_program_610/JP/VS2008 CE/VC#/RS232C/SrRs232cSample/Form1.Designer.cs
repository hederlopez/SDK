﻿namespace SrRs232cSample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.receive = new System.Windows.Forms.Button();
            this.loff = new System.Windows.Forms.Button();
            this.lon = new System.Windows.Forms.Button();
            this.disconnect = new System.Windows.Forms.Button();
            this.connect = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.serialPort2 = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // receive
            // 
            this.receive.Location = new System.Drawing.Point(12, 149);
            this.receive.Name = "receive";
            this.receive.Size = new System.Drawing.Size(260, 42);
            this.receive.TabIndex = 19;
            this.receive.Text = "データ受信";
            this.receive.Click += new System.EventHandler(this.receive_Click);
            // 
            // loff
            // 
            this.loff.Location = new System.Drawing.Point(278, 89);
            this.loff.Name = "loff";
            this.loff.Size = new System.Drawing.Size(260, 42);
            this.loff.TabIndex = 18;
            this.loff.Text = "トリガOFF";
            this.loff.Click += new System.EventHandler(this.loff_Click);
            // 
            // lon
            // 
            this.lon.Location = new System.Drawing.Point(12, 89);
            this.lon.Name = "lon";
            this.lon.Size = new System.Drawing.Size(260, 42);
            this.lon.TabIndex = 17;
            this.lon.Text = "トリガON";
            this.lon.Click += new System.EventHandler(this.lon_Click);
            // 
            // disconnect
            // 
            this.disconnect.Location = new System.Drawing.Point(278, 26);
            this.disconnect.Name = "disconnect";
            this.disconnect.Size = new System.Drawing.Size(260, 42);
            this.disconnect.TabIndex = 16;
            this.disconnect.Text = "切断";
            this.disconnect.Click += new System.EventHandler(this.disconnect_Click);
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(12, 26);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(260, 42);
            this.connect.TabIndex = 15;
            this.connect.Text = "接続";
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(554, 220);
            this.Controls.Add(this.receive);
            this.Controls.Add(this.loff);
            this.Controls.Add(this.lon);
            this.Controls.Add(this.disconnect);
            this.Controls.Add(this.connect);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button receive;
        private System.Windows.Forms.Button loff;
        private System.Windows.Forms.Button lon;
        private System.Windows.Forms.Button disconnect;
        private System.Windows.Forms.Button connect;
        private System.IO.Ports.SerialPort serialPort1;
        private System.IO.Ports.SerialPort serialPort2;
    }
}

