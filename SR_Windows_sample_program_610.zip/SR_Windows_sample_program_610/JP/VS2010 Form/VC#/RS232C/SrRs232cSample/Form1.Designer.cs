﻿namespace SrRs232cSample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.receive = new System.Windows.Forms.Button();
            this.loff = new System.Windows.Forms.Button();
            this.lon = new System.Windows.Forms.Button();
            this.disconnect = new System.Windows.Forms.Button();
            this.connect = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.serialPort2 = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // receive
            // 
            this.receive.Location = new System.Drawing.Point(12, 108);
            this.receive.Name = "receive";
            this.receive.Size = new System.Drawing.Size(260, 42);
            this.receive.TabIndex = 9;
            this.receive.Text = "データ受信";
            this.receive.UseVisualStyleBackColor = true;
            this.receive.Click += new System.EventHandler(this.receive_Click);
            // 
            // loff
            // 
            this.loff.Location = new System.Drawing.Point(278, 60);
            this.loff.Name = "loff";
            this.loff.Size = new System.Drawing.Size(260, 42);
            this.loff.TabIndex = 8;
            this.loff.Text = "トリガOFF";
            this.loff.UseVisualStyleBackColor = true;
            this.loff.Click += new System.EventHandler(this.loff_Click);
            // 
            // lon
            // 
            this.lon.Location = new System.Drawing.Point(12, 60);
            this.lon.Name = "lon";
            this.lon.Size = new System.Drawing.Size(260, 42);
            this.lon.TabIndex = 7;
            this.lon.Text = "トリガON";
            this.lon.UseVisualStyleBackColor = true;
            this.lon.Click += new System.EventHandler(this.lon_Click);
            // 
            // disconnect
            // 
            this.disconnect.Location = new System.Drawing.Point(278, 12);
            this.disconnect.Name = "disconnect";
            this.disconnect.Size = new System.Drawing.Size(260, 42);
            this.disconnect.TabIndex = 6;
            this.disconnect.Text = "切断";
            this.disconnect.UseVisualStyleBackColor = true;
            this.disconnect.Click += new System.EventHandler(this.disconnect_Click);
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(12, 12);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(260, 42);
            this.connect.TabIndex = 5;
            this.connect.Text = "接続";
            this.connect.UseVisualStyleBackColor = true;
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 161);
            this.Controls.Add(this.receive);
            this.Controls.Add(this.loff);
            this.Controls.Add(this.lon);
            this.Controls.Add(this.disconnect);
            this.Controls.Add(this.connect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button receive;
        private System.Windows.Forms.Button loff;
        private System.Windows.Forms.Button lon;
        private System.Windows.Forms.Button disconnect;
        private System.Windows.Forms.Button connect;
        private System.IO.Ports.SerialPort serialPort1;
        private System.IO.Ports.SerialPort serialPort2;
    }
}

