﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

/// <summary>
/// RS-232CでSRシリーズと通信するサンプルプログラム
/// </summary>
namespace SrRs232cSample
{
    public partial class Form1 : Form
    {
        private const Byte STX = 0x02;
        private const Byte ETX = 0x03;
        private const Byte CR = 0x0d;

        private const int SERIAL_PORT_COUNT = 2;    // 使用するCOMポート数
        private const int RECV_DATA_MAX = 10240;    // 受信データ最大長
        private const bool binaryDataMode = false;  // バイナリデータ受信モードを使うかどうか
        private SerialPort[] serialPortInstance;    // 使用するCOMポートインスタンスを格納する配列

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            //
            // RS-232C通信パラメータを指定します
            //
            this.serialPort1.BaudRate = 115200;         // 9600, 19200, 38400, 57600 or 115200
            this.serialPort1.DataBits = 8;              // 7 or 8
            this.serialPort1.Parity = Parity.Even;    // Even or Odd
            this.serialPort1.StopBits = StopBits.One;   // One or Two
            this.serialPort1.PortName = "COM1";

            this.serialPort2.BaudRate = 115200;         // 9600, 19200, 38400, 57600 or 115200
            this.serialPort2.DataBits = 8;              // 7 or 8
            this.serialPort2.Parity = Parity.Even;    // Even or Odd
            this.serialPort2.StopBits = StopBits.One;   // One or Two
            this.serialPort2.PortName = "COM2";

            //
            // COMポートインスタンスを配列に格納します
            //
            serialPortInstance = new SerialPort[SERIAL_PORT_COUNT] { this.serialPort1, this.serialPort2 };
        }



        /// <summary>
        /// 接続ボタンが押された時に実行される関数
        /// </summary>
        private void connect_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                try
                {
                    //
                    // COMポートがオープ中であればクローズします
                    //
                    if (serialPortInstance[i].IsOpen)
                    {
                        this.serialPortInstance[i].Close();
                    }

                    //
                    // COMポートをオープンします
                    //
                    this.serialPortInstance[i].Open();

                    //
                    // 受信タイムアウト時間を100msecに設定します
                    //
                    this.serialPortInstance[i].ReadTimeout = 100;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);  // ポートが存在しない or ポートが消失
                }
            }
        }

        /// <summary>
        /// 切断ボタンが押された時に実行される関数
        /// </summary>
        private void disconnect_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                //
                // COMポートをクローズします
                //
                try
                {
                    this.serialPortInstance[i].Close();
                }
                catch (IOException ex)
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // ポートが消失した
                }
            }
        }

        /// <summary>
        /// トリガONボタンが押された時に実行される関数
        /// </summary>
        private void lon_Click(object sender, EventArgs e)
        {
            //
            // "LON"コマンドを送信します
            // コマンドのレスポンを読取りデータと区別するために,ヘッダは<STX>, ターミネータは<ETX>とします
            // 
            string lon = "\x02LON\x03";   // <STX>LON<ETX>
            Byte[] sendBytes = ASCIIEncoding.ASCII.GetBytes(lon);

            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                if (this.serialPortInstance[i].IsOpen)
                {
                    try
                    {
                        this.serialPortInstance[i].Write(sendBytes, 0, sendBytes.Length);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // ポートが消失した
                    }
                }
                else
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "は切断中です");
                }
            }
        }

        /// <summary>
        /// トリガOFFボタンが押された時に実行される関数
        /// </summary>
        private void loff_Click(object sender, EventArgs e)
        {
            //
            // "LOFF"コマンドを送信します
            // コマンドのレスポンを読取りデータと区別するために,ヘッダは<STX>, ターミネータは<ETX>とします
            // 
            string loff = "\x02LOFF\x03";   // <STX>LOFF<ETX>
            Byte[] sendBytes = ASCIIEncoding.ASCII.GetBytes(loff);

            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                if (this.serialPortInstance[i].IsOpen)
                {
                    try
                    {
                        this.serialPortInstance[i].Write(sendBytes, 0, sendBytes.Length);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // ポートが消失した
                    }
                }
                else
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "は切断中です");
                }
            }
        }

        /// <summary>
        /// データ受信ボタンが押された時に実行される関数
        /// </summary>
        private void receive_Click(object sender, EventArgs e)
        {
            Byte[] recvBytes = new Byte[RECV_DATA_MAX];  // 受信バッファ
            int recvSize;                           // 受信データサイズ

            for (int i = 0; i < this.serialPortInstance.Length; i++)
            {
                if (this.serialPortInstance[i].IsOpen == false)
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "は切断中です");
                    continue;
                }

                for (; ; )
                {
                    try
                    {
                        recvSize = readDataSub(recvBytes, this.serialPortInstance[i]);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // ポートが消失した
                        break;
                    }
                    if (recvSize == 0)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "に受信データはありません");
                        break;
                    }
                    if (recvBytes[0] == STX)
                    {
                        //
                        // コマンドのレスポンスは読み飛ばします
                        //
                        continue;
                    }
                    else
                    {
                        //
                        // 受信データをShift JISに変換してメッセージボックスで表示します
                        // 文字列として表示するので\0終端します
                        //
                        recvBytes[recvSize] = 0;
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes));
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// データ受信処理
        /// </summary>
        /// <param name="recvBytes">受信データを格納するバッファ</param>
        /// <param name="recvBytes">データ受信するシリアルポート</param>
        /// <returns>受信データサイズ</returns>
        private int readDataSub(Byte[] recvBytes, SerialPort serialPortInstance)
        {
            int recvSize = 0;       // 受信データサイズ
            bool isCommandRes = false;   // コマンドのレスポンスかどうか
            Byte d;

            //
            // コマンドレスポンスか読取りデータかを判別します
            //
            try
            {
                d = (Byte)serialPortInstance.ReadByte();
                recvBytes[recvSize++] = d;
                if (d == STX)
                {
                    isCommandRes = true;    // STXで始まるデータはコマンドレスポンス
                }
            }
            catch (TimeoutException)
            {
                return 0;   // 受信データが無い
            }

            //
            // ターミネータまで受信します
            //
            while (true)
            {
                try
                {
                    d = (Byte)serialPortInstance.ReadByte();
                    recvBytes[recvSize++] = d;

                    if (isCommandRes && (d == ETX))
                    {
                        break;  // コマンドレスポンス受信完了
                    }
                    else if (d == CR)
                    {
                        if (checkDataSize(recvBytes, recvSize))
                        {
                            break;  // 読取りデータ受信完了
                        }
                    }
                }
                catch (TimeoutException ex)
                {
                    //
                    // 通信異常(ターミネータが見つからない)
                    //
                    MessageBox.Show(ex.Message);
                    return 0;
                }
            }

            return recvSize;
        }

        /// <summary>
        /// 受信データサイズチェック処理
        /// </summary>
        private bool checkDataSize(Byte[] recvBytes, int recvSize)
        {
            const int dataSizeLen = 4;

            if (binaryDataMode == false)
            {
                return true;
            }

            if (recvSize < dataSizeLen)
            {
                return false;
            }

            int dataSize = 0;
            int mul = 1;
            for (int i = 0; i < dataSizeLen; i++)
            {
                dataSize += (recvBytes[dataSizeLen - 1 - i] - '0') * mul;
                mul *= 10;
            }

            return (dataSize + 1 == recvSize);
        }
    }
}
