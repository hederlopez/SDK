﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.barcodeReaderControl1 = New Keyence.AutoID.BarcodeReaderControl()
        Me.button6 = New System.Windows.Forms.Button()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.radioButtonImageErrSave = New System.Windows.Forms.RadioButton()
        Me.radioButtonImageOkSave = New System.Windows.Forms.RadioButton()
        Me.radioButtonImageNoSave = New System.Windows.Forms.RadioButton()
        Me.ComboBoxReader = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'barcodeReaderControl1
        '
        Me.barcodeReaderControl1.BackColor = System.Drawing.Color.Lime
        Me.barcodeReaderControl1.IpAddress = "0.0.0.0"
        Me.barcodeReaderControl1.LiveView.WindowScale = 2
        Me.barcodeReaderControl1.Location = New System.Drawing.Point(14, 16)
        Me.barcodeReaderControl1.Name = "barcodeReaderControl1"
        Me.barcodeReaderControl1.ReaderType = Keyence.AutoID.ReaderType.SR_D100
        Me.barcodeReaderControl1.Size = New System.Drawing.Size(400, 300)
        Me.barcodeReaderControl1.TabIndex = 46
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(208, 325)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(190, 49)
        Me.button6.TabIndex = 42
        Me.button6.Text = "ライブビュー開始"
        Me.button6.UseVisualStyleBackColor = True
        '
        'textBox3
        '
        Me.textBox3.Location = New System.Drawing.Point(432, 79)
        Me.textBox3.Multiline = True
        Me.textBox3.Name = "textBox3"
        Me.textBox3.ReadOnly = True
        Me.textBox3.Size = New System.Drawing.Size(240, 116)
        Me.textBox3.TabIndex = 38
        Me.textBox3.Text = "IPアドレス = 192.168.100.100" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "コマンド待ち受けポート番号 = 9003" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "データ待ち受けポート番号  = 9004"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(430, 64)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(55, 12)
        Me.label3.TabIndex = 37
        Me.label3.Text = "リーダ設定"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(12, 543)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(76, 12)
        Me.label2.TabIndex = 36
        Me.label2.Text = "読み取りデータ"
        '
        'textBox2
        '
        Me.textBox2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.textBox2.Location = New System.Drawing.Point(12, 565)
        Me.textBox2.Multiline = True
        Me.textBox2.Name = "textBox2"
        Me.textBox2.ReadOnly = True
        Me.textBox2.Size = New System.Drawing.Size(587, 112)
        Me.textBox2.TabIndex = 35
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(12, 450)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(50, 12)
        Me.label1.TabIndex = 34
        Me.label1.Text = "ステータス"
        '
        'textBox1
        '
        Me.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.textBox1.Location = New System.Drawing.Point(12, 471)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.ReadOnly = True
        Me.textBox1.Size = New System.Drawing.Size(587, 47)
        Me.textBox1.TabIndex = 33
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(12, 325)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(190, 49)
        Me.button3.TabIndex = 32
        Me.button3.Text = "接続"
        Me.button3.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(110, 391)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(92, 49)
        Me.button2.TabIndex = 31
        Me.button2.Text = "LOFF"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(12, 391)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(92, 49)
        Me.button1.TabIndex = 30
        Me.button1.Text = "LON"
        Me.button1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ComboBoxReader)
        Me.GroupBox1.Location = New System.Drawing.Point(432, 212)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(116, 111)
        Me.GroupBox1.TabIndex = 47
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "リーダ種別"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton4)
        Me.GroupBox2.Controls.Add(Me.RadioButton5)
        Me.GroupBox2.Location = New System.Drawing.Point(554, 212)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(120, 111)
        Me.GroupBox2.TabIndex = 48
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "インタフェース"
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Checked = True
        Me.RadioButton4.Location = New System.Drawing.Point(24, 66)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(82, 16)
        Me.RadioButton4.TabIndex = 45
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "ETHERNET"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(24, 44)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(46, 16)
        Me.RadioButton5.TabIndex = 44
        Me.RadioButton5.Text = "USB"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.radioButtonImageErrSave)
        Me.groupBox3.Controls.Add(Me.radioButtonImageOkSave)
        Me.groupBox3.Controls.Add(Me.radioButtonImageNoSave)
        Me.groupBox3.Location = New System.Drawing.Point(432, 329)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(182, 111)
        Me.groupBox3.TabIndex = 50
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "画像保存"
        '
        'radioButtonImageErrSave
        '
        Me.radioButtonImageErrSave.AutoSize = True
        Me.radioButtonImageErrSave.Location = New System.Drawing.Point(7, 65)
        Me.radioButtonImageErrSave.Name = "radioButtonImageErrSave"
        Me.radioButtonImageErrSave.Size = New System.Drawing.Size(105, 16)
        Me.radioButtonImageErrSave.TabIndex = 2
        Me.radioButtonImageErrSave.Text = "読み取りエラー時"
        Me.radioButtonImageErrSave.UseVisualStyleBackColor = True
        '
        'radioButtonImageOkSave
        '
        Me.radioButtonImageOkSave.AutoSize = True
        Me.radioButtonImageOkSave.Location = New System.Drawing.Point(7, 42)
        Me.radioButtonImageOkSave.Name = "radioButtonImageOkSave"
        Me.radioButtonImageOkSave.Size = New System.Drawing.Size(102, 16)
        Me.radioButtonImageOkSave.TabIndex = 1
        Me.radioButtonImageOkSave.Text = "読み取り成功時"
        Me.radioButtonImageOkSave.UseVisualStyleBackColor = True
        '
        'radioButtonImageNoSave
        '
        Me.radioButtonImageNoSave.AutoSize = True
        Me.radioButtonImageNoSave.Checked = True
        Me.radioButtonImageNoSave.Location = New System.Drawing.Point(7, 19)
        Me.radioButtonImageNoSave.Name = "radioButtonImageNoSave"
        Me.radioButtonImageNoSave.Size = New System.Drawing.Size(76, 16)
        Me.radioButtonImageNoSave.TabIndex = 0
        Me.radioButtonImageNoSave.TabStop = True
        Me.radioButtonImageNoSave.Text = "保存しない"
        Me.radioButtonImageNoSave.UseVisualStyleBackColor = True
        '
        'ComboBoxReader
        '
        Me.ComboBoxReader.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxReader.FormattingEnabled = True
        Me.ComboBoxReader.Location = New System.Drawing.Point(7, 44)
        Me.ComboBoxReader.Name = "ComboBoxReader"
        Me.ComboBoxReader.Size = New System.Drawing.Size(102, 20)
        Me.ComboBoxReader.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 687)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.barcodeReaderControl1)
        Me.Controls.Add(Me.button6)
        Me.Controls.Add(Me.textBox3)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents barcodeReaderControl1 As Keyence.AutoID.BarcodeReaderControl
    Private WithEvents button6 As System.Windows.Forms.Button
    Private WithEvents textBox3 As System.Windows.Forms.TextBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents textBox2 As System.Windows.Forms.TextBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents textBox1 As System.Windows.Forms.TextBox
    Private WithEvents button3 As System.Windows.Forms.Button
    Private WithEvents button2 As System.Windows.Forms.Button
    Private WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Private WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Private WithEvents groupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents radioButtonImageErrSave As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonImageOkSave As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonImageNoSave As System.Windows.Forms.RadioButton
    Friend WithEvents ComboBoxReader As System.Windows.Forms.ComboBox

End Class
