﻿Imports System.Text
Imports System.Net
Imports System.Net.Sockets

'
' EthernetでSRシリーズと通信するサンプルプログラム(サーバ動作)
'
Public Class Form1
    Private Const READER_COUNT As Integer = 10      ' 接続可能なリーダ数
    Private Const RECV_DATA_MAX As Integer = 10240  ' 受信データ最大長
    Private Const LISTEN_PORT As Integer = 9004     ' 待ち受けポート番号
    Private listenSocket As Socket = Nothing        ' Listen用ソケット
    Private dataSocket() As Socket                  ' データ通信用ソケット

    '
    ' コンストラクタ
    '
    Public Sub New()
        InitializeComponent()
        dataSocket = New Socket(READER_COUNT - 1) {}
    End Sub

    '
    ' 待ち受け開始ボタンが押された時に実行される関数
    '
    Private Sub connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connect.Click
        Dim hostDataEndPoint As IPEndPoint = New IPEndPoint(IPAddress.Any, LISTEN_PORT)

        If listenSocket IsNot Nothing Then
            MessageBox.Show("待ち受け中です")
            Return
        End If

        '
        ' 新規ソケットを作成してListenを開始します
        '
        listenSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
        listenSocket.Bind(hostDataEndPoint)
        listenSocket.Listen(5)  ' 保留できる接続要求数は5

        '
        ' 非同期でAccept処理を開始します
        '
        Try
            listenSocket.BeginAccept(New System.AsyncCallback(AddressOf acceptCallback), listenSocket)
        Catch ex As Exception
            MessageBox.Show(ex.Message) ' エラー
        End Try
    End Sub

    '
    ' Accept可能時に呼び出されるコールバック関数
    '
    Private Sub acceptCallback(ByVal ar As System.IAsyncResult)
        If listenSocket Is Nothing Then
            Return
        End If

        Try
            Dim newSocket As Socket
            newSocket = listenSocket.EndAccept(ar)
            '
            ' 受信タイムアウト時間を100msecに設定します
            '
            newSocket.ReceiveTimeout = 100
            MessageBox.Show(newSocket.RemoteEndPoint.ToString() + "が接続しました")

            For i = 0 To READER_COUNT - 1
                If dataSocket(i) Is Nothing Then
                    dataSocket(i) = newSocket
                    '
                    ' 非同期でAccept処理を開始します
                    '
                    listenSocket.BeginAccept(New System.AsyncCallback(AddressOf acceptCallback), listenSocket)
                    Return
                End If
            Next
            newSocket.Close()
        Catch ex As ObjectDisposedException
            '
            ' Accept処理中に切断すると,この例外が発生します
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message) ' エラー
        End Try
    End Sub

    '
    ' 待ち受け終了ボタンが押された時に実行される関数
    '
    Private Sub disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles disconnect.Click
        '
        ' データ通信ソケットをクローズします
        '
        For i = 0 To READER_COUNT - 1
            If dataSocket(i) IsNot Nothing Then
                dataSocket(i).Close()
                dataSocket(i) = Nothing
            End If
        Next

        '
        ' Listenソケットをクローズします
        '
        If listenSocket IsNot Nothing Then
            listenSocket.Close()
            listenSocket = Nothing
        End If
    End Sub

    '
    ' データ受信ボタンが押された時に実行される関数
    '
    Private Sub receive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles receive.Click
        Dim recvBytes As Byte() = New Byte(RECV_DATA_MAX) {}    ' 受信バッファ
        Dim recvSize As Integer = 0 ' 受信データサイズ

        For i = 0 To READER_COUNT - 1
            If dataSocket(i) IsNot Nothing Then
                Try
                    recvSize = dataSocket(i).Receive(recvBytes)
                Catch ex As SocketException
                    '
                    ' 受信できない時は例外が発生するのでキャッチします
                    '
                    recvSize = 0
                End Try
            Else
                Continue For
            End If

            If recvSize = 0 Then
                MessageBox.Show(dataSocket(i).RemoteEndPoint.ToString() + "に受信データはありません")
            Else
                '
                ' 受信データをShift JISに変換してメッセージボックスで表示します
                ' 文字列として表示するので\0終端します
                '
                recvBytes(recvSize) = 0
                MessageBox.Show(dataSocket(i).RemoteEndPoint.ToString() + vbCrLf + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes))
            End If
        Next
    End Sub
End Class
