﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

'
' EthernetでSRシリーズと通信するサンプルプログラム(クライアント動作)
'
Public Class Form1

    Private Const READER_COUNT As Integer = 2    ' 接続するリーダ数
    Private Const RECV_DATA_MAX As Integer = 10240  ' 受信データ最大長
    Private clientSocketInstance() As ClientSocket

    '
    ' コンストラクタ
    '
    Public Sub New()
        InitializeComponent()

        '
        ' ClientSocketインスタンスを確保し, 接続するリーダのIPアドレス, コマンドポート番号
        ' データポート番号を指定します
        '
        Dim ipAddress0() As Byte = {192, 168, 100, 100}
        Dim ipAddress1() As Byte = {192, 168, 100, 101}
        CommandPortInput.Text = 9003
        DataPortInput.Text = 9004
        clientSocketInstance = New ClientSocket(READER_COUNT - 1) {}
        clientSocketInstance(0) = New ClientSocket(ipAddress0, CommandPortInput.Text, DataPortInput.Text)
        clientSocketInstance(1) = New ClientSocket(ipAddress1, CommandPortInput.Text, DataPortInput.Text)
    End Sub

    '
    ' 接続ボタンが押された時に実行される関数
    '
    Private Sub connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connect.Click
        For i = 0 To READER_COUNT - 1
            '
            'ポート番号の入力を反映させます
            '
            Try
                clientSocketInstance(i).readerCommandEndPoint.Port = CommandPortInput.Text
                clientSocketInstance(i).readerDataEndPoint.Port = DataPortInput.Text
                '
                ' コマンド通信ポートに接続します
                '

                '
                ' オープン中のソケットがあればクローズします
                '
                If clientSocketInstance(i).commandSocket IsNot Nothing Then
                    clientSocketInstance(i).commandSocket.Close()
                End If
                '
                ' 新規ソケットを作成します
                '
                clientSocketInstance(i).commandSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + "接続中"
                textBox1.Update()

                clientSocketInstance(i).commandSocket.Connect(clientSocketInstance(i).readerCommandEndPoint)

                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + "接続成功"
                textBox1.Update()
                '
                ' 接続に失敗すると例外が発生しますのでキャッチしてメッセージを表示します
                '
            Catch ex As ArgumentOutOfRangeException
                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + "接続失敗"
                textBox1.Update()
                MessageBox.Show(ex.Message)
                clientSocketInstance(i).commandSocket = Nothing
                Return
            Catch ex As SocketException
                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + "接続失敗"
                textBox1.Update()
                MessageBox.Show(ex.Message)
                clientSocketInstance(i).commandSocket = Nothing
                Continue For
            End Try
            '
            ' データ通信ポートに接続します
            '
            Try
                '
                ' オープン中のソケットがあればクローズします
                '
                If clientSocketInstance(i).dataSocket IsNot Nothing Then
                    clientSocketInstance(i).dataSocket.Close()
                End If
                '
                'コマンド通信ポートとデータ通信ポートに分かれていない場合、2つのポートを統一し、新たな接続をスキップします
                '
                If clientSocketInstance(i).readerCommandEndPoint.Port = clientSocketInstance(i).readerDataEndPoint.Port Then
                        clientSocketInstance(i).dataSocket = clientSocketInstance(i).commandSocket
                Else
                    '
                    ' 新規ソケットを作成します
                    '
                    clientSocketInstance(i).dataSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                    textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + "接続中"
                    textBox1.Update()

                    clientSocketInstance(i).dataSocket.Connect(clientSocketInstance(i).readerDataEndPoint)

                    textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + "接続成功"
                    textBox1.Update()
                End If
                '
                ' 受信タイムアウト時間を100msecに設定します
                '
                clientSocketInstance(i).dataSocket.ReceiveTimeout = 100
            Catch ex As SocketException
                '
                ' 接続に失敗すると例外が発生しますのでキャッチしてメッセージを表示します
                '
                textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + "接続失敗"
                textBox1.Update()
                MessageBox.Show(ex.Message)
                clientSocketInstance(i).dataSocket = Nothing
                Continue For
            End Try
        Next i
    End Sub

    '
    ' 切断ボタンが押された時に実行される関数
    '
    Private Sub disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles disconnect.Click
        For i = 0 To READER_COUNT - 1
            '
            ' コマンド通信ソケットをクローズします
            '
            If clientSocketInstance(i).commandSocket IsNot Nothing Then
                clientSocketInstance(i).commandSocket.Close()
                clientSocketInstance(i).commandSocket = Nothing
                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + "切断"
                textBox1.Update()
            End If
            '
            ' データ通信ソケットをクローズします
            '
            If clientSocketInstance(i).dataSocket IsNot Nothing Then
                clientSocketInstance(i).dataSocket.Close()
                clientSocketInstance(i).dataSocket = Nothing
                textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + "切断"
                textBox1.Update()
            End If
        Next i
    End Sub

    '
    ' トリガONボタンが押された時に実行される関数
    '
    Private Sub lon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lon.Click
        '
        ' "LON"コマンドをByte配列で送信します
        '
        Dim lon As String = "LON" + vbCr     ' ターミネータはCR
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(lon)

        For i = 0 To READER_COUNT - 1
            If clientSocketInstance(i).commandSocket IsNot Nothing Then
                clientSocketInstance(i).commandSocket.Send(command)
            Else
                MessageBox.Show(clientSocketInstance(i).readerCommandEndPoint.ToString() + "は切断中です")
            End If
        Next i
    End Sub

    '
    ' トリガOFFボタンが押された時に実行される関数
    '
    Private Sub loff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loff.Click
        '
        ' "LOFF"コマンドをByte配列で送信します
        '
        Dim loff As String = "LOFF" + vbCr     ' ターミネータはCR
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(loff)

        For i = 0 To READER_COUNT - 1
            If clientSocketInstance(i).commandSocket IsNot Nothing Then
                clientSocketInstance(i).commandSocket.Send(command)
            Else
                MessageBox.Show(clientSocketInstance(i).readerCommandEndPoint.ToString() + "は切断中です")
            End If
        Next i
    End Sub

    '
    ' データ受信ボタンが押された時に実行される関数
    '
    Private Sub receive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles receive.Click
        Dim recvBytes As Byte() = New Byte(RECV_DATA_MAX) {}    ' 受信バッファ
        Dim recvSize As Integer = 0 ' 受信データサイズ

        For i = 0 To READER_COUNT - 1
            If clientSocketInstance(i).dataSocket IsNot Nothing Then
                Try
                    recvSize = clientSocketInstance(i).dataSocket.Receive(recvBytes)
                Catch ex As SocketException
                    '
                    ' 受信できない時は例外が発生するのでキャッチします
                    '
                    recvSize = 0
                End Try
            Else
                MessageBox.Show(clientSocketInstance(i).readerDataEndPoint.ToString() + "は切断中です")
                Continue For
            End If

            If recvSize = 0 Then
                MessageBox.Show(clientSocketInstance(i).readerDataEndPoint.ToString() + "に受信データはありません")
            Else
                '
                ' 受信データをShift JISに変換してメッセージボックスで表示します
                ' 文字列として表示するので\0終端します
                '
                recvBytes(recvSize) = 0
                MessageBox.Show(clientSocketInstance(i).readerDataEndPoint.ToString() + vbCrLf + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes))
            End If
        Next i

    End Sub

    '
    ' 各リーダの接続ソケットを保持するクラス
    '
    Public Class ClientSocket
        Public commandSocket As Socket              ' コマンド通信用ソケット
        Public dataSocket As Socket                 ' データ通信用ソケット
        Public readerCommandEndPoint As IPEndPoint  ' コマンド通信ポート番号
        Public readerDataEndPoint As IPEndPoint    ' データ通信ポート番号

        Public Sub New(ByVal ipAddress() As Byte, ByVal readerCommandPort As Integer, ByVal readerDataPort As Integer)
            Dim readerIpAddress As IPAddress = New IPAddress(ipAddress)
            readerCommandEndPoint = New IPEndPoint(readerIpAddress, readerCommandPort)
            readerDataEndPoint = New IPEndPoint(readerIpAddress, readerDataPort)
            commandSocket = Nothing
            dataSocket = Nothing
        End Sub
    End Class


    '
    'ポート番号入力の際に数値以外受け付けないようにします
    '
    Private Sub PortInput_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CommandPortInput.KeyPress, DataPortInput.KeyPress
        If (e.KeyChar < "0" Or e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub
End Class
