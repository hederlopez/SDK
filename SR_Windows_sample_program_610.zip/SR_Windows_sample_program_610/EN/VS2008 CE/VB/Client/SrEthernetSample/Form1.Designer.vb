﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.receive = New System.Windows.Forms.Button
        Me.loff = New System.Windows.Forms.Button
        Me.lon = New System.Windows.Forms.Button
        Me.disconnect = New System.Windows.Forms.Button
        Me.connect = New System.Windows.Forms.Button
        Me.CommandPortInput = New System.Windows.Forms.TextBox
        Me.DataPortInput = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(287, 164)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.ReadOnly = True
        Me.textBox1.Size = New System.Drawing.Size(260, 23)
        Me.textBox1.TabIndex = 23
        '
        'receive
        '
        Me.receive.Location = New System.Drawing.Point(21, 154)
        Me.receive.Name = "receive"
        Me.receive.Size = New System.Drawing.Size(260, 42)
        Me.receive.TabIndex = 22
        Me.receive.Text = "Receive Data"
        '
        'loff
        '
        Me.loff.Location = New System.Drawing.Point(287, 91)
        Me.loff.Name = "loff"
        Me.loff.Size = New System.Drawing.Size(260, 42)
        Me.loff.TabIndex = 21
        Me.loff.Text = "Timing OFF"
        '
        'lon
        '
        Me.lon.Location = New System.Drawing.Point(21, 91)
        Me.lon.Name = "lon"
        Me.lon.Size = New System.Drawing.Size(260, 42)
        Me.lon.TabIndex = 20
        Me.lon.Text = "Timing ON"
        '
        'disconnect
        '
        Me.disconnect.Location = New System.Drawing.Point(287, 28)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(260, 42)
        Me.disconnect.TabIndex = 19
        Me.disconnect.Text = "Disconnect"
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(21, 28)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(260, 42)
        Me.connect.TabIndex = 18
        Me.connect.Text = "Connect"
        '
        'CommandPortInput
        '
        Me.CommandPortInput.Location = New System.Drawing.Point(287, 202)
        Me.CommandPortInput.MaxLength = 5
        Me.CommandPortInput.Name = "CommandPortInput"
        Me.CommandPortInput.Size = New System.Drawing.Size(67, 23)
        Me.CommandPortInput.TabIndex = 24
        '
        'DataPortInput
        '
        Me.DataPortInput.Location = New System.Drawing.Point(457, 202)
        Me.DataPortInput.MaxLength = 5
        Me.DataPortInput.Name = "DataPortInput"
        Me.DataPortInput.Size = New System.Drawing.Size(67, 23)
        Me.DataPortInput.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(184, 204)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 23)
        Me.Label1.Text = "Command Port"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(382, 204)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 23)
        Me.Label2.Text = "Data Port"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(569, 233)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataPortInput)
        Me.Controls.Add(Me.CommandPortInput)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.receive)
        Me.Controls.Add(Me.loff)
        Me.Controls.Add(Me.lon)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents textBox1 As System.Windows.Forms.TextBox
    Private WithEvents receive As System.Windows.Forms.Button
    Private WithEvents loff As System.Windows.Forms.Button
    Private WithEvents lon As System.Windows.Forms.Button
    Private WithEvents disconnect As System.Windows.Forms.Button
    Private WithEvents connect As System.Windows.Forms.Button
    Private WithEvents CommandPortInput As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents DataPortInput As System.Windows.Forms.TextBox

End Class
