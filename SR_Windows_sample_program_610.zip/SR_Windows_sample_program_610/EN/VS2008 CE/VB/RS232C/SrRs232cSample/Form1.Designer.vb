﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    private mainMenu1 As System.Windows.Forms.MainMenu

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.receive = New System.Windows.Forms.Button
        Me.loff = New System.Windows.Forms.Button
        Me.lon = New System.Windows.Forms.Button
        Me.disconnect = New System.Windows.Forms.Button
        Me.connect = New System.Windows.Forms.Button
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort2 = New System.IO.Ports.SerialPort(Me.components)
        Me.SuspendLayout()
        '
        'receive
        '
        Me.receive.Location = New System.Drawing.Point(46, 211)
        Me.receive.Name = "receive"
        Me.receive.Size = New System.Drawing.Size(260, 42)
        Me.receive.TabIndex = 29
        Me.receive.Text = "Receive Data"
        '
        'loff
        '
        Me.loff.Location = New System.Drawing.Point(312, 130)
        Me.loff.Name = "loff"
        Me.loff.Size = New System.Drawing.Size(260, 42)
        Me.loff.TabIndex = 28
        Me.loff.Text = "Timing OFF"
        '
        'lon
        '
        Me.lon.Location = New System.Drawing.Point(46, 130)
        Me.lon.Name = "lon"
        Me.lon.Size = New System.Drawing.Size(260, 42)
        Me.lon.TabIndex = 27
        Me.lon.Text = "Timing ON"
        '
        'disconnect
        '
        Me.disconnect.Location = New System.Drawing.Point(312, 48)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(260, 42)
        Me.disconnect.TabIndex = 26
        Me.disconnect.Text = "Disconnect"
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(46, 48)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(260, 42)
        Me.connect.TabIndex = 25
        Me.connect.Text = "Connect"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(618, 314)
        Me.Controls.Add(Me.receive)
        Me.Controls.Add(Me.loff)
        Me.Controls.Add(Me.lon)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents receive As System.Windows.Forms.Button
    Private WithEvents loff As System.Windows.Forms.Button
    Private WithEvents lon As System.Windows.Forms.Button
    Private WithEvents disconnect As System.Windows.Forms.Button
    Private WithEvents connect As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents SerialPort2 As System.IO.Ports.SerialPort

End Class
