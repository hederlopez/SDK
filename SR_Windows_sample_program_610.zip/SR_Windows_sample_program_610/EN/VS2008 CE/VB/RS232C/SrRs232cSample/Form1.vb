﻿Imports System.IO
Imports System.IO.Ports
Imports System.Text

'
' Sample program to connect SR series readers with RS-232C cable.
'
Public Class Form1
    Private Const bySTX As Byte = &H2
    Private Const byETX As Byte = &H3
    Private Const byCR As Byte = &HD

    Private Const SERIAL_PORT_COUNT As Integer = 2    ' Number of COM ports used
    Private Const RECV_DATA_MAX As Integer = 10240
    Private Const binaryDataMode As Integer = False ' Whether using binary data mode
    Private serialPortInstance() As SerialPort      ' Array to store instances of COM ports used

    '
    ' Constructor
    '
    Public Sub New()
        InitializeComponent()

        '
        ' Set RS-232C parameters.
        '
        SerialPort1.BaudRate = 115200           ' 9600, 19200, 38400, 57600 or 115200
        SerialPort1.DataBits = 8                ' 7 or 8
        SerialPort1.Parity = Parity.Even        ' Even or Odd
        SerialPort1.StopBits = StopBits.One     ' One or Two
        SerialPort1.PortName = "COM1"

        SerialPort2.BaudRate = 115200           ' 9600, 19200, 38400, 57600 or 115200
        SerialPort2.DataBits = 8                ' 7 or 8
        SerialPort2.Parity = Parity.Even        ' Even or Odd
        SerialPort2.StopBits = StopBits.One     ' One or Two
        SerialPort2.PortName = "COM2"

        '
        ' Store COM ports instances in the array.
        '
        serialPortInstance = New SerialPort(SERIAL_PORT_COUNT - 1) {SerialPort1, SerialPort2}
    End Sub

    '
    ' handler for "Connect" button is clicked
    '
    Private Sub connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connect.Click
        For i = 0 To SERIAL_PORT_COUNT - 1
            Try
                '
                ' Close the COM port if opened.
                '
                If serialPortInstance(i).IsOpen Then
                    serialPortInstance(i).Close()
                End If

                '
                ' Open the COM port.
                '
                serialPortInstance(i).Open()
                '
                ' Set 100 milliseconds to receive timeout.
                '
                serialPortInstance(i).ReadTimeout = 100
            Catch ex As Exception
                MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' non-existent or disappeared
            End Try
        Next i
    End Sub

    '
    ' handler for "Disonnect" button is clicked
    '
    Private Sub disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles disconnect.Click
        For i = 0 To SERIAL_PORT_COUNT - 1
            Try
                serialPortInstance(i).Close()
            Catch ex As IOException
                MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' disappeared
            End Try
        Next i
    End Sub

    '
    ' handler for "Timing ON" button is clicked
    '
    Private Sub lon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lon.Click
        '
        ' Send "LON" command.
        ' Set STX to command header and ETX to the terminator to distinguish between command respons
        ' and read data when receives data from readers.
        '
        Dim lon As String = vbCr + "LON" + vbCr     ' <CR>LON<CR>
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(lon)
        command(0) = bySTX      ' <STX>LON<CR>
        command(4) = byETX      ' <STX>LON<ETX>

        For i = 0 To SERIAL_PORT_COUNT - 1
            If serialPortInstance(i).IsOpen Then
                Try
                    serialPortInstance(i).Write(command, 0, command.Length)
                Catch ex As IOException
                    MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' disappeared
                End Try
            Else
                MessageBox.Show(serialPortInstance(i).PortName + " is disconnected.")
            End If
        Next i
    End Sub

    '
    ' handler for "Timing OFF" button is clicked
    '
    Private Sub loff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loff.Click
        '
        ' Send "LOFF" command.
        ' Set STX to command header and ETX to the terminator to distinguish between command respons
        ' and read data when receives data from readers.
        '
        Dim loff As String = vbCr + "LOFF" + vbCr     ' <CR>LOFF<CR>
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(loff)
        command(0) = bySTX      ' <STX>LOFF<CR>
        command(5) = byETX      ' <STX>LOFF<ETX>

        For i = 0 To SERIAL_PORT_COUNT - 1
            If serialPortInstance(i).IsOpen Then
                Try
                    serialPortInstance(i).Write(command, 0, command.Length)
                Catch ex As IOException
                    MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' disappeared
                End Try
            Else
                MessageBox.Show(serialPortInstance(i).PortName + " is disconnected.")
            End If
        Next i
    End Sub

    '
    ' handler for "Receive Data" button is clicked
    '
    Private Sub receive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles receive.Click
        Dim recvBytes As Byte() = New Byte(RECV_DATA_MAX) {}
        Dim recvSize As Integer

        For i = 0 To SERIAL_PORT_COUNT - 1
            If serialPortInstance(i).IsOpen Then
                While (True)
                    recvSize = 0
                    Try
                        readDataSub(recvSize, recvBytes, serialPortInstance(i))
                    Catch ex As IOException
                        MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + ex.Message)   ' disappeared
                    End Try
                    If recvSize = 0 Then
                        MessageBox.Show(serialPortInstance(i).PortName + " has no data.")
                        Exit While
                    End If
                    If recvBytes(0) = bySTX Then
                        '
                        ' Skip if command response.
                        '
                        Continue While
                    Else
                        '
                        ' Show the receive data after converting the receive data to Shift-JIS.
                        ' Terminating null to handle as string.
                        '
                        recvBytes(recvSize) = 0
                        MessageBox.Show(serialPortInstance(i).PortName + vbCrLf + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes, 0, recvBytes.Length))
                        Exit While
                    End If
                End While
            Else
                MessageBox.Show(serialPortInstance(i).PortName + " is disconnected.")
                Continue For
            End If
        Next i
    End Sub

    '
    ' Sub function to receive data
    '
    Private Sub readDataSub(ByRef recvSize As Integer, ByVal recvBytes() As Byte, ByVal serialPortInstance As SerialPort)
        Dim isCommandRes As Boolean
        Dim d As Byte

        '
        ' Distinguish between command response and read data.
        '
        Try
            d = serialPortInstance.ReadByte()
            recvBytes(recvSize) = d
            recvSize += 1
            If d = bySTX Then
                isCommandRes = True ' this is command response because the header character is STX
            End If
        Catch ex As TimeoutException
            '
            ' No data received.
            '
            Return
        End Try

        '
        ' Receive data until the terminator character.
        '
        While (True)
            Try
                d = serialPortInstance.ReadByte()
                recvBytes(recvSize) = d
                recvSize += 1
                If isCommandRes And (d = byETX) Then
                    '
                    ' Command response is received completely.
                    '
                    Exit Sub
                ElseIf d = byCR Then
                    Dim complete As Boolean
                    checkDataSize(complete, recvBytes, recvSize)
                    If complete Then
                        Exit Sub ' Read data is received completely.
                    End If
                End If
            Catch ex As TimeoutException
                '
                ' No terminator is received.
                '
                MessageBox.Show(ex.Message)
                Return
            End Try
        End While
    End Sub

    '
    ' check data size
    '
    Private Sub checkDataSize(ByRef complete As Boolean, ByVal recvBytes() As Byte, ByVal recvsize As Integer)
        Dim dataSizeLen As Integer = 4
        Dim asc0 As Integer = &H30

        If (binaryDataMode = False) Then
            complete = True
            Exit Sub
        End If

        If (recvsize < dataSizeLen) Then
            complete = False
            Exit Sub
        End If

        Dim dataSize As Integer = 0
        Dim mul As Integer = 1

        For i = 0 To dataSizeLen - 1
            dataSize += (recvBytes(dataSizeLen - 1 - i) - asc0) * mul
            mul *= 10
        Next
        If (dataSize + 1 = recvsize) Then
            complete = True
        Else
            complete = False
        End If
    End Sub
End Class
