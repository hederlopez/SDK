﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

/// <summary>
/// Sample program that a server host accepts connection from a SR series reader.
/// </summary>
namespace SrEthernetServerSample
{
    public partial class Form1 : Form
    {
        private const int READER_COUNT = 10;    // number of readers can be connected
        private const int RECV_DATA_MAX = 10240;
        private Socket listenSocket = null;     // socket for listening
        private const int LISTEN_PORT = 9004;   // listening port
        private Socket[] dataSocket;            // sockets for data

        public Form1()
        {
            InitializeComponent();
            dataSocket = new Socket[READER_COUNT];
        }

        /// <summary>
        /// handler for "Start Listening" button is clicked
        /// </summary>
        private void connect_Click(object sender, EventArgs e)
        {
            IPEndPoint hostDataEndPoint = new IPEndPoint(IPAddress.Any, LISTEN_PORT);

            if (listenSocket != null)
            {
                MessageBox.Show("Already listening.");
                return;
            }

            //
            // Create a new socket and start listening.
            //
            listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listenSocket.Bind(hostDataEndPoint);
            listenSocket.Listen(5);     // Maximum pending request is 5.

            //
            // Start accepting asynchronously.
            //
            try
            {
                listenSocket.BeginAccept(new AsyncCallback(acceptCallback), listenSocket);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // Error
            }
        }

        /// <summary>
        /// Callback function that is called when new connection is acceptable.
        /// </summary>
        /// <param name="ar"></param>
        private void acceptCallback(IAsyncResult ar)
        {
            if (listenSocket == null)
            {
                return;
            }

            try
            {
                //
                // Finish accepting.
                //
                Socket newSocket = listenSocket.EndAccept(ar);

                //
                // Set 100 milliseconds to receive timeout.
                //
                //newSocket.ReceiveTimeout = 100;

                MessageBox.Show(newSocket.RemoteEndPoint.ToString() + " is connected.");

                for (int i = 0; i < dataSocket.Length; i++)
                {
                    if (dataSocket[i] == null)
                    {
                        dataSocket[i] = newSocket;
                        //
                        // Start accepting asynchronously.
                        //
                        listenSocket.BeginAccept(new AsyncCallback(acceptCallback), listenSocket);
                        return;
                    }
                }

                newSocket.Close();
            }
            catch (ObjectDisposedException)
            {
                //
                // This exception occures when the listening socket is closed before acception is done.
                //
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // Error
            }
        }

        /// <summary>
        /// handler for "Stop Listening" button is clicked
        /// </summary>
        private void disconnect_Click(object sender, EventArgs e)
        {
            //
            // Close the data sockets.
            //
            for (int i = 0; i < dataSocket.Length; i++)
            {
                if (dataSocket[i] != null)
                {
                    dataSocket[i].Close();
                    dataSocket[i] = null;
                }
            }

            //
            // Close the listening socket.
            //
            if (listenSocket != null)
            {
                listenSocket.Close();
                listenSocket = null;
            }
        }

        /// <summary>
        /// handler for "Receive Data" button is clicked
        /// </summary>
        private void receive_Click(object sender, EventArgs e)
        {
            Byte[] recvBytes = new Byte[RECV_DATA_MAX];
            int recvSize = 0;

            for (int i = 0; i < dataSocket.Length; i++)
            {
                if (dataSocket[i] != null)
                {
                    try
                    {
                        recvSize = dataSocket[i].Receive(recvBytes);
                    }
                    catch (SocketException)
                    {
                        //
                        // Catch the exception, if cannot receive any data.
                        //
                        recvSize = 0;
                    }
                }
                else
                {
                    continue;
                }

                if (recvSize == 0)
                {
                    MessageBox.Show(dataSocket[i].RemoteEndPoint.ToString() + " has no data.");
                }
                else
                {
                    //
                    // Show the receive data after converting the receive data to Shift-JIS.
                    // Terminating null to handle as string.
                    //
                    recvBytes[recvSize] = 0;
                    MessageBox.Show(dataSocket[i].RemoteEndPoint.ToString() + "\r\n" + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes, 0, recvBytes.Length));
                }
            }
        }
    }
}
