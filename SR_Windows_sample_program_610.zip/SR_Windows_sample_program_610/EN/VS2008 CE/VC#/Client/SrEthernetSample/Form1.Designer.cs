﻿namespace SrEthernetSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.receive = new System.Windows.Forms.Button();
            this.loff = new System.Windows.Forms.Button();
            this.lon = new System.Windows.Forms.Button();
            this.disconnect = new System.Windows.Forms.Button();
            this.connect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CommandPortInput = new System.Windows.Forms.TextBox();
            this.DataPortInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(297, 216);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(260, 23);
            this.textBox1.TabIndex = 23;
            // 
            // receive
            // 
            this.receive.Location = new System.Drawing.Point(31, 205);
            this.receive.Name = "receive";
            this.receive.Size = new System.Drawing.Size(260, 42);
            this.receive.TabIndex = 22;
            this.receive.Text = "Receive Data";
            this.receive.Click += new System.EventHandler(this.receive_Click);
            // 
            // loff
            // 
            this.loff.Location = new System.Drawing.Point(297, 126);
            this.loff.Name = "loff";
            this.loff.Size = new System.Drawing.Size(260, 42);
            this.loff.TabIndex = 21;
            this.loff.Text = "Timing OFF";
            this.loff.Click += new System.EventHandler(this.loff_Click);
            // 
            // lon
            // 
            this.lon.Location = new System.Drawing.Point(31, 126);
            this.lon.Name = "lon";
            this.lon.Size = new System.Drawing.Size(260, 42);
            this.lon.TabIndex = 20;
            this.lon.Text = "Timing ON";
            this.lon.Click += new System.EventHandler(this.lon_Click);
            // 
            // disconnect
            // 
            this.disconnect.Location = new System.Drawing.Point(297, 40);
            this.disconnect.Name = "disconnect";
            this.disconnect.Size = new System.Drawing.Size(260, 42);
            this.disconnect.TabIndex = 19;
            this.disconnect.Text = "Disconnect";
            this.disconnect.Click += new System.EventHandler(this.disconnect_Click);
            // 
            // connect
            // 
            this.connect.Location = new System.Drawing.Point(31, 40);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(260, 42);
            this.connect.TabIndex = 18;
            this.connect.Text = "Connect";
            this.connect.Click += new System.EventHandler(this.connect_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(262, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 24);
            this.label1.Text = "Command Port";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(422, 270);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 24);
            this.label2.Text = "Data Port";
            // 
            // CommandPortInput
            // 
            this.CommandPortInput.Location = new System.Drawing.Point(356, 270);
            this.CommandPortInput.MaxLength = 5;
            this.CommandPortInput.Name = "CommandPortInput";
            this.CommandPortInput.Size = new System.Drawing.Size(60, 23);
            this.CommandPortInput.TabIndex = 27;
            // 
            // DataPortInput
            // 
            this.DataPortInput.Location = new System.Drawing.Point(497, 270);
            this.DataPortInput.MaxLength = 5;
            this.DataPortInput.Name = "DataPortInput";
            this.DataPortInput.Size = new System.Drawing.Size(60, 23);
            this.DataPortInput.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(597, 313);
            this.Controls.Add(this.DataPortInput);
            this.Controls.Add(this.CommandPortInput);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.receive);
            this.Controls.Add(this.loff);
            this.Controls.Add(this.lon);
            this.Controls.Add(this.disconnect);
            this.Controls.Add(this.connect);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button receive;
        private System.Windows.Forms.Button loff;
        private System.Windows.Forms.Button lon;
        private System.Windows.Forms.Button disconnect;
        private System.Windows.Forms.Button connect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox CommandPortInput;
        private System.Windows.Forms.TextBox DataPortInput;
    }
}

