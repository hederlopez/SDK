#pragma onace

extern void SrRs232cApi_Init();
extern void SrRs232cApi_Open();
extern void SrRs232cApi_Close();
extern void SrRs232cApi_Lon();
extern void SrRs232cApi_Loff();
extern void SrRs232cApi_Receive();