// SrRs232cSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SrRs232cSample.h"
#include "SrRs232cSampleDlg.h"
#include "SrRs232cApi.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSrRs232cSampleDlg dialog

CSrRs232cSampleDlg::CSrRs232cSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrRs232cSampleDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSrRs232cSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSrRs232cSampleDlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CONNECT, &CSrRs232cSampleDlg::OnBnClickedConnect)
	ON_BN_CLICKED(IDC_DISCONNECT, &CSrRs232cSampleDlg::OnBnClickedDisconnect)
	ON_BN_CLICKED(IDC_LON, &CSrRs232cSampleDlg::OnBnClickedLon)
	ON_BN_CLICKED(IDC_LOFF, &CSrRs232cSampleDlg::OnBnClickedLoff)
	ON_BN_CLICKED(IDC_RECEIVE, &CSrRs232cSampleDlg::OnBnClickedReceive)
END_MESSAGE_MAP()


// CSrRs232cSampleDlg message handlers

BOOL CSrRs232cSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	SrRs232cApi_Init();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
void CSrRs232cSampleDlg::OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/)
{
	if (AfxIsDRAEnabled())
	{
		DRA::RelayoutDialog(
			AfxGetResourceHandle(), 
			this->m_hWnd, 
			DRA::GetDisplayMode() != DRA::Portrait ? 
			MAKEINTRESOURCE(IDD_SRRS232CSAMPLE_DIALOG) : 
			MAKEINTRESOURCE(IDD_SRRS232CSAMPLE_DIALOG));
	}
}
#endif


void CSrRs232cSampleDlg::OnBnClickedConnect()
{
	SrRs232cApi_Open();
}

void CSrRs232cSampleDlg::OnBnClickedDisconnect()
{
	SrRs232cApi_Close();
}

void CSrRs232cSampleDlg::OnBnClickedLon()
{
	SrRs232cApi_Lon();
}

void CSrRs232cSampleDlg::OnBnClickedLoff()
{
	SrRs232cApi_Loff();
}

void CSrRs232cSampleDlg::OnBnClickedReceive()
{
	SrRs232cApi_Receive();
}