// Sample program to connect SR series readers with RS-232C cable.
#include <stdio.h>
#include <winsock2.h>
#include "stdafx.h"

#define SERIAL_PORT_COUNT	2	// Number of COM ports used
#define RECV_DATA_MAX	10240

static HANDLE m_rs232cHandle[SERIAL_PORT_COUNT];	// Array to store COM port handles used
// Name of COM port used
// Be careful to specify serial ports larger than COM9
static CString m_portName[SERIAL_PORT_COUNT] = { (CString)"COM1", (CString)"\\\\.\\COM10" };
static bool m_binaryDataMode = false;	// Whether using binary data mode

#define STX		0x02
#define ETX		0x03
#define CR		0x0d

static int readDataSub(char *recvBytes, HANDLE handle);
static bool checkDataSize(char *recvBytes, int recvSize);


// Function to initialize
void SrRs232cApi_Init()
{
	for (int i = 0; i < SERIAL_PORT_COUNT; i++) {
		m_rs232cHandle[i] = INVALID_HANDLE_VALUE;
	}
}

// Function to open COM port
void SrRs232cApi_Open()
{
	for (int i = 0; i < SERIAL_PORT_COUNT; i++) {
		// Close the COM port if opened.
		if (m_rs232cHandle[i] != INVALID_HANDLE_VALUE) {
			CloseHandle(m_rs232cHandle[i]);
			m_rs232cHandle[i] = INVALID_HANDLE_VALUE;
		}

		// Open the COM port.
		m_rs232cHandle[i] = CreateFile(m_portName[i], GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
		if (m_rs232cHandle[i] == INVALID_HANDLE_VALUE) {
			CString s;
			s.Format(_T("cannot open %s."), m_portName[i]);		
			AfxMessageBox(s);
			continue;
		}

		// Set parametes to COM port.
		DCB dcb;
		memset(&dcb, NULL, sizeof(DCB));
		dcb.DCBlength = sizeof(DCB);
		dcb.BaudRate  = 115200;			// 9600, 19200, 38400, 57600 or 115200
		dcb.Parity    = EVENPARITY;		// NOPARITY(0), ODDPRITY(1), or EVENPARITY(2)
		dcb.StopBits  = ONESTOPBIT;		// ONESTOPBIT(1) or TWOSTOPBITS(2)
		dcb.ByteSize  = 8;				// 7 or 8
		if (SetCommState(m_rs232cHandle[i], &dcb) == false){
			CloseHandle(m_rs232cHandle[i]);
			m_rs232cHandle[i] = INVALID_HANDLE_VALUE;
			continue;
		}

		// Set 100 milliseconds to receive timeout.
		COMMTIMEOUTS timeout;
		GetCommTimeouts(m_rs232cHandle[i], &timeout);
		timeout.ReadIntervalTimeout = 100;
		timeout.ReadTotalTimeoutConstant = 100;	
		timeout.ReadTotalTimeoutMultiplier = 100;
		SetCommTimeouts(m_rs232cHandle[i], &timeout);
	}
}

// Function to close COM port
void SrRs232cApi_Close()
{
	for (int i = 0; i < SERIAL_PORT_COUNT; i++) {
		CloseHandle(m_rs232cHandle[i]);
		m_rs232cHandle[i] = INVALID_HANDLE_VALUE;
	}
}

// Function to set timing ON
void SrRs232cApi_Lon()
{
	// Send "LON" command.
	// Set STX to command header and ETX to the terminator to distinguish between command respons
	// and read data when receives data from readers.
	char command[] = "\02LON\03";	// <STX>LON<ETX>

	for (int i = 0; i < SERIAL_PORT_COUNT; i++) {
		if (m_rs232cHandle[i] != INVALID_HANDLE_VALUE) {
			DWORD size;
			if (WriteFile(m_rs232cHandle[i], command, strlen(command), &size, NULL) == false) {
				CString s;
				s.Format(_T("%s\r\nCommunication error."), m_portName[i]);		
				AfxMessageBox(s);
				continue;
			}
		}
		else {
			CString s;
			s.Format(_T("%s is disconnected."), m_portName[i]);		
			AfxMessageBox(s);
		}
	}
}

// Function to set timing OFF
void SrRs232cApi_Loff()
{
	// Send "LOFF" command.
	// Set STX to command header and ETX to the terminator to distinguish between command respons
	// and read data when receives data from readers.
	char command[] = "\02LOFF\03";	// <STX>LOFF<ETX>

	for (int i = 0; i < SERIAL_PORT_COUNT; i++) {
		if (m_rs232cHandle[i] != INVALID_HANDLE_VALUE) {
			DWORD size;
			if (WriteFile(m_rs232cHandle[i], command, strlen(command), &size, NULL) == false) {
				CString s;
				s.Format(_T("%s\r\nCommunication error."), m_portName[i]);		
				AfxMessageBox(s);
				continue;
			}
		}
		else {
			CString s;
			s.Format(_T("%s is disconnected."), m_portName[i]);		
			AfxMessageBox(s);
		}
	}
}

// Function to receive data
void SrRs232cApi_Receive()
{
	char recvBytes[RECV_DATA_MAX];
	int recvSize;

	for (int i = 0; i < SERIAL_PORT_COUNT; i++) {
		if (m_rs232cHandle[i] == INVALID_HANDLE_VALUE) {
			CString s;
			s.Format(_T("%s is disconnected."), m_portName[i]);		
			AfxMessageBox(s);
			continue;
		}

		while (true) {
			recvSize = readDataSub(recvBytes, m_rs232cHandle[i]);
			if (recvSize == 0) {
				CString s;
				s.Format(_T("%s has no data."), m_portName[i]);		
				AfxMessageBox(s);
				break;
			}
			if (recvBytes[0] == STX) {
				continue;	// Skip if command response.
			}
			else {
				// Terminating null to handle as string.
				recvBytes[recvSize] = 0;
				CString s;
				s.Format(_T("%s\r\n%s"), m_portName[i], (CString)recvBytes);		
				AfxMessageBox(s);
				break;
			}
		}
	}
}

// Sub function to receive data
static int readDataSub(char *recvBytes, HANDLE handle)
{
	bool isCommandRes = false;	// if data is response to command
	DWORD size;
	char *p = recvBytes;
	char d;

	// Distinguish between command response and read data.
	if (ReadFile(handle, p, 1, &size, NULL)) {
		if (size == 0) {
			return 0;	// No data received.
		}
		else {
			d = *p++;
			if (d == STX) {
				isCommandRes = true;
			}
		}
	}
	else {
		return 0;	// No data received.
	}

	//  Receive data until the terminator character.
	while (true) {
		if (ReadFile(handle, p, 1, &size, NULL)) {
			if (size == 0) {
				AfxMessageBox(_T("Communication error."));
				return 0;
			}
			else {
				d = *p++;
				if (isCommandRes && (d == ETX)) {
					break;	// Command response is received completely.
				}
				else if (d == CR) {
					if (checkDataSize(recvBytes, p - recvBytes)) {
						break;	// Read data is received completely.
					}
				}
			}
		}
		else {
			AfxMessageBox(_T("Communication error."));
			return 0;
		}
	}

	return (p - recvBytes);
}

// check data size
static bool checkDataSize(char *recvBytes, int recvSize)
{
	const int dataSizeLen = 4;

	if (m_binaryDataMode == false)
	{
		return true;
	}

	if (recvSize < dataSizeLen)
	{
		return false;
	}

	int dataSize = 0;
	int mul = 1;
	for (int i = 0; i < dataSizeLen; i++)
	{
		dataSize += (recvBytes[dataSizeLen - 1 - i] - '0') * mul;
		mul *= 10;
	}

	return (dataSize + 1 == recvSize);
}