#pragma once

extern void SrClinetSocket_Init();
extern void SrClientSocket_Connect(int,int);
extern void SrClientSocket_Disconnect();
extern void SrClientSocket_Lon();
extern void SrClientSocket_Loff();
extern void SrClientSocket_Receive();