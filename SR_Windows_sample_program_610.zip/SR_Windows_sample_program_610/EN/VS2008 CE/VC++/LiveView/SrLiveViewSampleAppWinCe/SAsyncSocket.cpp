// SAsyncSocket.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "SrLiveViewSampleApp.h"
#include "SAsyncSocket.h"


// CSAsyncSocket

CSAsyncSocket::CSAsyncSocket()
{
	m_lpCallBack = NULL;
	m_lpParam = NULL;
}

CSAsyncSocket::~CSAsyncSocket()
{
	if(!IsNull()) {
		CAsyncSocket::AsyncSelect(0);
		CAsyncSocket::Close();
	}
}


// CSAsyncSocket �����o�֐�

BOOL CSAsyncSocket::ConnectUdp(WORD wPort,long lEvent,pCbASFunc lpCb,LPVOID lpParam)
{
	BOOL bRet;
	int optval;

	if(!IsNull()) return FALSE;

	bRet = CAsyncSocket::Socket(SOCK_DGRAM,lEvent);
	if(bRet == FALSE) return FALSE;

	optval = SO_REUSEADDR;
	bRet = CAsyncSocket::SetSockOpt(SO_REUSEADDR,(const void*)&optval,sizeof(optval),SOL_SOCKET);
	if(bRet == FALSE) {
		CAsyncSocket::AsyncSelect(0);
		CAsyncSocket::Close();
		return FALSE;
	}

	if(wPort > 0) {
		struct  sockaddr_in	 tSockAddr;
		memset(&tSockAddr, 0, sizeof(tSockAddr));
		tSockAddr.sin_family = AF_INET;
		tSockAddr.sin_addr.S_un.S_addr = INADDR_ANY;
		tSockAddr.sin_port = htons(wPort);
		bRet = CAsyncSocket::Bind((struct sockaddr *)&tSockAddr, sizeof(tSockAddr));
		if(bRet == FALSE) {
			CAsyncSocket::AsyncSelect(0);
			CAsyncSocket::Close();
			return FALSE;
		}
	}

	m_lpCallBack = lpCb;
	m_lpParam = lpParam;

	return TRUE;
}

BOOL CSAsyncSocket::ConnectTcp(DWORD dwAddr,WORD wPort,long lEvent,pCbASFunc lpCb,LPVOID lpParam)
{
	BOOL bRet;
	int optval;

	if(!IsNull()) return FALSE;

	bRet = CAsyncSocket::Socket(SOCK_STREAM,lEvent);
	if(bRet == FALSE) return FALSE;

	optval = SO_REUSEADDR;
	bRet = CAsyncSocket::SetSockOpt(SO_REUSEADDR,(const void*)&optval,sizeof(optval),SOL_SOCKET);
	if(bRet == FALSE) {
		CAsyncSocket::AsyncSelect(0);
		CAsyncSocket::Close();
		return FALSE;
	}

	m_lpCallBack = lpCb;
	m_lpParam = lpParam;

	struct  sockaddr_in	 tSockAddr;
	memset(&tSockAddr, 0, sizeof(tSockAddr));
	tSockAddr.sin_family = AF_INET;
	tSockAddr.sin_addr.s_addr = dwAddr;
	tSockAddr.sin_port = htons(wPort);
	bRet = CAsyncSocket::Connect((struct sockaddr *)&tSockAddr,sizeof(tSockAddr));
	if(bRet == FALSE) {
		int nErr = CAsyncSocket::GetLastError();
		if(nErr != WSAEWOULDBLOCK) {
			CAsyncSocket::AsyncSelect(0);
			CAsyncSocket::Close();
			return FALSE;
		}
		else {
			if(m_lpCallBack != NULL) m_lpCallBack(this,FD_CONNECT,0,m_lpParam);
		}
	}

	return TRUE;
}

BOOL CSAsyncSocket::CloseSocket(void)
{
	if(IsNull()) return FALSE;
	CAsyncSocket::AsyncSelect(0);
	CAsyncSocket::ShutDown(SD_BOTH);
	CAsyncSocket::Close();
	m_lpCallBack = NULL;
	m_lpParam = NULL;
	return TRUE;
}

void CSAsyncSocket::OnAccept(int nErrorCode)
{
	if(m_lpCallBack != NULL) m_lpCallBack(this,FD_ACCEPT,nErrorCode,m_lpParam);
	CAsyncSocket::OnAccept(nErrorCode);
}

void CSAsyncSocket::OnClose(int nErrorCode)
{
	if(m_lpCallBack != NULL) m_lpCallBack(this,FD_CLOSE,nErrorCode,m_lpParam);
	CAsyncSocket::OnClose(nErrorCode);
}

void CSAsyncSocket::OnConnect(int nErrorCode)
{
	if(m_lpCallBack != NULL) m_lpCallBack(this,FD_CONNECT,nErrorCode,m_lpParam);
	CAsyncSocket::OnConnect(nErrorCode);
}

void CSAsyncSocket::OnReceive(int nErrorCode)
{
	if(m_lpCallBack != NULL) m_lpCallBack(this,FD_READ,nErrorCode,m_lpParam);
	CAsyncSocket::OnReceive(nErrorCode);
}

void CSAsyncSocket::OnSend(int nErrorCode)
{
	if(m_lpCallBack != NULL) m_lpCallBack(this,FD_WRITE,nErrorCode,m_lpParam);
	CAsyncSocket::OnSend(nErrorCode);
}
