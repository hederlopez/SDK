#pragma once

// CSAsyncSocket

#pragma once
#include "afxsock.h"

class CSAsyncSocket;
typedef void (CALLBACK* pCbASFunc)(CSAsyncSocket *pSock, long lEvent, int nErrorCode,LPVOID lpParam);


class CSAsyncSocket : public CAsyncSocket
{
public:
	CSAsyncSocket();
	virtual ~CSAsyncSocket();

	BOOL ConnectUdp(WORD wPort,long lEvent,pCbASFunc lpCb,LPVOID lpParam);
	BOOL ConnectTcp(DWORD dwAddr,WORD wPort,long lEvent,pCbASFunc lpCb,LPVOID lpParam);
	BOOL CloseSocket(void);
	BOOL IsNull(void) {return m_hSocket == INVALID_SOCKET;}
	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnSend(int nErrorCode);

protected:
	pCbASFunc	m_lpCallBack;
	LPVOID		m_lpParam;
};


