// Sample program that a server host accepts connection from a SR series reader.

#include <stdio.h>
#include <winsock2.h>
#include "stdafx.h"

#define READER_COUNT	10		// number of readers can be connected
#define RECV_DATA_MAX	10240
#define LISTEN_PORT		9004

static SOCKET s_listenSocket = INVALID_SOCKET;		// socket for listening
static SOCKET s_dataSocket[READER_COUNT];			// sockets for data
static bool s_disconnectRequest;					// request to disconnect

static UINT SrServerSocket_doAccept(LPVOID pParam);


// Function to start listening
void SrServerSocket_Connect()
{
	// Activate winsock.
	WSADATA data;
	WSAStartup(MAKEWORD(2,0), &data);

	struct sockaddr_in src;
	memset(&src, 0, sizeof(src));

	src.sin_port             = htons(LISTEN_PORT);
	src.sin_family           = AF_INET;
	src.sin_addr.S_un.S_addr = INADDR_ANY;

	if (s_listenSocket != INVALID_SOCKET) {
		AfxMessageBox(_T("Already listening."),MB_OK);
		return;
	}

	for (int i = 0; i < READER_COUNT; i++) {
		s_dataSocket[i] = INVALID_SOCKET;
	}

	// Create a new socket and start listening.
	s_listenSocket = socket(AF_INET, SOCK_STREAM, 0);
	bind(s_listenSocket, (struct sockaddr *)&src, sizeof(src));
	listen(s_listenSocket, 5);	// Maximum pending request is 5.

	// Create new thread to accept asynchronously.
	AfxBeginThread(SrServerSocket_doAccept, (LPVOID)0, THREAD_PRIORITY_IDLE);
}

static UINT SrServerSocket_doAccept(LPVOID pParam)
{
	static sockaddr_in dst;
	static int dst_len = sizeof(dst);
	
	s_disconnectRequest = false;

	for (int i = 0; i < READER_COUNT; i++) {
		// Wait for connection from a reader in blocking mode.
		s_dataSocket[i] = accept(s_listenSocket, (struct sockaddr *)&dst, &dst_len);

		if (s_disconnectRequest) {
			return 0;
		}

		CString s;
		s.Format(_T("%S:%d is connected"), inet_ntoa(dst.sin_addr), ntohs(dst.sin_port));		
		AfxMessageBox(s, MB_OK);
	}
	return 0;
}

// Function to stop listening
void SrServerSocket_Disconnect()
{
	s_disconnectRequest = true;

	for (int i = 0; i < READER_COUNT; i++) {
		if (s_dataSocket[i] != INVALID_SOCKET) {
			closesocket(s_dataSocket[i]);
			s_dataSocket[i] = INVALID_SOCKET;
		}
	}

	if (s_listenSocket != INVALID_SOCKET) {
		closesocket(s_listenSocket);
		s_listenSocket = INVALID_SOCKET;
	}

	WSACleanup();
}

// Function to receive data
void SrServerSocket_Receive()
{
	char recvBytes[RECV_DATA_MAX];
	int recvSize = 0;

	for (int i = 0; i < READER_COUNT; i++) {
		// Set 100 milliseconds to receive timeout.
		int timeout = 100;
		if (0 != setsockopt(s_dataSocket[i],	SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout))) {
			CString s;
			s.Format(_T("SO_RCVTIMEO is not supported."));		
			AfxMessageBox(s, MB_OK);
			return;
		}

		if (s_dataSocket[i] != INVALID_SOCKET) {
			recvSize = recv(s_dataSocket[i], recvBytes, sizeof(recvBytes), 0);
		}
		else {
			continue;
		}

		sockaddr_in dst;
		int dst_len = sizeof(dst);
		if (getpeername(s_dataSocket[i], (struct sockaddr *)&dst, &dst_len) != 0) {
			AfxMessageBox(_T("getpeername error"), MB_OK);
			continue;
		}

		if (recvSize > 0) {
			recvBytes[recvSize] = 0;	// Terminating null to handle as string
			CString s;
			s.Format(_T("%S\r\n%S"), inet_ntoa(dst.sin_addr), recvBytes);
			AfxMessageBox(s,MB_ICONINFORMATION,0);
		}
		else {
			CString s;
			s.Format(_T("%S has no data."), inet_ntoa(dst.sin_addr));	
			AfxMessageBox(s, MB_OK);
		}
	}
}

