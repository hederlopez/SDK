// SrEthernetServerSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SrEthernetServerSample.h"
#include "SrEthernetServerSampleDlg.h"
#include "SrServerSocketApi.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSrEthernetServerSampleDlg dialog

CSrEthernetServerSampleDlg::CSrEthernetServerSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrEthernetServerSampleDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSrEthernetServerSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSrEthernetServerSampleDlg, CDialog)
#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
	ON_WM_SIZE()
#endif
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CONNECT, &CSrEthernetServerSampleDlg::OnBnClickedConnect)
	ON_BN_CLICKED(IDC_DISCONNECT, &CSrEthernetServerSampleDlg::OnBnClickedDisconnect)
	ON_BN_CLICKED(IDC_RECEIVE, &CSrEthernetServerSampleDlg::OnBnClickedReceive)
END_MESSAGE_MAP()


// CSrEthernetServerSampleDlg message handlers

BOOL CSrEthernetServerSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

#if defined(_DEVICE_RESOLUTION_AWARE) && !defined(WIN32_PLATFORM_WFSP)
void CSrEthernetServerSampleDlg::OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/)
{
	if (AfxIsDRAEnabled())
	{
		DRA::RelayoutDialog(
			AfxGetResourceHandle(), 
			this->m_hWnd, 
			DRA::GetDisplayMode() != DRA::Portrait ? 
			MAKEINTRESOURCE(IDD_SRETHERNETSERVERSAMPLE_DIALOG) : 
			MAKEINTRESOURCE(IDD_SRETHERNETSERVERSAMPLE_DIALOG));
	}
}
#endif

void CSrEthernetServerSampleDlg::OnBnClickedConnect()
{
	SrServerSocket_Connect();
}

void CSrEthernetServerSampleDlg::OnBnClickedDisconnect()
{
	SrServerSocket_Disconnect();
}

void CSrEthernetServerSampleDlg::OnBnClickedReceive()
{
	SrServerSocket_Receive();
}
