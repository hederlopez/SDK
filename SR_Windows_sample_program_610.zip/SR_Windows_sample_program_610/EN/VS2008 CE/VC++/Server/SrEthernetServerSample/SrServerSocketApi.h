#pragma once

extern void SrServerSocket_Connect();
extern void SrServerSocket_Disconnect();
extern void SrServerSocket_Receive();