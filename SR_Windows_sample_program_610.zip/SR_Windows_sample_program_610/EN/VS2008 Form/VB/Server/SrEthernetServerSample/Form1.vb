﻿Imports System.Text
Imports System.Net
Imports System.Net.Sockets

'
' Sample program that a server host accepts connection from a SR series reader.
'
Public Class Form1
    Private Const READER_COUNT As Integer = 10  ' number of readers can be connected to this host
    Private Const RECV_DATA_MAX As Integer = 10240
    Private Const LISTEN_PORT As Integer = 9004 ' listening port
    Private listenSocket As Socket = Nothing    ' socket for listening
    Private dataSocket() As Socket              ' sockets for data

    '
    ' constructor
    '
    Public Sub New()
        InitializeComponent()
        dataSocket = New Socket(READER_COUNT - 1) {}
    End Sub

    '
    ' handler for "Start Listening" button is clicked
    '
    Private Sub connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connect.Click
        Dim hostDataEndPoint As IPEndPoint = New IPEndPoint(IPAddress.Any, LISTEN_PORT)

        If listenSocket IsNot Nothing Then
            MessageBox.Show("Already listening.")
            Return
        End If

        '
        ' Create a new socket and start listening.
        '
        listenSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
        listenSocket.Bind(hostDataEndPoint)
        listenSocket.Listen(5)  ' Maximum pending request is 5.

        '
        ' Start accepting asynchronously.
        '
        Try
            listenSocket.BeginAccept(New System.AsyncCallback(AddressOf acceptCallback), listenSocket)
        Catch ex As Exception
            MessageBox.Show(ex.Message) ' Error
        End Try
    End Sub

    '
    ' Callback function that is called when new connection is acceptable.
    '
    Private Sub acceptCallback(ByVal ar As System.IAsyncResult)
        If listenSocket Is Nothing Then
            Return
        End If

        Try
            Dim newSocket As Socket
            newSocket = listenSocket.EndAccept(ar)
            '
            ' Set 100 milliseconds to receive timeout.
            '
            newSocket.ReceiveTimeout = 100
            MessageBox.Show(newSocket.RemoteEndPoint.ToString() + " is connected.")

            For i = 0 To READER_COUNT - 1
                If dataSocket(i) Is Nothing Then
                    dataSocket(i) = newSocket
                    '
                    ' Start accepting asynchronously.
                    '
                    listenSocket.BeginAccept(New System.AsyncCallback(AddressOf acceptCallback), listenSocket)
                    Return
                End If
            Next
            newSocket.Close()
        Catch ex As ObjectDisposedException
            '
            ' This exception occures when the listening socket is closed before acception is done.
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message) ' Error
        End Try
    End Sub

    '
    ' handler for "Stop Listening" button is clicked
    '
    Private Sub disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles disconnect.Click
        '
        ' Close the data sockets.
        '
        For i = 0 To READER_COUNT - 1
            If dataSocket(i) IsNot Nothing Then
                dataSocket(i).Close()
                dataSocket(i) = Nothing
            End If
        Next

        '
        ' Close the listening socket.
        '
        If listenSocket IsNot Nothing Then
            listenSocket.Close()
            listenSocket = Nothing
        End If
    End Sub

    '
    ' handler for "Receive Data" button is clicked
    '
    Private Sub receive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles receive.Click
        Dim recvBytes As Byte() = New Byte(RECV_DATA_MAX) {}
        Dim recvSize As Integer = 0

        For i = 0 To READER_COUNT - 1
            If dataSocket(i) IsNot Nothing Then
                Try
                    recvSize = dataSocket(i).Receive(recvBytes)
                Catch ex As SocketException
                    '
                    ' Catch the exception, if cannot receive any data.
                    '
                    recvSize = 0
                End Try
            Else
                Continue For
            End If

            If recvSize = 0 Then
                MessageBox.Show(dataSocket(i).RemoteEndPoint.ToString() + " has no data.")
            Else
                '
                ' Show the receive data after converting the receive data to Shift-JIS.
                ' Terminating null to handle as string.
                '
                recvBytes(recvSize) = 0
                MessageBox.Show(dataSocket(i).RemoteEndPoint.ToString() + vbCrLf + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes))
            End If
        Next
    End Sub
End Class
