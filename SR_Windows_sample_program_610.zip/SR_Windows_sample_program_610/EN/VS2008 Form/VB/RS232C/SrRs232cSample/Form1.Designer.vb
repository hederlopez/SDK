﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.receive = New System.Windows.Forms.Button
        Me.loff = New System.Windows.Forms.Button
        Me.lon = New System.Windows.Forms.Button
        Me.disconnect = New System.Windows.Forms.Button
        Me.connect = New System.Windows.Forms.Button
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.SerialPort2 = New System.IO.Ports.SerialPort(Me.components)
        Me.SuspendLayout()
        '
        'receive
        '
        Me.receive.Location = New System.Drawing.Point(13, 107)
        Me.receive.Name = "receive"
        Me.receive.Size = New System.Drawing.Size(260, 42)
        Me.receive.TabIndex = 24
        Me.receive.Text = "Receive Data"
        Me.receive.UseVisualStyleBackColor = True
        '
        'loff
        '
        Me.loff.Location = New System.Drawing.Point(279, 59)
        Me.loff.Name = "loff"
        Me.loff.Size = New System.Drawing.Size(260, 42)
        Me.loff.TabIndex = 23
        Me.loff.Text = "Timing OFF"
        Me.loff.UseVisualStyleBackColor = True
        '
        'lon
        '
        Me.lon.Location = New System.Drawing.Point(13, 59)
        Me.lon.Name = "lon"
        Me.lon.Size = New System.Drawing.Size(260, 42)
        Me.lon.TabIndex = 22
        Me.lon.Text = "Timing ON"
        Me.lon.UseVisualStyleBackColor = True
        '
        'disconnect
        '
        Me.disconnect.Location = New System.Drawing.Point(279, 11)
        Me.disconnect.Name = "disconnect"
        Me.disconnect.Size = New System.Drawing.Size(260, 42)
        Me.disconnect.TabIndex = 21
        Me.disconnect.Text = "Disconnect"
        Me.disconnect.UseVisualStyleBackColor = True
        '
        'connect
        '
        Me.connect.Location = New System.Drawing.Point(13, 11)
        Me.connect.Name = "connect"
        Me.connect.Size = New System.Drawing.Size(260, 42)
        Me.connect.TabIndex = 20
        Me.connect.Text = "Connect"
        Me.connect.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(553, 161)
        Me.Controls.Add(Me.receive)
        Me.Controls.Add(Me.loff)
        Me.Controls.Add(Me.lon)
        Me.Controls.Add(Me.disconnect)
        Me.Controls.Add(Me.connect)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents receive As System.Windows.Forms.Button
    Private WithEvents loff As System.Windows.Forms.Button
    Private WithEvents lon As System.Windows.Forms.Button
    Private WithEvents disconnect As System.Windows.Forms.Button
    Private WithEvents connect As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents SerialPort2 As System.IO.Ports.SerialPort

End Class
