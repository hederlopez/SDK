﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

'
' Sample program that a client host connects SR series readers.
'
Public Class Form1

    Private Const READER_COUNT As Integer = 2    ' number of readers to connect
    Private Const RECV_DATA_MAX As Integer = 10240
    Private clientSocketInstance() As ClientSocket

    '
    ' Constructor
    '
    Public Sub New()
        InitializeComponent()

        '
        ' Allocate Instances of ClientSocket, and set IP address, command port number and
        ' data port number.
        '
        Dim ipAddress0() As Byte = {192, 168, 100, 100}
        Dim ipAddress1() As Byte = {192, 168, 100, 101}
        CommandPortInput.Text = 9003
        DataPortInput.Text = 9004
        clientSocketInstance = New ClientSocket(READER_COUNT - 1) {}
        clientSocketInstance(0) = New ClientSocket(ipAddress0, CommandPortInput.Text, DataPortInput.Text)
        clientSocketInstance(1) = New ClientSocket(ipAddress1, CommandPortInput.Text, DataPortInput.Text)
    End Sub

    '
    ' handler for "Connect" button is clicked
    '
    Private Sub connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles connect.Click
        For i = 0 To READER_COUNT - 1
            '
            ' Get command port number and data port number from text boxes.
            '
            Try
                clientSocketInstance(i).readerCommandEndPoint.Port = CommandPortInput.Text
                clientSocketInstance(i).readerDataEndPoint.Port = DataPortInput.Text
                '
                ' Connect to the command port.
                '

                '
                ' Close the socket if opened.
                '
                If clientSocketInstance(i).commandSocket IsNot Nothing Then
                    clientSocketInstance(i).commandSocket.Close()
                End If
                '
                ' Create a new socket.
                '
                clientSocketInstance(i).commandSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)

                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + " Connecting.."
                textBox1.Update()

                clientSocketInstance(i).commandSocket.Connect(clientSocketInstance(i).readerCommandEndPoint)

                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + " Connected."
                textBox1.Update()
                '
                ' Catch exceptions.
                '
            Catch ex As ArgumentOutOfRangeException
                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + " Failed to connect."
                textBox1.Update()
                MessageBox.Show(ex.Message)
                clientSocketInstance(i).commandSocket = Nothing
                Return
            Catch ex As SocketException
                '
                ' Catch exceptions and show the message.
                '
                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + " Failed to connect."
                textBox1.Update()
                MessageBox.Show(ex.Message)
                clientSocketInstance(i).commandSocket = Nothing
                Continue For
            End Try
            '
            ' Connect to the data port.
            '
            Try
                '
                ' Close the socket if opened.
                '
                If clientSocketInstance(i).dataSocket IsNot Nothing Then
                    clientSocketInstance(i).dataSocket.Close()
                End If
                '
                ' If the same port number is used for command port and data port, unify the sockets and skip a new connection. 
                '
                If clientSocketInstance(i).readerCommandEndPoint.Port = clientSocketInstance(i).readerDataEndPoint.Port Then
                    clientSocketInstance(i).dataSocket = clientSocketInstance(i).commandSocket
                Else
                    '
                    ' Create a new socket.
                    '
                    clientSocketInstance(i).dataSocket = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                    textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + " Connecting.."
                    textBox1.Update()

                    clientSocketInstance(i).dataSocket.Connect(clientSocketInstance(i).readerDataEndPoint)

                    textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + " Connected."
                    textBox1.Update()
                End If
                '
                ' Set 100 milliseconds to receive timeout.
                '
                clientSocketInstance(i).dataSocket.ReceiveTimeout = 100
            Catch ex As SocketException
                '
                ' Catch exceptions and show the message.
                '
                textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + " Failed to connect."
                textBox1.Update()
                MessageBox.Show(ex.Message)
                clientSocketInstance(i).dataSocket = Nothing
                Continue For
            End Try
        Next i
    End Sub

    '
    ' handler for "Disonnect" button is clicked
    '
    Private Sub disconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles disconnect.Click
        For i = 0 To READER_COUNT - 1
            '
            ' Close the command socket.
            '
            If clientSocketInstance(i).commandSocket IsNot Nothing Then
                clientSocketInstance(i).commandSocket.Close()
                clientSocketInstance(i).commandSocket = Nothing
                textBox1.Text = clientSocketInstance(i).readerCommandEndPoint.ToString() + " Disconnected."
                textBox1.Update()
            End If
            '
            ' Close the data socket.
            '
            If clientSocketInstance(i).dataSocket IsNot Nothing Then
                clientSocketInstance(i).dataSocket.Close()
                clientSocketInstance(i).dataSocket = Nothing
                textBox1.Text = clientSocketInstance(i).readerDataEndPoint.ToString() + " Disconnected."
                textBox1.Update()
            End If
        Next i
    End Sub

    '
    ' handler for "Timing ON" button is clicked
    '
    Private Sub lon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lon.Click
        '
        ' Send "LON" command.
        '
        Dim lon As String = "LON" + vbCr     ' CR is terminator
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(lon)

        For i = 0 To READER_COUNT - 1
            If clientSocketInstance(i).commandSocket IsNot Nothing Then
                clientSocketInstance(i).commandSocket.Send(command)
            Else
                MessageBox.Show(clientSocketInstance(i).readerCommandEndPoint.ToString() + " is disconnected.")
            End If
        Next i
    End Sub

    '
    ' handler for "Timing OFF" button is clicked
    '
    Private Sub loff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loff.Click
        '
        ' Send "LOFF" command.
        '
        Dim loff As String = "LOFF" + vbCr     ' CR is terminator
        Dim command As Byte() = ASCIIEncoding.ASCII.GetBytes(loff)

        For i = 0 To READER_COUNT - 1
            If clientSocketInstance(i).commandSocket IsNot Nothing Then
                clientSocketInstance(i).commandSocket.Send(command)
            Else
                MessageBox.Show(clientSocketInstance(i).readerCommandEndPoint.ToString() + " is disconnected.")
            End If
        Next i
    End Sub

    '
    ' handler for "Receive Data" button is clicked
    '
    Private Sub receive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles receive.Click
        Dim recvBytes As Byte() = New Byte(RECV_DATA_MAX) {}
        Dim recvSize As Integer = 0

        For i = 0 To READER_COUNT - 1
            If clientSocketInstance(i).dataSocket IsNot Nothing Then
                Try
                    recvSize = clientSocketInstance(i).dataSocket.Receive(recvBytes)
                Catch ex As SocketException
                    '
                    ' Catch the exception, if cannot receive any data.
                    '
                    recvSize = 0
                End Try
            Else
                MessageBox.Show(clientSocketInstance(i).readerDataEndPoint.ToString() + " is disconnected.")
                Continue For
            End If

            If recvSize = 0 Then
                MessageBox.Show(clientSocketInstance(i).readerDataEndPoint.ToString() + " has no data.")
            Else
                '
                ' Show the receive data after converting the receive data to Shift-JIS.
                ' Terminating null to handle as string.
                '
                recvBytes(recvSize) = 0
                MessageBox.Show(clientSocketInstance(i).readerDataEndPoint.ToString() + vbCrLf + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes))
            End If
        Next i

    End Sub

    '
    ' Socket class for a reader.
    '
    Public Class ClientSocket
        Public commandSocket As Socket              ' socket for command
        Public dataSocket As Socket                 ' socket for data
        Public readerCommandEndPoint As IPEndPoint
        Public readerDataEndPoint As IPEndPoint

        Public Sub New(ByVal ipAddress() As Byte, ByVal readerCommandPort As Integer, ByVal readerDataPort As Integer)
            Dim readerIpAddress As IPAddress = New IPAddress(ipAddress)
            readerCommandEndPoint = New IPEndPoint(readerIpAddress, readerCommandPort)
            readerDataEndPoint = New IPEndPoint(readerIpAddress, readerDataPort)
            commandSocket = Nothing
            dataSocket = Nothing
        End Sub
    End Class


    '
    ' Reject inputs except numbers in text boxes.
    '
    Private Sub PortInput_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CommandPortInput.KeyPress, DataPortInput.KeyPress
        If (e.KeyChar < "0" Or e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub
End Class
