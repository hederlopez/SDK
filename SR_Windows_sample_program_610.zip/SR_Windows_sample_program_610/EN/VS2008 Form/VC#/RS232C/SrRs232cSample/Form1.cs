﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;

/// <summary>
/// Sample program to connect SR series readers with RS-232C cable.
/// </summary>
namespace SrRs232cSample
{
    public partial class Form1 : Form
    {
        private const Byte STX = 0x02;
        private const Byte ETX = 0x03;
        private const Byte CR = 0x0d;

        private const int SERIAL_PORT_COUNT = 2;    // Number of COM ports used
        private const int RECV_DATA_MAX = 10240;
        private const bool binaryDataMode = false;  // Whether using binary data mode
        private SerialPort[] serialPortInstance;    // Array to store instances of COM ports used

        /// <summary>
        /// Constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            //
            // Set RS-232C parameters.
            //
            this.serialPort1.BaudRate = 115200;         // 9600, 19200, 38400, 57600 or 115200
            this.serialPort1.DataBits = 8;              // 7 or 8
            this.serialPort1.Parity = Parity.Even;    // Even or Odd
            this.serialPort1.StopBits = StopBits.One;   // One or Two
            this.serialPort1.PortName = "COM1";

            this.serialPort2.BaudRate = 115200;         // 9600, 19200, 38400, 57600 or 115200
            this.serialPort2.DataBits = 8;              // 7 or 8
            this.serialPort2.Parity = Parity.Even;    // Even or Odd
            this.serialPort2.StopBits = StopBits.One;   // One or Two
            this.serialPort2.PortName = "COM2";

            //
            // Store COM ports instances in the array.
            //
            serialPortInstance = new SerialPort[SERIAL_PORT_COUNT] { this.serialPort1, this.serialPort2 };
        }

        /// <summary>
        /// handler for "Connect" button is clicked
        /// </summary>
        private void connect_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                try
                {
                    //
                    // Close the COM port if opened.
                    //
                    if (serialPortInstance[i].IsOpen)
                    {
                        this.serialPortInstance[i].Close();
                    }

                    //
                    // Open the COM port.
                    //
                    this.serialPortInstance[i].Open();

                    //
                    // Set 100 milliseconds to receive timeout.
                    //
                    this.serialPortInstance[i].ReadTimeout = 100;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);  // non-existent or disappeared
                }
            }
        }

        /// <summary>
        /// handler for "Disonnect" button is clicked
        /// </summary>
        private void disconnect_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                try
                {
                    this.serialPortInstance[i].Close();
                }
                catch (IOException ex)
                {
                    MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // disappeared
                }
            }
        }

        /// <summary>
        /// handler for "Timing ON" button is clicked
        /// </summary>
        private void lon_Click(object sender, EventArgs e)
        {
            //
            // Send "LON" command.
            // Set STX to command header and ETX to the terminator to distinguish between command respons
            // and read data when receives data from readers.
            // 
            string lon = "\x02LON\x03";   // <STX>LON<ETX>
            Byte[] sendBytes = ASCIIEncoding.ASCII.GetBytes(lon);

            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                if (this.serialPortInstance[i].IsOpen)
                {
                    try
                    {
                        this.serialPortInstance[i].Write(sendBytes, 0, sendBytes.Length);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // disappeared
                    }
                }
                else
                {
                    MessageBox.Show(serialPortInstance[i].PortName + " is disconnected.");
                }
            }
        }

        /// <summary>
        /// handler for "Timing OFF" button is clicked
        /// </summary>
        private void loff_Click(object sender, EventArgs e)
        {
            //
            // Send "LOFF" command.
            // Set STX to command header and ETX to the terminator to distinguish between command respons
            // and read data when receives data from readers.
            // 
            string loff = "\x02LOFF\x03";   // <STX>LOFF<ETX>
            Byte[] sendBytes = ASCIIEncoding.ASCII.GetBytes(loff);

            for (int i = 0; i < serialPortInstance.Length; i++)
            {
                if (this.serialPortInstance[i].IsOpen)
                {
                    try
                    {
                        this.serialPortInstance[i].Write(sendBytes, 0, sendBytes.Length);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // disappeared
                    }
                }
                else
                {
                    MessageBox.Show(serialPortInstance[i].PortName + " is disconnected.");
                }
            }
        }

        /// <summary>
        ///  handler for "Receive Data" button is clicked
        /// </summary>
        private void receive_Click(object sender, EventArgs e)
        {
            Byte[] recvBytes = new Byte[RECV_DATA_MAX];
            int recvSize;

            for (int i = 0; i < this.serialPortInstance.Length; i++)
            {
                if (this.serialPortInstance[i].IsOpen == false)
                {
                    MessageBox.Show(serialPortInstance[i].PortName + " is disconnected.");
                    continue;
                }

                for (; ; )
                {
                    try
                    {
                        recvSize = readDataSub(recvBytes, this.serialPortInstance[i]);
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + ex.Message);    // disappeared
                        break;
                    }
                    if (recvSize == 0)
                    {
                        MessageBox.Show(serialPortInstance[i].PortName + " has no data.");
                        break;
                    }
                    if (recvBytes[0] == STX)
                    {
                        //
                        // Skip if command response.
                        //
                        continue;
                    }
                    else
                    {
                        //
                        // Show the receive data after converting the receive data to Shift-JIS.
                        // Terminating null to handle as string.
                        //
                        recvBytes[recvSize] = 0;
                        MessageBox.Show(serialPortInstance[i].PortName + "\r\n" + Encoding.GetEncoding("Shift_JIS").GetString(recvBytes));
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Sub function to receive data
        /// </summary>
        private int readDataSub(Byte[] recvBytes, SerialPort serialPortInstance)
        {
            int recvSize = 0;
            bool isCommandRes = false;
            Byte d;

            //
            // Distinguish between command response and read data.
            //
            try
            {
                d = (Byte)serialPortInstance.ReadByte();
                recvBytes[recvSize++] = d;
                if (d == STX)
                {
                    isCommandRes = true;    // Distinguish between command response and read data.
                }
            }
            catch (TimeoutException)
            {
                return 0;   //  No data received.
            }

            //
            // Receive data until the terminator character.
            //
            for (; ; )
            {
                try
                {
                    d = (Byte)serialPortInstance.ReadByte();
                    recvBytes[recvSize++] = d;

                    if (isCommandRes && (d == ETX))
                    {
                        break;  // Command response is received completely.
                    }
                    else if (d == CR)
                    {
                        if (checkDataSize(recvBytes, recvSize))
                        {
                            break;  // Read data is received completely.
                        }
                    }
                }
                catch (TimeoutException ex)
                {
                    //
                    // No terminator is received.
                    //
                    MessageBox.Show(ex.Message);
                    return 0;
                }
            }

            return recvSize;
        }

        /// <summary>
        /// check data size
        /// </summary>
        private bool checkDataSize(Byte[] recvBytes, int recvSize)
        {
            const int dataSizeLen = 4;

            if (binaryDataMode == false)
            {
                return true;
            }

            if (recvSize < dataSizeLen)
            {
                return false;
            }

            int dataSize = 0;
            int mul = 1;
            for (int i = 0; i < dataSizeLen; i++)
            {
                dataSize += (recvBytes[dataSizeLen - 1 - i] - '0') * mul;
                mul *= 10;
            }

            return (dataSize + 1 == recvSize);
        }
    }
}
