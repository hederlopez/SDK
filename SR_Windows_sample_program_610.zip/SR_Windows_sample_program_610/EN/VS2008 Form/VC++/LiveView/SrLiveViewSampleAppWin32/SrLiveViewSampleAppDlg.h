// SrLiveViewSampleAppWin32Dlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "SAsyncSocket.h"

// CSrLiveViewSampleAppDlg dialog
class CSrLiveViewSampleAppDlg : public CDialog
{
// Construction
public:
	CSrLiveViewSampleAppDlg(CWnd* pParent = NULL);	// standard constructor
	void CmdCallBack(CSAsyncSocket *pSock, long lEvent, int nErrorCode);
	void DataCallBack(CSAsyncSocket *pSock, long lEvent, int nErrorCode);

// Dialog Data
	enum { IDD = IDD_SRLIVEVIEWSAMPLEAPPWIN32_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	static char szReadData[8192];

	BOOL m_bInit;
	int m_nId;
	unsigned long m_ulAddr;
	CSAsyncSocket m_cTcpCmd;
	CSAsyncSocket m_cTcpData;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	DECLARE_MESSAGE_MAP()
public:
	CStatic m_StaticSample;
	CButton m_BT1;
	CButton m_BT2;
	CButton m_BT3;
	CButton m_BT4;
	CEdit m_EditStatus;
	CEdit m_EditData;
	CButton m_RD3;
	afx_msg void OnClickedRadio3();
	afx_msg void OnClickedButton1();
	afx_msg void OnClickedButton2();
	afx_msg void OnClickedButton3();
	afx_msg void OnClickedButton4();
};
