// SrLiveViewSampleAppWin32Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "SrLiveViewSampleApp.h"
#include "SrLiveViewSampleAppDlg.h"
#include "../../../../../Src/SrLiveViewSample/SrLiveViewSample.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


static void CALLBACK CmdCallBack(CSAsyncSocket *pSock, long lEvent, int nErrorCode,LPVOID lpParam)
{
	CSrLiveViewSampleAppDlg* pWnd = (CSrLiveViewSampleAppDlg*)lpParam;
	pWnd->CmdCallBack(pSock,lEvent,nErrorCode);
}

static void CALLBACK DataCallBack(CSAsyncSocket *pSock, long lEvent, int nErrorCode,LPVOID lpParam)
{
	CSrLiveViewSampleAppDlg* pWnd = (CSrLiveViewSampleAppDlg*)lpParam;
	pWnd->DataCallBack(pSock,lEvent,nErrorCode);
}

char CSrLiveViewSampleAppDlg::szReadData[8192];

CSrLiveViewSampleAppDlg::CSrLiveViewSampleAppDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSrLiveViewSampleAppDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bInit = FALSE;
	m_nId = -1;
	m_ulAddr = 0;
}

void CSrLiveViewSampleAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_SAMPLE, m_StaticSample);
	DDX_Control(pDX, IDC_BUTTON1, m_BT1);
	DDX_Control(pDX, IDC_BUTTON2, m_BT2);
	DDX_Control(pDX, IDC_BUTTON3, m_BT3);
	DDX_Control(pDX, IDC_BUTTON4, m_BT4);
	DDX_Control(pDX, IDC_EDIT1, m_EditStatus);
	DDX_Control(pDX, IDC_EDIT2, m_EditData);
	DDX_Control(pDX, IDC_RADIO3, m_RD3);
}

BEGIN_MESSAGE_MAP(CSrLiveViewSampleAppDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_RADIO3, &CSrLiveViewSampleAppDlg::OnClickedRadio3)
	ON_BN_CLICKED(IDC_BUTTON1, &CSrLiveViewSampleAppDlg::OnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CSrLiveViewSampleAppDlg::OnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CSrLiveViewSampleAppDlg::OnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CSrLiveViewSampleAppDlg::OnClickedButton4)
END_MESSAGE_MAP()


// CSrLiveViewSampleAppDlg message handlers

BOOL CSrLiveViewSampleAppDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	CRect cRect;
	GetClientRect(cRect);
	m_bInit = TRUE;

	OnClickedRadio3();

	// Set IP address of the reader
	m_ulAddr = inet_addr("192.168.100.100");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSrLiveViewSampleAppDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSrLiveViewSampleAppDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSrLiveViewSampleAppDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if(m_bInit) {
		CRect cRect;
		GetClientRect(cRect);
		m_StaticSample.MoveWindow(cRect.left,cRect.top,cRect.Width(),cRect.Height());
	}
}

void CSrLiveViewSampleAppDlg::OnDestroy()
{
	CDialog::OnDestroy();

	m_cTcpCmd.CloseSocket();
	m_cTcpData.CloseSocket();

	if(m_nId >= 0) ReleaseLiveView(m_nId);
}

void CSrLiveViewSampleAppDlg::OnClickedRadio3()
{
	// USB is not supported
	m_RD3.SetCheck(1);
}

void CSrLiveViewSampleAppDlg::OnClickedButton1()
{
	m_EditStatus.SetWindowTextW(_T(""));

	if(m_cTcpCmd.IsNull() && m_cTcpData.IsNull()) {
		// Start to connect the reader
		m_cTcpCmd.ConnectTcp(m_ulAddr,9003,FD_CONNECT|FD_CLOSE|FD_READ|FD_WRITE,::CmdCallBack,this);
		m_cTcpData.ConnectTcp(m_ulAddr,9004,FD_CONNECT|FD_CLOSE|FD_READ|FD_WRITE,::DataCallBack,this);

		if(m_cTcpCmd.IsNull() || m_cTcpData.IsNull()) {
			m_cTcpCmd.CloseSocket();
			m_cTcpData.CloseSocket();
			return;
		}
		m_BT1.SetWindowTextW(_T("Disconnect"));
	}
	else {
		// End the connection
		m_cTcpCmd.CloseSocket();
		m_cTcpData.CloseSocket();
		m_BT1.SetWindowTextW(_T("Connect"));
	}
}

void CSrLiveViewSampleAppDlg::OnClickedButton2()
{
	m_EditStatus.SetWindowTextW(_T(""));

	if (m_nId == -1) {	
		// Start LiveView
		//m_nId = CreateLiveViewW(m_StaticSample.m_hWnd,_T("192.168.10.100"));
		//m_nId = CreateLiveViewA(m_StaticSample.m_hWnd,"192.168.100.100");
		m_nId = CreateLiveViewN(m_StaticSample.m_hWnd, m_ulAddr);
		m_BT2.SetWindowTextW(_T("Stop LiveView"));
	}
	else {	
		// Stop LiveView
		ReleaseLiveView(m_nId);
		m_nId = -1;
		m_BT2.SetWindowTextW(_T("Start LiveView"));
	}
}

void CSrLiveViewSampleAppDlg::CmdCallBack(CSAsyncSocket *pSock, long lEvent, int nErrorCode)
{
	int nRet;

	switch(lEvent) {
		case FD_CLOSE:
			m_cTcpCmd.CloseSocket();
			break;
		case FD_READ:
			nRet = pSock->Receive(szReadData,sizeof(szReadData),0);
			if(nRet >= 0) {
				CString string;
				szReadData[nRet] = 0;
				string = szReadData;
				m_EditStatus.SetWindowText(string);
			}
			break;
		default:
			break;
	}
}

void CSrLiveViewSampleAppDlg::DataCallBack(CSAsyncSocket *pSock, long lEvent, int nErrorCode)
{
	int nRet;

	switch(lEvent) {
		case FD_CLOSE:
			m_cTcpData.CloseSocket();
			break;
		case FD_READ:
			nRet = pSock->Receive(szReadData,sizeof(szReadData),0);
			if(nRet >= 0) {
				CString string;
				szReadData[nRet] = 0;
				string = szReadData;
				m_EditData.SetWindowText(string);
			}
			break;
		default:
			break;
	}
}

void CSrLiveViewSampleAppDlg::OnClickedButton3()
{
	m_EditStatus.SetWindowText(_T(""));
	m_EditData.SetWindowText(_T(""));

	if(!m_cTcpCmd.IsNull()) {
		m_cTcpCmd.Send("LON\r",4,0);
	}
}

void CSrLiveViewSampleAppDlg::OnClickedButton4()
{
	m_EditStatus.SetWindowText(_T(""));
	m_EditData.SetWindowText(_T(""));

	if(!m_cTcpCmd.IsNull()) {
		m_cTcpCmd.Send("LOFF\r",5,0);
	}
}
