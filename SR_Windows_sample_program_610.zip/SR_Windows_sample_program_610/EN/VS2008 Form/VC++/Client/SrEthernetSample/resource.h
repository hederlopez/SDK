//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SrEthernetSample.rc
//
#define IDD_SRETHERNETSAMPLE_DIALOG     102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_CONNECT                     1000
#define IDC_DISCONNECT                  1001
#define IDC_LON                         1002
#define IDC_LOFF                        1003
#define IDC_LON2                        1004
#define IDC_RECEIVE                     1004
#define IDC_EDIT2                       1006
#define IDC_COMMAND                     1006
#define IDC_EDIT3                       1007
#define IDC_DATA                        1007
#define IDC_COMMAND2                    1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
