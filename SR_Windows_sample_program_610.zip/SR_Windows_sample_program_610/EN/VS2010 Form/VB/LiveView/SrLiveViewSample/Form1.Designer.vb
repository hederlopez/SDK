﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.barcodeReaderControl1 = New Keyence.AutoID.BarcodeReaderControl()
        Me.button6 = New System.Windows.Forms.Button()
        Me.textBox3 = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.radioButtonImageErrSave = New System.Windows.Forms.RadioButton()
        Me.radioButtonImageOkSave = New System.Windows.Forms.RadioButton()
        Me.radioButtonImageNoSave = New System.Windows.Forms.RadioButton()
        Me.ComboBoxReader = New System.Windows.Forms.ComboBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'barcodeReaderControl1
        '
        Me.barcodeReaderControl1.BackColor = System.Drawing.Color.Lime
        Me.barcodeReaderControl1.IpAddress = "0.0.0.0"
        Me.barcodeReaderControl1.LiveView.WindowScale = 2
        Me.barcodeReaderControl1.Location = New System.Drawing.Point(14, 16)
        Me.barcodeReaderControl1.Name = "barcodeReaderControl1"
        Me.barcodeReaderControl1.ReaderType = Keyence.AutoID.ReaderType.SR_D100
        Me.barcodeReaderControl1.Size = New System.Drawing.Size(400, 300)
        Me.barcodeReaderControl1.TabIndex = 61
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(208, 328)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(190, 49)
        Me.button6.TabIndex = 57
        Me.button6.Text = "Start LiveView"
        Me.button6.UseVisualStyleBackColor = True
        '
        'textBox3
        '
        Me.textBox3.Location = New System.Drawing.Point(425, 78)
        Me.textBox3.Multiline = True
        Me.textBox3.Name = "textBox3"
        Me.textBox3.ReadOnly = True
        Me.textBox3.Size = New System.Drawing.Size(250, 116)
        Me.textBox3.TabIndex = 55
        Me.textBox3.Text = "IP address = 192.168.100.100" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Command Listenning port = 9003" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Data Listenning" & _
    " Port  = 9004" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(423, 63)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(113, 12)
        Me.label3.TabIndex = 54
        Me.label3.Text = "Reader Configuration"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(12, 546)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(59, 12)
        Me.label2.TabIndex = 53
        Me.label2.Text = "Read Data"
        '
        'textBox2
        '
        Me.textBox2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.textBox2.Location = New System.Drawing.Point(12, 568)
        Me.textBox2.Multiline = True
        Me.textBox2.Name = "textBox2"
        Me.textBox2.ReadOnly = True
        Me.textBox2.Size = New System.Drawing.Size(587, 112)
        Me.textBox2.TabIndex = 52
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(12, 453)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(38, 12)
        Me.label1.TabIndex = 51
        Me.label1.Text = "Status"
        '
        'textBox1
        '
        Me.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.textBox1.Location = New System.Drawing.Point(12, 474)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.ReadOnly = True
        Me.textBox1.Size = New System.Drawing.Size(587, 47)
        Me.textBox1.TabIndex = 50
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(12, 328)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(190, 49)
        Me.button3.TabIndex = 49
        Me.button3.Text = "Connect"
        Me.button3.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(110, 394)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(92, 49)
        Me.button2.TabIndex = 48
        Me.button2.Text = "LOFF"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(12, 394)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(92, 49)
        Me.button1.TabIndex = 47
        Me.button1.Text = "LON"
        Me.button1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ComboBoxReader)
        Me.GroupBox1.Location = New System.Drawing.Point(425, 200)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(122, 111)
        Me.GroupBox1.TabIndex = 62
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Reader Type"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton4)
        Me.GroupBox2.Controls.Add(Me.RadioButton5)
        Me.GroupBox2.Location = New System.Drawing.Point(554, 200)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(122, 111)
        Me.GroupBox2.TabIndex = 63
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Interface"
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Checked = True
        Me.RadioButton4.Location = New System.Drawing.Point(21, 65)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(82, 16)
        Me.RadioButton4.TabIndex = 60
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "ETHERNET"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(21, 43)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(46, 16)
        Me.RadioButton5.TabIndex = 59
        Me.RadioButton5.Text = "USB"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.radioButtonImageErrSave)
        Me.groupBox3.Controls.Add(Me.radioButtonImageOkSave)
        Me.groupBox3.Controls.Add(Me.radioButtonImageNoSave)
        Me.groupBox3.Location = New System.Drawing.Point(425, 328)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(182, 96)
        Me.groupBox3.TabIndex = 65
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Saving Images"
        '
        'radioButtonImageErrSave
        '
        Me.radioButtonImageErrSave.AutoSize = True
        Me.radioButtonImageErrSave.Location = New System.Drawing.Point(7, 65)
        Me.radioButtonImageErrSave.Name = "radioButtonImageErrSave"
        Me.radioButtonImageErrSave.Size = New System.Drawing.Size(82, 16)
        Me.radioButtonImageErrSave.TabIndex = 2
        Me.radioButtonImageErrSave.Text = "Error Image"
        Me.radioButtonImageErrSave.UseVisualStyleBackColor = True
        '
        'radioButtonImageOkSave
        '
        Me.radioButtonImageOkSave.AutoSize = True
        Me.radioButtonImageOkSave.Location = New System.Drawing.Point(7, 42)
        Me.radioButtonImageOkSave.Name = "radioButtonImageOkSave"
        Me.radioButtonImageOkSave.Size = New System.Drawing.Size(72, 16)
        Me.radioButtonImageOkSave.TabIndex = 1
        Me.radioButtonImageOkSave.Text = "OK Image"
        Me.radioButtonImageOkSave.UseVisualStyleBackColor = True
        '
        'radioButtonImageNoSave
        '
        Me.radioButtonImageNoSave.AutoSize = True
        Me.radioButtonImageNoSave.Checked = True
        Me.radioButtonImageNoSave.Location = New System.Drawing.Point(7, 19)
        Me.radioButtonImageNoSave.Name = "radioButtonImageNoSave"
        Me.radioButtonImageNoSave.Size = New System.Drawing.Size(61, 16)
        Me.radioButtonImageNoSave.TabIndex = 0
        Me.radioButtonImageNoSave.TabStop = True
        Me.radioButtonImageNoSave.Text = "Disable"
        Me.radioButtonImageNoSave.UseVisualStyleBackColor = True
        '
        'ComboBoxReader
        '
        Me.ComboBoxReader.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxReader.FormattingEnabled = True
        Me.ComboBoxReader.Location = New System.Drawing.Point(6, 39)
        Me.ComboBoxReader.Name = "ComboBoxReader"
        Me.ComboBoxReader.Size = New System.Drawing.Size(110, 20)
        Me.ComboBoxReader.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 687)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.barcodeReaderControl1)
        Me.Controls.Add(Me.button6)
        Me.Controls.Add(Me.textBox3)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents barcodeReaderControl1 As Keyence.AutoID.BarcodeReaderControl
    Private WithEvents button6 As System.Windows.Forms.Button
    Private WithEvents textBox3 As System.Windows.Forms.TextBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents textBox2 As System.Windows.Forms.TextBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents textBox1 As System.Windows.Forms.TextBox
    Private WithEvents button3 As System.Windows.Forms.Button
    Private WithEvents button2 As System.Windows.Forms.Button
    Private WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Private WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Private WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Private WithEvents groupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents radioButtonImageErrSave As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonImageOkSave As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonImageNoSave As System.Windows.Forms.RadioButton
    Friend WithEvents ComboBoxReader As System.Windows.Forms.ComboBox

End Class
