﻿Imports System.Data
Imports System.ComponentModel
Imports Keyence.AutoID

Class Window1 
    Private WithEvents barcodeReaderControl1 As Keyence.AutoID.BarcodeReaderControl

    Private Sub Grid1_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Grid1.Loaded
        barcodeReaderControl1 = New Keyence.AutoID.BarcodeReaderControl

        Dim dt As DataTable = New DataTable("ReaderTable")
        dt.Columns.Add("Text", Type.GetType("System.String"))
        dt.Columns.Add("Value", GetType(Keyence.AutoID.ReaderType))
        dt.Rows.Add("SR-D100", ReaderType.SR_D100)
        dt.Rows.Add("SR-750", ReaderType.SR_750)
        dt.Rows.Add("SR-1000", ReaderType.SR_1000)
        dt.Rows.Add("SR-2000", ReaderType.SR_2000)

        Me.ComboBoxReader.ItemsSource = (CType(dt, IListSource)).GetList()
        Me.ComboBoxReader.DisplayMemberPath = "Text"
        Me.ComboBoxReader.SelectedValuePath = "Value"
        Me.ComboBoxReader.SelectedIndex = Me.ComboBoxReader.Items.Count - 1
        
        Me.barcodeReaderControl1.BackColor = System.Drawing.Color.Lime
        Me.barcodeReaderControl1.IpAddress = "0.0.0.0"
        Me.barcodeReaderControl1.LiveView.ImageType = Keyence.AutoID.ImageType.JEPG_IMAGE
        Me.barcodeReaderControl1.LiveView.WindowScale = 2
        Me.barcodeReaderControl1.Location = New System.Drawing.Point(12, 12)
        Me.barcodeReaderControl1.Name = "barcodeReaderControl1"
        Me.barcodeReaderControl1.Size = New System.Drawing.Size(400, 300)
        Me.barcodeReaderControl1.TabIndex = 29
        Me.windowsFormsHost1.Child = Me.barcodeReaderControl1
        '
        ' Set the interface to connect the reader
        '
        barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.Ethernet
        '
        ' Set the IP address of the reader to connect
        '
        barcodeReaderControl1.IpAddress = "192.168.100.100"
        '
        ' Set the TCP port number of the reader to connect.
        ' Comannd port number must be different from Data port number
        '
        barcodeReaderControl1.Ether.CommandPort = 9003
        barcodeReaderControl1.Ether.DataPort = 9004
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles button1.Click
        Try
            '
            ' Connect to the Reader
            '
            barcodeReaderControl1.Connect()
            textBox1.Text = "Connected successfulllly"
            If barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.USB Then
                '
                ' Send "SKCLOSE" in order to occupy the data port connection
                '
                barcodeReaderControl1.SKCLOSE()
            Else
                '
                ' Make sure that command response character string is specified.
                '
                Dim val As String = barcodeReaderControl1.RP("610")
                Select Case barcodeReaderControl1.ReaderType
                    Case Keyence.AutoID.ReaderType.SR_2000
                        If val.Equals("1") = False Then
                            textBox1.Text = "Set Baseic command response string to Detailed response."
                        End If
                    Case Keyence.AutoID.ReaderType.SR_1000
                        If val.Equals("1") = False Then
                            textBox1.Text = "Set Baseic command response string to Detailed response."
                        End If
                    Case Keyence.AutoID.ReaderType.SR_700
                        If val.Equals("1") = False Then
                            textBox1.Text = "Set Baseic command response string to Detailed response."
                        End If
                    Case Keyence.AutoID.ReaderType.SR_750
                        If val.Equals("0") = False Then
                            textBox1.Text = "Disable the setting of Specify response character."
                        End If
                    Case Keyence.AutoID.ReaderType.SR_D100
                        If val.Equals("0") = False Then
                            textBox1.Text = "Disable the setting of Specify response character."
                        End If
                End Select
            End If
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles button2.Click
        Try
            '
            ' Start processing of LiveView
            '
            barcodeReaderControl1.StartLiveView()
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles button3.Click
        textBox1.Text = ""
        Try
            '
            ' Send LON command
            '
            barcodeReaderControl1.LON()
        Catch cex As Keyence.AutoID.CommandException
            '
            ' ExtErrCode shows the number of command error
            '
            textBox1.Text = "Command err," & cex.ExtErrCode
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub button4_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles button4.Click
        textBox1.Text = ""
        Try
            '
            ' Send LOFF command
            '
            barcodeReaderControl1.LOFF()
        Catch ex As Exception
            textBox1.Text = ex.Message
        End Try
    End Sub

    Private Sub OnDataReceived(ByVal sender As System.Object, ByVal e As Keyence.AutoID.OnDataReceivedEventArgs) Handles barcodeReaderControl1.OnDataReceived
        '
        ' Delegate display processing of the received data to the textBox
        '
        textBox2.Dispatcher.Invoke(New updateTextBoxDelegate(AddressOf updateTextBox), e.data)
    End Sub

    Private Delegate Sub updateTextBoxDelegate(ByVal data As Byte())

    Private Sub updateTextBox(ByVal data As Byte())
        '
        ' Display the received data to the textBox 
        '
        textBox2.Text = System.Text.Encoding.GetEncoding("Shift_JIS").GetString(data)

        '
        '  Image file saving process 
        '
        Dim saveImage As Boolean
        If textBox2.Text.StartsWith("ERROR") Then
            saveImage = radioButtonImageErrSave.IsChecked.Value
        Else
            saveImage = radioButtonImageOkSave.IsChecked.Value
        End If
        If (saveImage) Then
            Try
                '
                ' Get file path of saved file
                '
                Dim srcFile As String = barcodeReaderControl1.LSIMG()
                Dim dstFile As String = srcFile.Split("\")(2)
                '
                ' Get file path of saved file
                '
                barcodeReaderControl1.GetFile(srcFile, dstFile)
                MessageBox.Show(dstFile, "Image file")
            Catch ex As Exception
                textBox1.Text = ex.Message
            End Try
        End If
    End Sub

    Private Sub radioButton5_Checked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles radioButton5.Checked
        barcodeReaderControl1.StopLiveView()
        barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.USB
    End Sub

    Private Sub radioButton6_Checked(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles radioButton6.Checked
        barcodeReaderControl1.StopLiveView()
        barcodeReaderControl1.Comm.Interface = Keyence.AutoID.Interface.Ethernet
    End Sub

    Private Sub comboBoxReader_SelectionChanged(ByVal sender As System.Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs) Handles ComboBoxReader.SelectionChanged
        barcodeReaderControl1.StopLiveView()

        '
        ' Set the type of reader to connect
        '
        barcodeReaderControl1.ReaderType = ComboBoxReader.SelectedValue

    End Sub
End Class
