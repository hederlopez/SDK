#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int WINAPI CreateLiveViewN(HWND hWnd, unsigned long ulAddr);
int WINAPI CreateLiveViewA(HWND hWnd, LPCSTR lpAddr);
int WINAPI CreateLiveViewW(HWND hWnd, LPCWSTR lpAddr);
BOOL WINAPI ReleaseLiveView(int nId);


#ifdef __cplusplus
}
#endif
