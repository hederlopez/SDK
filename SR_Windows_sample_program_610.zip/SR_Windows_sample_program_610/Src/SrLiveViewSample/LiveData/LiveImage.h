#pragma once

#include "../image/FrameImage.h"
#include "../LiveView/LiveCtrl.h"
#include "../LiveView/LiveView.h"

#define	IMAGE_BACK_COLOR	RGB(0,128,128)
#define	CODE_LINE_WEIGHT	3
#define	CODE_LINE_COLOR		RGB(0,255,0)

typedef struct _TCODEPOINTS {
	POINT tVertex[4];
	POINT tCenter;
} TCODEPOINTS;

class CLiveImage : public CFrameImage
{
public:
	CLiveImage(void);
	~CLiveImage(void);
	BOOL SetLiveData(RECVIMAGE *pImage);
	void SetBinningTbl(SIZE *pBinTbl,int nSize) {m_pBinTbl = pBinTbl; m_nBinMax = nSize;};
	void SetDrawFrame(BOOL bFrame) {m_bFrame = bFrame;}
	void SetDrawFixAspectRatio(BOOL bFAR) {m_bFixAspectRatio = bFAR;}

	virtual void ClearImage(void);

	void SetImageBackColor(COLORREF colBak);
	void SetCodeColor(COLORREF colCode);

	int GetDecodeResult(void) {return m_nDecRes;}

	void Lock(void) {if(m_pCSLv!=NULL)EnterCriticalSection(m_pCSLv);}
	void Unlock(void) {if(m_pCSLv!=NULL)LeaveCriticalSection(m_pCSLv);}

	void Draw(HDC hDstDc,int nDstW, int nDstH);

protected:
	void DrawCode(HDC hDstDc, int nDstX, int nDstY, int nDstW, int nDstH, BOOL bFrame);
	void DrawCodeLine(HDC hDc, TCODEPOINTS *pPt, double x, double y, double ox, double oy, int s, int n);

protected:
	LPCRITICAL_SECTION m_pCSLv;
	SIZE	*m_pBinTbl;
	int		m_nBinMax;

	int		m_nDecRes;
	int		m_nCodeCnt;
	TCODEPOINTS	m_tPoints[CODE_MAX_COUNT];

	HPEN		m_hImageBackPen;
	HBRUSH		m_hImageBackBrush;
	HPEN		m_hCodePen;
	HBRUSH		m_hCodeBrush;
	BOOL		m_bFrame;
	BOOL		m_bFixAspectRatio;
};
