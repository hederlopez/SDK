#include "StdAfx.h"
#include "LiveImage.h"

/*!
	Constructor
    @return None
*/
CLiveImage::CLiveImage(void)
{
	m_pCSLv = new CRITICAL_SECTION;
	if(m_pCSLv != NULL) InitializeCriticalSection(m_pCSLv);

	m_pBinTbl = NULL;
	m_nBinMax = 0;

	m_nDecRes = 2;
	m_nCodeCnt = 0;
	memset(m_tPoints,0,sizeof(m_tPoints));

	m_hImageBackPen =  ::CreatePen(PS_SOLID,1,IMAGE_BACK_COLOR);
	m_hImageBackBrush = CreateSolidBrush(IMAGE_BACK_COLOR);;
	m_hCodePen = ::CreatePen(PS_SOLID,CODE_LINE_WEIGHT,CODE_LINE_COLOR);
	m_hCodeBrush = CreateSolidBrush(CODE_LINE_COLOR);

	m_bFrame = FALSE;
	m_bFixAspectRatio = TRUE;
}

/*!
	Destructor
    @return None
*/
CLiveImage::~CLiveImage(void)
{
	if( m_pCSLv != NULL ) {
		DeleteCriticalSection(m_pCSLv);
		delete m_pCSLv;
		m_pCSLv = NULL;
	}

	if(m_hImageBackPen != NULL) {
		DeleteObject(m_hImageBackPen);
		m_hImageBackPen = NULL;
	}
	if(m_hImageBackBrush != NULL) {
		DeleteObject(m_hImageBackBrush);
		m_hImageBackBrush = NULL;
	}
	if(m_hCodePen != NULL) {
		DeleteObject(m_hCodePen);
		m_hCodePen = NULL;
	}
	if(m_hCodeBrush != NULL) {
		DeleteObject(m_hCodeBrush);
		m_hCodeBrush = NULL;
	}
}

/*!
   Analyze the data packet
    @param[in] pImage : image data
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveImage::SetLiveData(RECVIMAGE *pImage)
{
	int i,j;

	//************** Data Packet **************
	i = pImage->nImageBining;
	if(i < 0 || i >= m_nBinMax) return FALSE;
	if(pImage->nImageWidth  < 0 || pImage->nImageWidth  > m_pBinTbl[i].cx )  return FALSE;
	if(pImage->nImageHeight < 0 || pImage->nImageHeight > m_pBinTbl[i].cy )  return FALSE;
	if(pImage->nImageLeft   < 0 || pImage->nImageLeft   > m_pBinTbl[i].cx-1 ) return FALSE;
	if(pImage->nImageTop    < 0 || pImage->nImageTop    > m_pBinTbl[i].cy-1 ) return FALSE;

	m_nDecRes = pImage->nDecodeResult;
	m_nCodeCnt = pImage->nCodeCount;

	for(j=0;j<m_nCodeCnt;j++) {
		m_tPoints[j].tVertex[0].x  = pImage->tPoints[j].tVertex[0].x;	// X1
		m_tPoints[j].tVertex[0].y  = pImage->tPoints[j].tVertex[0].y;	// Y1
		m_tPoints[j].tVertex[1].x  = pImage->tPoints[j].tVertex[1].x;	// X2
		m_tPoints[j].tVertex[1].y  = pImage->tPoints[j].tVertex[1].y;	// Y2
		m_tPoints[j].tVertex[2].x  = pImage->tPoints[j].tVertex[2].x;	// X3
		m_tPoints[j].tVertex[2].y  = pImage->tPoints[j].tVertex[2].y;	// Y3
		m_tPoints[j].tVertex[3].x  = pImage->tPoints[j].tVertex[3].x;	// X4
		m_tPoints[j].tVertex[3].y  = pImage->tPoints[j].tVertex[3].y;	// Y4
		m_tPoints[j].tCenter.x     = pImage->tPoints[j].tCenter.x;		// CX
		m_tPoints[j].tCenter.y	   = pImage->tPoints[j].tCenter.y;		// CY
			/*TRACE(_T("%d,%d\n%d,%d\n%d,%d\n%d,%d\n%d,%d\n"),
			m_tPoints[j].tVertex[0].x,m_tPoints[j].tVertex[0].y,
			m_tPoints[j].tVertex[1].x,m_tPoints[j].tVertex[1].y,
			m_tPoints[j].tVertex[2].x,m_tPoints[j].tVertex[2].y,
			m_tPoints[j].tVertex[3].x,m_tPoints[j].tVertex[3].y,
			m_tPoints[j].tCenter.x,m_tPoints[j].tCenter.y);*/
	}

	int nFmt,nIW,nIH,nImgSize;

	nFmt = pImage->nImageFormat;
	m_nFrameWidth = m_pBinTbl[i].cx;
	m_nFrameHeight = m_pBinTbl[i].cy;
	nIW = pImage->nImageWidth;
	nIH = pImage->nImageHeight;
	m_nImageX = pImage->nImageLeft;
	m_nImageY = pImage->nImageTop;
	nImgSize  = pImage->nImageSize;

	BYTE *pImg = pImage->pImageData;

	MITYPE eITyp = IMGM_TYPE_NONE;
	if(nFmt == LIV_IMG_JPEG) eITyp = IMGM_TYPE_JPEG;
	else eITyp = IMGM_TYPE_GRAY;

	BOOL bRes = SetMemImage(pImg,nImgSize,nIW,nIH,eITyp);

	return bRes;
}

/*!
   Draw on the device context
    @param[in] hDstDc : Handle of the device context
    @param[in] nDstW  : the width
    @param[in] nDstH  : the height
    @return ����
*/
void CLiveImage::Draw(HDC hDstDc,int nDstW, int nDstH)
{
	if(IsEmpty() == TRUE) {
		HPEN hOldPen = (HPEN)::SelectObject(hDstDc,m_hBackPen);
		HBRUSH hOldBrush = (HBRUSH)::SelectObject(hDstDc,m_hBackBrush);
		::Rectangle(hDstDc,0,0,nDstW-1,nDstH-1);
		::SelectObject(hDstDc,hOldPen);
		::SelectObject(hDstDc,hOldBrush);
		return;
	}

	Decode();

	int nDstX,nDstY;
	int nXD,nYD,nWD,nHD,nWF,nHF;
	if(m_bFrame == TRUE) {
		double ax = (double)nDstW/(double)m_nFrameWidth;
		double ay = (double)nDstH/(double)m_nFrameHeight;
		if(m_bFixAspectRatio == TRUE) {
			if(ax < ay) ay = ax;
			else ax = ay;
		}
		nXD = (int)(m_nImageX*ax);
		nYD = (int)(m_nImageY*ay);
		nWD = (int)(m_nWidth*ax);
		nHD = (int)(m_nHeight*ay);
		nWF = (int)(m_nFrameWidth*ax);
		nHF = (int)(m_nFrameHeight*ay);
		nDstX = 0;
		nDstY = 0;
		if(m_bFixAspectRatio == TRUE) {
			nXD = nXD + (nDstW - nWF) / 2;
			nYD = nYD + (nDstH - nHF) / 2;
			nDstX = (nDstW - nWF) / 2;
			nDstY = (nDstH - nHF) / 2;
			nDstW = nWF;
			nDstH = nHF;
		}
	}
	else {
		double ax = (double)nDstW/(double)m_nWidth;
		double ay = (double)nDstH/(double)m_nHeight;
		if(m_bFixAspectRatio == TRUE) {
			if(ax < ay) ay = ax;
			else ax = ay;
		}
		nXD = 0;
		nYD = 0;
		nWD = (int)(m_nWidth*ax);
		nHD = (int)(m_nHeight*ay);
		nWF = (int)(m_nFrameWidth*ax);
		nHF = (int)(m_nFrameHeight*ay);
		nDstX = 0;
		nDstY = 0;
		if(m_bFixAspectRatio == TRUE) {
			nXD = (nDstW - nWD) / 2;
			nYD = (nDstH - nHD) / 2;
			nDstX = nXD;
			nDstY = nYD;
			nDstW = nWD;
			nDstH = nHD;
		}
	}

	if(m_bFixAspectRatio == TRUE && (nDstX > 0 || nDstY > 0)) {
		HPEN hOldPen = (HPEN)::SelectObject(hDstDc,m_hBackPen);
		HBRUSH hOldBrush = (HBRUSH)::SelectObject(hDstDc,m_hBackBrush);
		if(nDstX > 0) {
			::Rectangle(hDstDc,0,0,nDstX,nDstH-1);
			::Rectangle(hDstDc,nDstX+nDstW-1,0,nDstX+nDstW-1+nDstX,nDstH-1);
		}
		if(nDstY > 0) {
			::Rectangle(hDstDc,0,0,nDstW-1,nDstY);
			::Rectangle(hDstDc,0,nDstY+nDstH-1,nDstW-1,nDstY+nDstH-1+nDstY);
		}
		::SelectObject(hDstDc,hOldPen);
		::SelectObject(hDstDc,hOldBrush);
	}

	if(m_bFrame == TRUE && ((nXD-nDstX) > 0 || (nYD-nDstY) > 0 || (nWF-(nXD-nDstX)-nWD) > 0 || (nHF-(nYD-nDstY)-nHD) > 0)) {
		HPEN hOldPen = (HPEN)::SelectObject(hDstDc,m_hImageBackPen);
		HBRUSH hOldBrush = (HBRUSH)::SelectObject(hDstDc,m_hImageBackBrush);
		if(nXD > 0) ::Rectangle(hDstDc,nDstX,nYD,nXD,nYD+nHD-1);
		if((nWF-nXD-nWD+nDstX) > 0) ::Rectangle(hDstDc,nXD+nWD-1,nYD,nWF+nDstX-1,nYD+nHD-1);
		if(nYD > 0) ::Rectangle(hDstDc,nDstX,nDstY,nWF+nDstX-1,nYD);
		if((nHF-nYD-nHD+nDstY) > 0) ::Rectangle(hDstDc,nDstX,nYD+nHD-1,nWF+nDstX-1,nHF+nDstY-1);
		::SelectObject(hDstDc,hOldPen);
		::SelectObject(hDstDc,hOldBrush);
	}

	::StretchBlt(hDstDc,nXD,nYD,nWD,nHD,
				m_hDc,0,0,m_nWidth,m_nHeight, SRCCOPY);

	DrawCode(hDstDc, nDstX, nDstY, nDstW, nDstH, m_bFrame);
}

/*!
   Draw the code frame
    @param[in] hDstDc : handle of the device context
    @param[in] nDstX  : X-axis offset
    @param[in] nDstY  : Y-axis offset
    @param[in] nDstW  : width of the frame
    @param[in] nDstH  : hegiht of the frame
    @param[in] bFrame : if frame is
    @return ����
*/
void CLiveImage::DrawCode(HDC hDstDc, int nDstX, int nDstY, int nDstW, int nDstH, BOOL bFrame) 
{
	int i,typ;
	HPEN hOldPen = (HPEN)::SelectObject(hDstDc,m_hCodePen);
	HBRUSH hOldBrush = (HBRUSH)::SelectObject(hDstDc,m_hCodeBrush);

	double dOftX,dOftY;
	double dMX,dMY;
	if(bFrame == TRUE) {
		dMX = (double)nDstW/(double)m_nFrameWidth;
		dMY = (double)nDstH/(double)m_nFrameHeight;
		dOftX = -1*nDstX;
		dOftY = -1*nDstY;
	}
	else {
		dMX = (double)nDstW/(double)m_nWidth;
		dMY = (double)nDstH/(double)m_nHeight;
		dOftX = -1*nDstX + m_nImageX*dMX;
		dOftY = -1*nDstY + m_nImageY*dMY;
	}

	for(i=0;i<m_nCodeCnt;i++) {
		typ = 0;
		if(m_tPoints[i].tVertex[0].x >= 0) typ |= 1;
		if(m_tPoints[i].tVertex[1].x >= 0) typ |= 2;
		if(m_tPoints[i].tVertex[2].x >= 0) typ |= 4;
		if(m_tPoints[i].tVertex[3].x >= 0) typ |= 8;

		switch(typ) {
		case 15: DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,0,4); break;

		case 7:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,0,3); break;
		case 14: DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,1,3); break;
		case 13: DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,2,3); break;
		case 11: DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,3,3); break;

		case 3:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,0,2); break;
		case 6:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,1,2); break;
		case 12: DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,2,2); break;
		case 9:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,3,2); break;

		case 5:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,0,5); break;
		case 10: DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,1,5); break;

		case 1:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,0,1); break;
		case 2:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,1,1); break;
		case 4:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,2,1); break;
		case 8:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,3,1); break;

		case 0:  DrawCodeLine(hDstDc,&m_tPoints[i],dMX,dMY,dOftX,dOftY,3,0); break;

		default: break;

		}
	}
	::SelectObject(hDstDc,hOldPen);
	::SelectObject(hDstDc,hOldBrush);
}

/*!
   Draw the line of code area
    @param[in] hDc   : handle of the devic context
    @param[in] pPt   : coordinations of the code
    @param[in] dMX   : X-axis ratio
    @param[in] dMY   : Y-axis ratio
    @param[in] dOftX : X-axis offset
    @param[in] dOftY : Y-axis offset
    @param[in] s     : line number
    @param[in] n     : draw pattern
    @return None
*/
inline void CLiveImage::DrawCodeLine(HDC hDc, TCODEPOINTS *pPt, double dMX, double dMY, double dOftX, double dOftY, int s, int n) 
{
	RECT tRc;

	if(n == 4) {
		::MoveToEx(hDc,(int)((pPt->tVertex[0].x)*dMX-dOftX),(int)((pPt->tVertex[0].y)*dMY-dOftY),NULL);
		::LineTo(hDc,(int)((pPt->tVertex[1].x)*dMX-dOftX),(int)((pPt->tVertex[1].y)*dMY-dOftY));
		::LineTo(hDc,(int)((pPt->tVertex[2].x)*dMX-dOftX),(int)((pPt->tVertex[2].y)*dMY-dOftY));
		::LineTo(hDc,(int)((pPt->tVertex[3].x)*dMX-dOftX),(int)((pPt->tVertex[3].y)*dMY-dOftY));
		::LineTo(hDc,(int)((pPt->tVertex[0].x)*dMX-dOftX),(int)((pPt->tVertex[0].y)*dMY-dOftY));
	}
#if 0
	if(n == 3) {
		::MoveToEx(hDc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),NULL);
		s = (s + 1) & 3;
		::LineTo(hDc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		s = (s + 1) & 3;
		::LineTo(hDc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
	}
	if(n == 2) {
		::MoveToEx(hDc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),NULL);
		s = (s + 1) & 3;
		::LineTo(hDc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
	}
#else
	if(n == 3) {
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
		s = (s + 1) & 3;
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
		s = (s + 1) & 3;
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
	}
	if(n == 2) {
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
		s = (s + 1) & 3;
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
	}
#endif
	if(n == 5) {
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
		s = (s + 2) & 3;
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
	}
	if(n == 1) {
		::SetRect(&tRc,(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY),(int)((pPt->tVertex[s].x)*dMX-dOftX),(int)((pPt->tVertex[s].y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Rectangle(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
	}
	if(n != 4) {
		::SetRect(&tRc,(int)((pPt->tCenter.x)*dMX-dOftX),(int)((pPt->tCenter.y)*dMY-dOftY),(int)((pPt->tCenter.x)*dMX-dOftX),(int)((pPt->tCenter.y)*dMY-dOftY));
		::InflateRect(&tRc,3,3);
		::Ellipse(hDc,tRc.left,tRc.top,tRc.right,tRc.bottom);
	}
}

/*!
   Clea the data
    @return None
*/
void CLiveImage::ClearImage(void)
{
	m_nDecRes  = LIV_DECODE_NONE;
	m_nCodeCnt = 0;
	CFrameImage::ClearImage();
}

/*!
   Set the backround color
    @param[in] colBak : background color
    @return None
*/
void CLiveImage::SetImageBackColor(COLORREF colBak)
{
	if(m_hImageBackPen != NULL) {
		DeleteObject(m_hImageBackPen);
		m_hImageBackPen = NULL;
	}
	m_hImageBackPen =  ::CreatePen(PS_SOLID,1,colBak);

	if(m_hImageBackBrush != NULL) {
		DeleteObject(m_hImageBackBrush);
		m_hImageBackBrush = NULL;
	}
	m_hImageBackBrush = CreateSolidBrush(colBak);;
}

/*!
   Set the color of the code
    @param[in] colCode : color of the code
    @return ����
*/
void CLiveImage::SetCodeColor(COLORREF colCode)
{
	if(m_hCodePen != NULL) {
		DeleteObject(m_hCodePen);
		m_hCodePen = NULL;
	}
	m_hCodePen = ::CreatePen(PS_SOLID,CODE_LINE_WEIGHT,colCode);

	if(m_hCodeBrush != NULL) {
		DeleteObject(m_hCodeBrush);
		m_hCodeBrush = NULL;
	}
	m_hCodeBrush = CreateSolidBrush(colCode);
}
