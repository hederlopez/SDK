#include "StdAfx.h"
#include "LiveInfo.h"

/*!
	Constructor
    @return None
*/
CLiveInfo::CLiveInfo(void)
{
	m_nMode = 0;
	m_nTrigerNo = 0;
	m_nImageCont = 0;
	m_nBank = 0;
	m_nBstScNo = 0;
	m_bEnable = FALSE;
	m_pCSLv = new CRITICAL_SECTION;
	if(m_pCSLv != NULL) InitializeCriticalSection(m_pCSLv);
}

/*!
	Destructor
    @return None
*/
CLiveInfo::~CLiveInfo(void)
{
	if( m_pCSLv != NULL ) {
		DeleteCriticalSection(m_pCSLv);
		delete m_pCSLv;
		m_pCSLv = NULL;
	}
}

/*!
   Analyze the packet of start of sending image
    @param[in] pInfo : data
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveInfo::SetLiveData(RECVINFO *pInfo)
{
	//************** Packet of start of sending image **************
	m_nMode = 0;
	m_nTrigerNo = 0;
	m_nImageCont = 0;
	m_nBank = 0;
	m_nBstScNo = 0;

	m_nMode = pInfo->nMode;	

	m_nTrigerNo = pInfo->nTrigerNumber;

	m_nImageCont = pInfo->nImageCont;

	m_nBank = pInfo->nBank;

	m_nBstScNo = pInfo->nBstOk;

	m_bEnable = TRUE;

	return TRUE;
}

/*!
   Clear data
    @return None
*/
void CLiveInfo::ClearInfo(void)
{
	m_nMode = 0;
	m_nTrigerNo = 0;
	m_nImageCont = 0;
	m_nBank = 0;
	m_nBstScNo = 0;
	m_bEnable = FALSE;
};
