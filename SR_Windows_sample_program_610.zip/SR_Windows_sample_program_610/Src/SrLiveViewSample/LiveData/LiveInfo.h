#pragma once
#include "../LiveView/LiveCtrl.h"

class CLiveInfo {
public:
	CLiveInfo(void);
	~CLiveInfo(void);

	BOOL SetLiveData(RECVINFO *pInfo);

	void ClearInfo(void);

	int GetReadMode(void) {return m_nMode;}
	int GetTrigerNumber(void) {return m_nTrigerNo;}
	int GetReadBankNumber(void) {return m_nBank;}
	int GetBurstImageCount(void) {return m_nImageCont;}
	int GetBurstImageNumber(void) {return m_nBstScNo;}

	BOOL IsEmpty(void) {return m_bEnable;}

	void Lock(void) {if(m_pCSLv!=NULL)EnterCriticalSection(m_pCSLv);}
	void Unlock(void) {if(m_pCSLv!=NULL)LeaveCriticalSection(m_pCSLv);}

protected:
	int		m_nMode;
	int		m_nTrigerNo;
	int		m_nImageCont;
	int		m_nBank;
	int		m_nBstScNo;
	LPCRITICAL_SECTION m_pCSLv;
	BOOL	m_bEnable;
};
