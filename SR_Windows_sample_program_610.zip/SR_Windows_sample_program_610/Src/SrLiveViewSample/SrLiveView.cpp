#include "StdAfx.h"
#include "SrLiveView.h"

CSrLiveView*  CSrLiveView::s_pInstance = NULL;

SIZE BinningSize750[SR750_IMG_BINNING_MAX] = {
	{SR750_IMG_WIDTH,SR750_IMG_HEIGHT},
	{SR750_IMG_WIDTH/2,SR750_IMG_HEIGHT/2},
	{SR750_IMG_WIDTH/3,SR750_IMG_HEIGHT/3},
	{SR750_IMG_WIDTH/4,SR750_IMG_HEIGHT/4}
};

SIZE BinningSize1000[SR1000_IMG_BINNING_MAX] = {
	{SR1000_IMG_WIDTH,SR1000_IMG_HEIGHT},
	{SR1000_IMG_WIDTH/2,SR1000_IMG_HEIGHT/2},
	{SR1000_IMG_WIDTH/3,SR1000_IMG_HEIGHT/3},
	{SR1000_IMG_WIDTH/4,SR1000_IMG_HEIGHT/4}
};

SIZE BinningSize2000[SR2000_IMG_BINNING_MAX] = {
	{SR2000_IMG_WIDTH,SR2000_IMG_HEIGHT},
	{SR2000_IMG_WIDTH/2,SR2000_IMG_HEIGHT/2},
	{SR2000_IMG_WIDTH/3,SR2000_IMG_HEIGHT/3},
	{SR2000_IMG_WIDTH/4,SR2000_IMG_HEIGHT/4}
};

CSrLiveView::CSrLiveView(void)
{
	InitializeCriticalSection(&m_tCSLock);
	int i;
	for(i=0;i<MAX_LVIEW;i++) {
		m_LView[i].bUse = FALSE;
		m_LView[i].hWnd = NULL;
		m_LView[i].ulAddr = 0;
		m_LView[i].fncOrgWnd = NULL;
		m_LView[i].pLiveCtrl = NULL;
		m_LView[i].pLiveInfo = NULL;
		m_LView[i].pLiveImage = NULL;
		m_LView[i].pPaintBuffer = NULL;
		m_LView[i].pUdpCtrl = NULL;
		m_LView[i].pCSLock = &m_tCSLock;
		m_LView[i].szType[0] = 0;
	}
	m_nLView = 0;
	m_pMontor = new CMonUdpCtrl;
}

CSrLiveView::~CSrLiveView(void)
{
	int i;
	for(i=0;i<MAX_LVIEW;i++) ReleaseLiveView(i);

	if(m_pMontor != NULL) {
		m_pMontor->Stop();
		delete m_pMontor;
		m_pMontor = NULL;
	}
	DeleteCriticalSection(&m_tCSLock);
}

void CALLBACK CSrLiveView::UdpCallBack(LPVOID lpParam, struct sockaddr_in *pAddr, BYTE *lpData, DWORD dwSize)
{
	if(dwSize > CHECK_RES_LEN) {
		if(memcmp(lpData,CHECK_RESULT,CHECK_RES_LEN) == 0) {
			int i,j;
			char szNead[LV_MAX_TYPELEN];
			memset(szNead,0,sizeof(szNead));
			for(i=0,j=CHECK_RES_LEN+1;i<_countof(szNead)-1&&j<(int)dwSize;i++,j+=2) {
				if(lpData[j] == ',') break;
				szNead[i] = lpData[j];
			}

			LVIEW *pLView = (LVIEW*)lpParam;

			EnterCriticalSection(pLView->pCSLock);

			if(pLView != NULL) {
				if(pLView->bUse == TRUE) {
					strncpy_s(pLView->szType,_countof(pLView->szType),szNead,_countof(pLView->szType));
					::PostMessage(pLView->hWnd,WM_DEVICEON,(WPARAM)pLView->szType,0);
				}
			}

			LeaveCriticalSection(pLView->pCSLock);
		}
	}
}

void CALLBACK  CSrLiveView::LiveCallBack(LPVOID lpParam, LPVOID lpData, CBST eEvent)
{
	LVIEW *pLView = (LVIEW*)lpParam;

	EnterCriticalSection(pLView->pCSLock);

	if(pLView->bUse == TRUE) {
		switch(eEvent) {
		case CBST_CONNECT:
			::PostMessage(pLView->hWnd,WM_LIVELIEW,eEvent,0);
			break;
		case CBST_DISCONNECT:
			::PostMessage(pLView->hWnd,WM_LIVELIEW,eEvent,0);
			break;
		case CBST_RECVINFO:
			pLView->pLiveInfo->Lock();
			pLView->pLiveInfo->SetLiveData((RECVINFO*)lpData);
			pLView->pLiveInfo->Unlock();
			::PostMessage(pLView->hWnd,WM_LIVELIEW,eEvent,0);
			break;
		case CBST_RECVDATA:
			pLView->pLiveImage->Lock();
			pLView->pLiveImage->SetLiveData((RECVIMAGE*)lpData);
			pLView->pLiveImage->Unlock();
			::PostMessage(pLView->hWnd,WM_LIVELIEW,eEvent,0);
			break;
		}
	}

	LeaveCriticalSection(pLView->pCSLock);
}

int CSrLiveView::GetLviewId(HWND hWnd)
{
	int i;
	for(i=0;i<MAX_LVIEW;i++) {
		if(m_LView[i].bUse == TRUE) {
			if(m_LView[i].hWnd == hWnd) {
				return i;
			}
		}
	}
	return -1;
}

int CSrLiveView::GetLviewId(unsigned long ulAddr)
{
	int i;
	for(i=0;i<MAX_LVIEW;i++) {
		if(m_LView[i].bUse == TRUE) {
			if(m_LView[i].ulAddr == ulAddr) {
				return i;
			}
		}
	}
	return -1;
}

int CSrLiveView::GetLviewEmptyId(void)
{
	int i;
	for(i=0;i<MAX_LVIEW;i++) {
		if(m_LView[i].bUse == FALSE) {
			return i;
		}
	}
	return -1;
}

LRESULT CALLBACK CSrLiveView::SubProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	CSrLiveView *pSrLv = CSrLiveView::getInstance();

	int nId = pSrLv->GetLviewId(hWnd);
	if(nId < 0) return 0;

	switch (message) {
	case WM_DEVICEON:
		pSrLv->OnDeviceChange(hWnd,wParam,lParam);
		return 0;
	case WM_LIVELIEW:
		pSrLv->OnLiveView(hWnd,wParam,lParam);
		return 0;
	case WM_PAINT:
		pSrLv->OnPaint(hWnd,wParam,lParam);
		return 0;
	case WM_TIMER:
		pSrLv->OnTimer(hWnd,wParam,lParam);
		break;
	case WM_SIZE:
		pSrLv->OnSize(hWnd,wParam,lParam);
		break;
	case WM_DESTROY:
		pSrLv->ReleaseLiveView(nId);
		break;
	default:
		break;
	}
	return (CallWindowProc((WNDPROC)pSrLv->GetfncOrgWnd(nId), hWnd, message, wParam, lParam));
}

void CSrLiveView::OnDeviceChange(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	int i = GetLviewId(hWnd);
	if(m_LView[i].bUse == TRUE) {
		HWND hWnd = m_LView[i].hWnd;
		CLiveCtrl *pCtrl = m_LView[i].pLiveCtrl;
		CLiveImage  *pImage = m_LView[i].pLiveImage;
		CUdpCtrl  *pUdpCtrl = m_LView[i].pUdpCtrl;
		char *lpType = m_LView[i].szType;

		::KillTimer(hWnd,TM_TRYDEVCHECK);
		pUdpCtrl->Stop();

		int nType = strtol(&lpType[3],NULL,10);
        if(nType<1000){
            // SR-750
            pImage->SetBinningTbl(BinningSize750,SR750_IMG_BINNING_MAX);
        }else if(nType < 2000){
            // SR-1000
            pImage->SetBinningTbl(BinningSize1000,SR1000_IMG_BINNING_MAX);
        }else{
            // SR-2000
            pImage->SetBinningTbl(BinningSize2000,SR2000_IMG_BINNING_MAX);
        }
		pCtrl->Start();	
	}
}

void CSrLiveView::OnLiveView(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	int i = GetLviewId(hWnd);
	if(m_LView[i].bUse == TRUE) {
		HWND hWnd = m_LView[i].hWnd;
		CLiveCtrl *pCtrl = m_LView[i].pLiveCtrl;
		switch((CBST)wParam) {
		case CBST_CONNECT:
			::KillTimer(hWnd,TM_TRYDEVCHECK);
			pCtrl->SendStartReq(LIV_TRANS_PULL,LIV_IMG_JPEG,5,IMG_BINNING_DEV2);
			::SetTimer(hWnd,TM_PULLIMAGE,TIME_PULL_WAIT,NULL);
			break;
		case CBST_DISCONNECT:
			pCtrl->Stop();
			::KillTimer(hWnd,TM_PULLIMAGE);
			::SetTimer(hWnd,TM_TRYDEVCHECK,TIME_CHECK_DEVICE,NULL);
			break;
		case CBST_RECVINFO:
			break;
		case CBST_RECVDATA:
			::InvalidateRect(hWnd,NULL,FALSE);
			::KillTimer(hWnd,TM_PULLIMAGE);
			::SetTimer(hWnd,TM_PULLIMAGE,TIME_PULL_WAIT,NULL);
			break;
		}
	}
}

void CSrLiveView::OnPaint(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	int i = GetLviewId(hWnd);
	CLiveImage  *pImage = m_LView[i].pLiveImage;
	CDcBuffer *pBuffer  = m_LView[i].pPaintBuffer;

	RECT tRc;
	::GetClientRect(hWnd,&tRc);

	BOOL bReDraw = FALSE;
	LONG  lWidth = tRc.right-tRc.left+1;
	LONG  lHeigth = tRc.bottom-tRc.top+1;

	if(pBuffer->GetWidth() !=  lWidth || pBuffer->GetHeight() != lHeigth) {
		pBuffer->SetSize(lWidth,lHeigth,FALSE);
		bReDraw = TRUE;
	}

	pImage->Lock();
	if(pImage->IsNew() || bReDraw) {
		pImage->Draw(pBuffer->GethDC(), lWidth, lHeigth);
	}
	pImage->Unlock();

	HDC hDc;
	PAINTSTRUCT tPs;
	hDc = BeginPaint(hWnd , &tPs);
	BitBlt(hDc, 0, 0, lWidth, lHeigth, pBuffer->GethDC(), 0, 0, SRCCOPY);
	EndPaint(hWnd , &tPs);
}

void CSrLiveView::OnTimer(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	if(wParam == TM_TRYDEVCHECK) {
		int i = GetLviewId(hWnd);
		unsigned long ulAddr = m_LView[i].ulAddr;
		CUdpCtrl	*pUdpCtrl = m_LView[i].pUdpCtrl;
		pUdpCtrl->Stop();
		pUdpCtrl->Start();
		pUdpCtrl->Send(ulAddr,(BYTE*)CHECK_CMD,CHECK_CMD_LEN);
	}
	if(wParam == TM_PULLIMAGE) {
		::KillTimer(hWnd,TM_PULLIMAGE);
		int i = GetLviewId(hWnd);
		CLiveCtrl *pCtrl = m_LView[i].pLiveCtrl;
		HWND hWnd = m_LView[i].hWnd;
		pCtrl->SendImgReq();
		::SetTimer(hWnd,TM_PULLIMAGE,TIME_PULL_TIMEOUT,NULL);
	}
}

void CSrLiveView::OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	::InvalidateRect(hWnd,NULL,FALSE);
}

int CSrLiveView::CreateLiveView(HWND hWnd, unsigned long ulAddr)
{
	Lock();

	if(m_nLView >= MAX_LVIEW) {
		Unlock();
		return -1;
	}

	int nRet = -1;

	nRet = GetLviewId(hWnd);
	if(nRet != -1) {
		Unlock();
		return -1;
	}

	nRet = GetLviewId(ulAddr);
	if(nRet != -1) {
		Unlock();
		return -1;
	}

	nRet = GetLviewEmptyId();

	if(nRet != -1) {
		int i = nRet;
		CLiveTcpCtrl *pCtrl = new CLiveTcpCtrl;
		CLiveInfo	*pInfo = new CLiveInfo;
		CLiveImage	*pImage = new CLiveImage;
		CDcBuffer	*pBuffer = new CDcBuffer;
		CUdpCtrl	*pUdpCtrl = new CUdpCtrl;

		if(pCtrl != NULL && pInfo != NULL && pImage != NULL && pBuffer != NULL && pUdpCtrl != NULL) {
			m_LView[i].bUse = TRUE;
			m_LView[i].ulAddr = ulAddr;
			m_LView[i].pLiveCtrl = pCtrl;
			m_LView[i].pLiveInfo = pInfo;
			m_LView[i].pLiveImage = pImage;
			m_LView[i].pPaintBuffer = pBuffer;
			m_LView[i].pUdpCtrl = pUdpCtrl;
			m_LView[i].hWnd = hWnd;
			m_LView[i].fncOrgWnd = (FARPROC)GetWindowLong(hWnd, GWL_WNDPROC);
			::SetWindowLong(hWnd, GWL_WNDPROC, (LONG)SubProc);

			pBuffer->SetWnd(hWnd);

			pCtrl->SetAddress(ulAddr);
			pCtrl->SetLiveCallBack(&m_LView[i],LiveCallBack);
			pImage->SetBinningTbl(BinningSize1000,SR1000_IMG_BINNING_MAX);

			if(m_nLView == 0) {
				if(m_pMontor != NULL) {
					m_pMontor->Start();
				}
			}

			pUdpCtrl->SetCallBack(&m_LView[i],UdpCallBack);
			pUdpCtrl->SetPort(9015);
			pUdpCtrl->SetTimeout(TIME_CHECK_DEVICE/2);
			pUdpCtrl->SetOneShot(TRUE);

			pUdpCtrl->Start();
			pUdpCtrl->Send(ulAddr,(BYTE*)CHECK_CMD,CHECK_CMD_LEN);
			::SetTimer(hWnd,TM_TRYDEVCHECK,TIME_CHECK_DEVICE,NULL);

			::InvalidateRect(hWnd,NULL,FALSE);
			m_nLView++;
		}
		else {
			if(pCtrl != NULL) delete pCtrl;
			if(pInfo != NULL) delete pInfo;
			if(pImage != NULL) delete pImage;
			if(pBuffer != NULL) delete pBuffer;
			if(pUdpCtrl != NULL) delete pUdpCtrl;

			Unlock();
			return -1;
		}
	}

	Unlock();
	return nRet;
}

BOOL CSrLiveView::ReleaseLiveView(int nId)
{
	if(nId<0 || nId>=MAX_LVIEW) return FALSE;

	Lock();
	int i = nId;
	if(m_LView[i].bUse == TRUE) {
		CLiveTcpCtrl *pCtrl = (CLiveTcpCtrl*)m_LView[i].pLiveCtrl;
		CLiveInfo	*pInfo = m_LView[i].pLiveInfo;
		CLiveImage	*pImage = m_LView[i].pLiveImage;
		CDcBuffer	*pBuffer = m_LView[i].pPaintBuffer;
		CUdpCtrl	*pUdpCtrl = m_LView[i].pUdpCtrl;
		HWND hWnd = m_LView[i].hWnd;
		FARPROC fncOrgWnd = m_LView[i].fncOrgWnd;

		::KillTimer(hWnd,TM_PULLIMAGE);
		::KillTimer(hWnd,TM_TRYDEVCHECK);
		::SetWindowLong(hWnd, GWL_WNDPROC, (LONG)fncOrgWnd);

		m_LView[i].bUse = FALSE;
		m_LView[i].ulAddr = 0;
		m_LView[i].pLiveCtrl = NULL;
		m_LView[i].pLiveInfo = NULL;
		m_LView[i].pLiveImage = NULL;
		m_LView[i].pPaintBuffer = NULL;;
		m_LView[i].hWnd = NULL;
		m_LView[i].fncOrgWnd = NULL;

		pCtrl->SendEndReq();

		Unlock();
		pUdpCtrl->Stop();
		pCtrl->Stop();
		Lock();

		delete pCtrl;
		delete pInfo;
		delete pImage;
		delete pBuffer;
		delete pUdpCtrl;

		::InvalidateRect(hWnd,NULL,FALSE);
		m_nLView--;
		if(m_nLView == 0) {
			if(m_pMontor != NULL) m_pMontor->Stop();
		}
	}
	Unlock();

	return TRUE;
}
