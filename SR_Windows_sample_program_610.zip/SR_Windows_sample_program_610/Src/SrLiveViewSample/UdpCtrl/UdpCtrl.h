#pragma once
#include <winsock2.h>

#define	MAX_RECV_BUFFER		2048

typedef void (CALLBACK* pCbUdpFunc)(LPVOID, struct sockaddr_in *, BYTE*, DWORD);


class CUdpCtrl
{
public:
	CUdpCtrl(void);
	CUdpCtrl(unsigned short usPort,BOOL bBind);
	~CUdpCtrl(void);

	BOOL Start(void);
	BOOL Stop(void);

	void SetPort(unsigned short usPort);
	void SetTimeout(int nTimeout);
	void SetBind(BOOL bBind);
	void SetOneShot(BOOL bOneShot);

	int Send(unsigned long ulAddr, BYTE *pData, DWORD dwSize);
	int Send(unsigned long ulAddr, unsigned short usPort, BYTE *pData, DWORD dwSize);
	int Send(struct sockaddr_in *pAddr, BYTE *pData, DWORD dwSize);
	BOOL IsStart(void){return m_hThread!=NULL;}

	void SetCallBack(LPVOID pParam, pCbUdpFunc lpCallBack);

	UINT RecvThread(void);

protected:
	virtual void RecvData(struct sockaddr_in *pAddr, BYTE* pData, DWORD dwSize);

private:
	HANDLE	m_hBreak;
	BYTE	*m_pRecvBuffer;

	LPCRITICAL_SECTION m_pCSCb;
	pCbUdpFunc m_lpCallBack;
	LPVOID	m_pTarget;

	HANDLE	m_hThread;

	SOCKET	m_soSock;

	unsigned short m_usPort;
	int m_nRecvTimeout;
	BOOL m_bBind;
	BOOL m_bOneShot;
};

