#include "StdAfx.h"
#include "MonUdpCtrl.h"


CMonUdpCtrl::CMonUdpCtrl(void)
	:	CUdpCtrl(8502,TRUE)
{
}

CMonUdpCtrl::~CMonUdpCtrl(void)
{
}

void CMonUdpCtrl::RecvData(struct sockaddr_in *pAddr, BYTE* pData, DWORD dwSize)
{
	if(dwSize > 16) {
		if(memcmp(&pData[8],"EWWM",4) == 0) {
			BYTE bSendData[] = {0x00,0x00,0x00,0x00,0x04,0x00,0x00,0x00,'E','W','W',0x00};
			int nRes = Send(pAddr, bSendData, sizeof(bSendData));

			CUdpCtrl::RecvData(pAddr, pData, dwSize);
		}
	}
}
