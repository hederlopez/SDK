#include "stdafx.h"
#include "UdpCtrl.h"
#if defined(UNDER_CE)
#pragma  comment(lib,"ws2.lib")
#else
#pragma  comment(lib,"ws2_32.lib")
#endif

static DWORD WINAPI ThRecvThread(void *pParam)
{
	CUdpCtrl *pthis = (CUdpCtrl*)pParam;
	return pthis->RecvThread();
}


CUdpCtrl::CUdpCtrl(void)
{
	WSAData wsaData;
	WSAStartup(MAKEWORD(2,2), &wsaData);

	m_pRecvBuffer = new BYTE[MAX_RECV_BUFFER];

	m_pCSCb = new CRITICAL_SECTION;
	if(m_pCSCb != NULL) InitializeCriticalSection(m_pCSCb);

	m_hBreak = ::CreateEvent( NULL, TRUE, TRUE, NULL);

	m_soSock = INVALID_SOCKET;
	m_usPort = 5000;
	m_nRecvTimeout = 100;
	m_bBind = FALSE;
	m_bOneShot = FALSE;

	m_lpCallBack = NULL;
	m_hThread = NULL;
}

CUdpCtrl::CUdpCtrl(unsigned short usPort,BOOL bBind)
{
	m_pRecvBuffer = new BYTE[MAX_RECV_BUFFER];

	WSAData wsaData;
	WSAStartup(MAKEWORD(2,2), &wsaData);

	m_pCSCb = new CRITICAL_SECTION;
	if(m_pCSCb != NULL) InitializeCriticalSection(m_pCSCb);

	m_hBreak = ::CreateEvent( NULL, TRUE, TRUE, NULL);

	m_soSock = INVALID_SOCKET;
	m_usPort = usPort;
	m_nRecvTimeout = 100;
	m_bBind = bBind;
	m_bOneShot = FALSE;

	m_lpCallBack = NULL;
	m_hThread = NULL;
}

CUdpCtrl::~CUdpCtrl(void)
{
	Stop();

	WSACleanup();

	if( m_hBreak != NULL) {
		CloseHandle(m_hBreak);
		m_hBreak = NULL;
	}

	if( m_pCSCb != NULL ) {
		DeleteCriticalSection(m_pCSCb);
		delete m_pCSCb;
		m_pCSCb = NULL;
	}

	if( m_pRecvBuffer != NULL) {
		delete [] m_pRecvBuffer;
		m_pRecvBuffer = NULL;
	}
}

///////////////////////////////////////////////////
// public
///////////////////////////////////////////////////

BOOL CUdpCtrl::Start(void)
{
	if(m_pRecvBuffer == NULL) return FALSE;
	if(m_pCSCb == NULL) return FALSE;
	if(m_hBreak == NULL) return FALSE;

	SOCKET soSockfd;
	int nOptval;
	unsigned long ulArg;

	soSockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(soSockfd == INVALID_SOCKET) return FALSE;

	nOptval = SO_REUSEADDR;
	setsockopt(soSockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&nOptval, sizeof(nOptval));

	ulArg = 1;
	ioctlsocket(soSockfd, FIONBIO, &ulArg);

	if(m_bBind == TRUE) {
		int nRet;
		struct sockaddr_in tConnect;
		memset(&tConnect, 0, sizeof(tConnect));
		tConnect.sin_family = AF_INET;
		tConnect.sin_port = htons(m_usPort);
		tConnect.sin_addr.s_addr = INADDR_ANY;

		nRet = bind(soSockfd, (struct sockaddr *)&tConnect, sizeof(tConnect));
		if(nRet == SOCKET_ERROR) {
			return FALSE;
		}
	}

	m_soSock = soSockfd;

	if ( WaitForSingleObject(m_hBreak,0) == WAIT_TIMEOUT ) {
		return TRUE;
	}
	else {
		ResetEvent(m_hBreak);
		m_hThread = CreateThread(NULL,0,ThRecvThread,(void *)this,0,NULL);
		Sleep(0);
	}

	return TRUE;
}

BOOL CUdpCtrl::Stop(void)
{
	SetEvent(m_hBreak);

	if(m_soSock != INVALID_SOCKET ) {
		shutdown(m_soSock,2);
		closesocket(m_soSock);
		m_soSock = INVALID_SOCKET;
	}

	if(m_hThread != NULL) WaitForSingleObject(m_hThread,INFINITE);
	m_hThread = NULL;

	return TRUE;
}

void CUdpCtrl::SetPort(unsigned short usPort)
{
	m_usPort = usPort;
}

void CUdpCtrl::SetTimeout(int nTimeout)
{
	m_nRecvTimeout = nTimeout;
}

void CUdpCtrl::SetBind(BOOL bBind)
{
	m_bBind = bBind;
}

void CUdpCtrl::SetOneShot(BOOL bOneShot)
{
	m_bOneShot = bOneShot;
}

void CUdpCtrl::SetCallBack(LPVOID pParam, pCbUdpFunc lpCallBack)
{
	EnterCriticalSection(m_pCSCb);
	m_pTarget = pParam;
	m_lpCallBack = lpCallBack;
	LeaveCriticalSection(m_pCSCb);
}


///////////////////////////////////////////////////
// private
///////////////////////////////////////////////////
void CUdpCtrl::RecvData(struct sockaddr_in *pAddr, BYTE* pData, DWORD dwSize)
{
	EnterCriticalSection(m_pCSCb);
	if (m_lpCallBack != NULL) {
		(*m_lpCallBack)(m_pTarget, pAddr, pData, dwSize);
	}
	LeaveCriticalSection(m_pCSCb);
}

UINT CUdpCtrl::RecvThread(void)
{
	int nRes,nSize;
	struct timeval tTimeout = {0, 0};
	fd_set readMask,errMask;
	struct sockaddr_in tSockinfo;
	int nFromlen;
	BOOL bOneShot = FALSE;

	tTimeout.tv_sec = 0;
	tTimeout.tv_usec = m_nRecvTimeout * 1000;

	while ( WaitForSingleObject(m_hBreak,0) == WAIT_TIMEOUT && m_soSock != INVALID_SOCKET && bOneShot == FALSE) {
		bOneShot = m_bOneShot;

		FD_ZERO(&readMask);
		FD_ZERO(&errMask);
		FD_SET(m_soSock, &readMask);
		FD_SET(m_soSock, &errMask);
		nRes = select(((int)m_soSock)+1, &readMask, NULL, &errMask, &tTimeout);
		if( nRes == 0 ){
			continue;
		}
		if(nRes <= 0 || FD_ISSET(m_soSock, (fd_set *)&errMask)) {
			closesocket(m_soSock);
			m_soSock = INVALID_SOCKET;
			break;
		}

		nFromlen = sizeof(tSockinfo);
		memset(&tSockinfo, 0, sizeof(tSockinfo));
		nRes = recvfrom(m_soSock, (char*)m_pRecvBuffer, MAX_RECV_BUFFER, 0, (struct sockaddr *)&tSockinfo, &nFromlen);
		if(nRes == 0) {
			closesocket(m_soSock);
			m_soSock = INVALID_SOCKET;
			break;
		}
		else if(nRes < 0) {
			int nErr = WSAGetLastError();
			if (nErr == WSAEWOULDBLOCK) {
				Sleep(100);
				continue;
			}
			closesocket(m_soSock);
			m_soSock = INVALID_SOCKET;
			break;
		}

		nSize = nRes;

		RecvData(&tSockinfo ,m_pRecvBuffer, nSize);
	}

	EnterCriticalSection(m_pCSCb);
	if (m_lpCallBack != NULL) {
		(*m_lpCallBack)(m_pTarget, 0, NULL, 0);
	}
	LeaveCriticalSection(m_pCSCb);

	return 0;
}

int CUdpCtrl::Send(unsigned long ulAddr, BYTE *pData, DWORD dwSize)
{
	return Send(ulAddr,m_usPort,pData,dwSize);
}

int CUdpCtrl::Send(unsigned long ulAddr, unsigned short usPort, BYTE *pData, DWORD dwSize)
{
	struct sockaddr_in tDestSockAddr;
	memset(&tDestSockAddr, 0, sizeof(tDestSockAddr));
	tDestSockAddr.sin_family = AF_INET;
	tDestSockAddr.sin_port = htons(usPort);
	tDestSockAddr.sin_addr.s_addr = ulAddr;
	return Send(&tDestSockAddr,pData,dwSize);
}

int CUdpCtrl::Send(struct sockaddr_in *pAddr,BYTE *pData, DWORD dwSize)
{
	return sendto(m_soSock,(char*)pData,dwSize,0,(struct sockaddr*)pAddr,sizeof(struct sockaddr_in));
}
