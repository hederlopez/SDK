#pragma once
#include "UdpCtrl.h"

class CMonUdpCtrl :	public CUdpCtrl
{
public:
	CMonUdpCtrl(void);
	~CMonUdpCtrl(void);
private:
	virtual void RecvData(struct sockaddr_in *pAddr, BYTE* pData, DWORD dwSize);
};
