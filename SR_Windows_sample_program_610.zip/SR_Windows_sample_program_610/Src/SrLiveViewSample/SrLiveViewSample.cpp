#include "stdafx.h"
#include "SrLiveViewSample.h"
#include "SrLiveView.h"

#if defined(UNDER_CE)
BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
#else
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
#endif
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

/*!
	Register liveview function to the window
    @param[in] hWnd : Handle of the window
    @param[in] ulAddr : Address of the reader
    @return index : Success  -1 : Fail
*/
int WINAPI CreateLiveViewN(HWND hWnd, unsigned long ulAddr)
{
	CSrLiveView *pSrLv = CSrLiveView::getInstance();
	return pSrLv->CreateLiveView(hWnd,ulAddr);
}

/*!
	Register liveview function to the window
    @param[in] hWnd : Handle of the window
    @param[in] ulAddr : Address of the reader
    @return index : Success  -1 : Fail
*/
int WINAPI CreateLiveViewA(HWND hWnd, LPCSTR lpAddr)
{
	unsigned long ulAddr = inet_addr(lpAddr);
	CSrLiveView *pSrLv = CSrLiveView::getInstance();
	return pSrLv->CreateLiveView(hWnd,ulAddr);
}

/*!
	Register liveview function to the window
    @param[in] hWnd : Handle of the window
    @param[in] ulAddr : Address of the reader
    @return index : Success  -1 : Fail
*/
int WINAPI CreateLiveViewW(HWND hWnd, LPCWSTR lpAddr)
{
	int i;
	char szTemp[32];
	memset(szTemp,0,sizeof(szTemp));
	for(i=0;((i<(32-1))&&(lpAddr[i]!=0));i++) szTemp[i] = (char)lpAddr[i];
	unsigned long ulAddr = inet_addr(szTemp);
	CSrLiveView *pSrLv = CSrLiveView::getInstance();
	return pSrLv->CreateLiveView(hWnd,ulAddr);
}

/*!
    Remove liveview function from the window
    @param[in] nId : index
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL WINAPI ReleaseLiveView(int nId)
{
	CSrLiveView *pSrLv = CSrLiveView::getInstance();
	return pSrLv->ReleaseLiveView(nId);
}


void OutputDebugStringFormat( LPCTSTR lpFormat, ...)
{
	va_list	argp;
	TCHAR lpBuf[1024];
	va_start(argp, lpFormat);
#if defined(_vstprintf_s)
	_vstprintf_s( lpBuf,_countof(lpBuf), lpFormat, argp);
#else
	_vstprintf( lpBuf, lpFormat, argp);
#endif
	va_end(argp);
	OutputDebugString( lpBuf);
}
