#pragma once
#include "Liveview.h"
#include "LiveCtrl.h"
#include <winsock2.h>

class CLiveTcpCtrl : public CLiveCtrl
{
public:
	CLiveTcpCtrl(void);
	~CLiveTcpCtrl(void);

	void SetAddress(unsigned long ulAddr);
	void SetPort(unsigned short usPort);

private:
	BOOL IsConnectDevice(void);
	int ConnectDevice(void);
	int WaitConnectDevice(int nTimeout);
	int CloseDevice(void);
	int SendDevice(BYTE* pData, DWORD dwSize);
	int WaitRecvDevice(int nTimeout);
	int RecvDevice(BYTE* pBuf, DWORD dwLen);
private:
	unsigned long m_ulIpaddr;
	unsigned short m_usPort;
	SOCKET m_soConnect;
};

