#pragma once
#include "Liveview.h"

#define	CODE_MAX_COUNT	16			//!< Maximum number of codes

//!< Coordinates
typedef struct _LVPOINT {
	short	x;						//!< X-coordinate
	short	y;						//!< Y-coordinate
} LVPOINT;

//!< Size
typedef struct _LVSIZE {
	short	w;						//!< Width
	short	h;						//!< Height
} LVSIZE;

//!< Code position
typedef struct _CODEPOINTS {
	LVPOINT	tVertex[4];				//!< Vertex coordinates
	LVPOINT	tCenter;				//!< Center coodinate
} CODEPOINTS;

//!< Reading information
typedef struct _RECVINFO {
	int		nMode;					//!< Reading mode
	int		nTrigerNumber;			//!< Reserved
	int		nImageCont;				//!< Reserved
	int		nBank;					//!< Bank number
	int		nBstOk;					//!< Reserved
} RECVINFO;

//!< Image data
typedef struct _RECVIMAGE {
	int		nCommand;				//!< Command id
	int		nImageNumber;			//!< Reserved
	int		nDecodeResult;			//!< Decode result
	int		nCodeCount;				//!< Number of codes
	CODEPOINTS tPoints[CODE_MAX_COUNT];	//!< Vertex coordinates
	int		nImageFormat;			//!< Encoding type
	int		nImageBining;			//!< Binning value
	int		nImageWidth; 			//!< Image width
	int		nImageHeight;			//!< Image height
	int		nImageLeft;  			//!< Minimum x-coordinate
	int		nImageTop;	 			//!< Minimum y-coordinate
	int		nImageSize;  			//!< Image data size
	BYTE 	*pImageData;  			//!< Image data
} RECVIMAGE;

//!< Notification by callback function
typedef enum {
	CBST_CONNECT,		//!< Connected
	CBST_DISCONNECT,	//!< Disconnected
	CBST_RECVINFO,		//!< Received information
	CBST_RECVDATA,		//!< Received data
	CBST_SIZE
} CBST;

//!< Callback format
// RECVINFO* is passed to lpData in case of CBSET_RECVINFO, and 
// RECVIMAGE* is passed to lpData in case of CBSET_RECVDATA.
typedef void (CALLBACK* pCbFunc)(LPVOID lpParam, LPVOID lpData, CBST eEvent);


class CLiveCtrl
{
public:
	CLiveCtrl(void);
	~CLiveCtrl(void);

	BOOL Start(void);
	BOOL Stop(void);
	BOOL IsConnect(void);

	void SetConnectTimeout(int nTimeout);
	void SetRecvTimeout(int nTimeout);

	void SetLiveCallBack(LPVOID pParam, pCbFunc lpCallBack);

	BOOL SendStartReq(int nMode,int nImgType,int nQuality,int nBinning);
	BOOL SendEndReq(void);
	BOOL SendImgReq(void);
	BOOL SendPixReq(void);

	UINT RecvThread(void);

private:
	virtual BOOL IsConnectDevice(void)=0;
	virtual int ConnectDevice(void)=0;
	virtual int WaitConnectDevice(int nTimeout)=0;
	virtual int CloseDevice(void){return 0;}
	virtual int SendDevice(BYTE* pBuf, DWORD dwLen)=0;
	virtual int WaitRecvDevice(int nTimeout)=0;
	virtual int RecvDevice(BYTE* pBuf, DWORD dwLen)=0;

protected:
	BOOL Send(BYTE* pData, DWORD dwSize);
	virtual void RecvData(BYTE* pData,  DWORD dwSize);

private:
	HANDLE	m_hBreak;

	BYTE *m_pRecvBuffer;

	LPCRITICAL_SECTION m_pCSCb;
	pCbFunc m_lpLiveCallBack;
	LPVOID m_pTarget;

	RECVINFO  *m_pRecvInfo;
	RECVIMAGE *m_pRecvImage;

	HANDLE m_hThread;
	DWORD m_dwRecvStart;
	DWORD m_dwRecvEnd;

	int m_nConnectTimeout;
	int m_nRecvTimeout;
	DWORD m_dwRecvTime;
};

