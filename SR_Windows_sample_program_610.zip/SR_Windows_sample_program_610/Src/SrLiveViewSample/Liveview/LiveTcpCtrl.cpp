#include "stdafx.h"
#include "LiveTcpCtrl.h"
#if defined(UNDER_CE)
#pragma  comment(lib,"ws2.lib")
#else
#pragma  comment(lib,"ws2_32.lib")
#endif

/*!
	Constructor
    @return None
*/
CLiveTcpCtrl::CLiveTcpCtrl(void)
{
	WSAData wsaData;
	WSAStartup(MAKEWORD(2,2), &wsaData);

	m_soConnect = INVALID_SOCKET;
	m_ulIpaddr = 0;
	m_usPort = LIVE_PORT;
}

/*!
	Destructor
    @return None
*/
CLiveTcpCtrl::~CLiveTcpCtrl(void)
{
	Stop();

	WSACleanup();
}

///////////////////////////////////////////////////
// public function
///////////////////////////////////////////////////

/*!
	Check connection
    @return	BOOL TRUE : Connected	FALSE : Not connected
*/
BOOL CLiveTcpCtrl::IsConnectDevice(void)
{
	return m_soConnect != INVALID_SOCKET;
}

/*!
	Connect to the server
    @return	Result 0:Success -1:Fail
*/
int CLiveTcpCtrl::ConnectDevice(void)
{
	SOCKET soSockfd;
	int nRet;
	int nOptval;
	unsigned long ulArg;
	struct sockaddr_in tConnect;

	soSockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(soSockfd == INVALID_SOCKET) return -1;

	nOptval = SO_REUSEADDR;
	setsockopt(soSockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&nOptval, sizeof(nOptval));

	ulArg = 1;
	ioctlsocket(soSockfd, FIONBIO, &ulArg);

	memset(&tConnect, 0, sizeof(tConnect));
	tConnect.sin_family = AF_INET;
	tConnect.sin_port = htons(m_usPort);
	tConnect.sin_addr.s_addr = m_ulIpaddr;


	nRet = connect(soSockfd, (struct sockaddr *)&tConnect, sizeof(tConnect));
	if(nRet == SOCKET_ERROR) {
		nRet = WSAGetLastError();
		if (nRet != WSAEWOULDBLOCK) {
			closesocket(soSockfd);
			return -1;
		}
	}

	BOOL optval = TRUE;
	setsockopt(soSockfd, IPPROTO_TCP , TCP_NODELAY, (char*)&optval, sizeof(optval));

//	optval = 0;
//	setsockopt(soSockfd, SOL_SOCKET, SO_DELAYED_ACK, (RTP_PFCCHAR)&optval, sizeof(optval));

	m_soConnect = soSockfd;

	return 0;
}

/*!
	Wait for connection completion
    @return	Result 0:Success -1:Fail
*/
int CLiveTcpCtrl::WaitConnectDevice(int nTimeout)
{
	int nRet;
	struct timeval tTimeout = {0, 0};
	fd_set readMask,writeMask,errMask;

	tTimeout.tv_sec = nTimeout / 1000;
	tTimeout.tv_usec = (nTimeout % 1000) * 1000;

	FD_ZERO(&readMask);
	FD_ZERO(&writeMask);
	FD_ZERO(&errMask);
	FD_SET(m_soConnect, &readMask);
	FD_SET(m_soConnect, &writeMask);
	FD_SET(m_soConnect, &errMask);
	nRet = select(((int)m_soConnect)+1, &readMask, &writeMask, &errMask, &tTimeout);

	if(nRet <= 0 || FD_ISSET(m_soConnect, (fd_set *)&errMask)) {
		closesocket(m_soConnect);
		m_soConnect = INVALID_SOCKET;
		return -1;
	}
	return 0;
}

/*!
	Close connection
    @return	Result 0:Success -1:Fail
*/
int CLiveTcpCtrl::CloseDevice(void)
{
	if(m_soConnect != INVALID_SOCKET ) {
		shutdown(m_soConnect,2);
		closesocket(m_soConnect);
		m_soConnect = INVALID_SOCKET;
	}
	return 0;
}

/*!
	Send data
    @param[in] pData:Sent data
    @param[in] dwSize:Send data size
    @return	Result 0:Success -1:Fail
*/
int CLiveTcpCtrl::SendDevice(BYTE* pData, DWORD dwSize)
{
	int nRet;
	nRet = send(m_soConnect ,(char*)pData,dwSize, 0);
	if(nRet < 0) {
		nRet = WSAGetLastError();
		if (nRet != WSAEWOULDBLOCK) {
			return -1;
		}
		nRet = 0;
	}
	return nRet;
}


/*!
	Wait for reception
    @param[in] nTimeout:timeout
    @return	Result 0:Success  -1:Fail
*/
int CLiveTcpCtrl::WaitRecvDevice(int nTimeout)
{
	int nRet;
	struct timeval tTimeout = {0, 0};
	fd_set readMask,errMask;

	tTimeout.tv_sec = nTimeout / 1000;
	tTimeout.tv_usec = (nTimeout % 1000) * 1000;

	FD_ZERO(&readMask);
	FD_ZERO(&errMask);
	FD_SET(m_soConnect, &readMask);
	FD_SET(m_soConnect, &errMask);
	nRet = select(((int)m_soConnect)+1, &readMask, NULL, &errMask, &tTimeout);
	if(nRet < 0 || FD_ISSET(m_soConnect, (fd_set *)&errMask)) {
		closesocket(m_soConnect);
		m_soConnect = INVALID_SOCKET;
		return -1;
	}
	return nRet;
}

/*!
	Receive data
    @param[in] pData:Recevied data
    @param[in] dwSize:Receive data size
    @return	Result 0:Success -1:Fail
*/
int CLiveTcpCtrl::RecvDevice(BYTE* pData, DWORD dwSize)
{
	int nRes;
	nRes = recv(m_soConnect,(char*)pData,dwSize, 0);
	if(nRes == 0) {
		closesocket(m_soConnect);
		m_soConnect = INVALID_SOCKET;
		nRes = -1;
		return nRes;
	}
	if(nRes < 0) {
		int nErr = WSAGetLastError();
		if (nErr != WSAEWOULDBLOCK) {
			closesocket(m_soConnect);
			m_soConnect = INVALID_SOCKET;
			return nRes;
		}
		nRes = 0;
	}
	return nRes;
}

/*!
	Set address
    @param[in] ulAddr:Address
    @return None
*/
void CLiveTcpCtrl::SetAddress(unsigned long ulAddr)
{
	m_ulIpaddr = ulAddr;
}

/*!
	Set port number
    @param[in] usPort:port number
    @return None
*/
void CLiveTcpCtrl::SetPort(unsigned short usPort)
{
	m_usPort = usPort;
}
