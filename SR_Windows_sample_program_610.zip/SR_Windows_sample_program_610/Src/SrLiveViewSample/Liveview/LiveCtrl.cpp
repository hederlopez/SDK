#include "stdafx.h"
#include "LiveCtrl.h"


typedef enum {
	PKT_NORECV,
	PKT_FINDED,
	PKT_RECVING
} RXMODE;

/*!
	Receive thread function
    @param[in] pParam:argument
    @return Result
*/
static DWORD WINAPI ThRecvThread(void *pParam)
{
	CLiveCtrl *pthis = (CLiveCtrl*)pParam;
	return pthis->RecvThread();
}

/*!
	Constructor
    @return None
*/
CLiveCtrl::CLiveCtrl(void)
{
	m_pRecvBuffer = new BYTE[MAX_PACKET_SIZE];

	m_pCSCb = new CRITICAL_SECTION;
	if(m_pCSCb != NULL) InitializeCriticalSection(m_pCSCb);

	m_pRecvInfo = new RECVINFO;
	m_pRecvImage = new RECVIMAGE;

	m_hBreak = ::CreateEvent( NULL, TRUE, TRUE, NULL);

	m_nConnectTimeout = CONNCET_TIMEOUT;
	m_nRecvTimeout = RECV_TIMEOUT;

	m_lpLiveCallBack = NULL;
	m_hThread = NULL;
}

/*!
	Destructor
    @return None
*/
CLiveCtrl::~CLiveCtrl(void)
{
	Stop();

	if( m_hBreak != NULL) {
		CloseHandle(m_hBreak);
		m_hBreak = NULL;
	}

	if( m_pCSCb != NULL ) {
		DeleteCriticalSection(m_pCSCb);
		delete m_pCSCb;
		m_pCSCb = NULL;
	}

	if( m_pRecvBuffer != NULL) {
		delete [] m_pRecvBuffer;
		m_pRecvBuffer = NULL;
	}

	if( m_pRecvInfo != NULL) {
		delete [] m_pRecvInfo;
		m_pRecvInfo = NULL;
	}

	if( m_pRecvImage != NULL) {
		delete [] m_pRecvImage;
		m_pRecvImage = NULL;
	}
}

///////////////////////////////////////////////////
// public fnction
///////////////////////////////////////////////////

/*!
	Start Liveview
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveCtrl::Start(void)
{
	int nRet;

	if(m_pRecvBuffer == NULL) return FALSE;
	if(m_pCSCb == NULL) return FALSE;
	if(m_pRecvInfo == NULL) return FALSE;
	if(m_pRecvImage == NULL) return FALSE;
	if(m_hBreak == NULL) return FALSE;

	nRet = ConnectDevice();
	if(nRet < 0) return FALSE;

	if ( WaitForSingleObject(m_hBreak,0) == WAIT_TIMEOUT ) {
		return TRUE;
	}
	else {
		ResetEvent(m_hBreak);
		m_hThread = CreateThread(NULL,0,ThRecvThread,(void *)this,0,NULL);
		Sleep(0);
	}

	return TRUE;
}

/*!
	Stop Liveview
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveCtrl::Stop(void)
{
	if(m_pRecvBuffer == NULL) return FALSE;
	if(m_pCSCb == NULL) return FALSE;
	if(m_pRecvInfo == NULL) return FALSE;
	if(m_pRecvImage == NULL) return FALSE;
	if(m_hBreak == NULL) return FALSE;

	SetEvent(m_hBreak);

	CloseDevice();

	if(m_hThread != NULL) {
		WaitForSingleObject(m_hThread,INFINITE);
		CloseHandle(m_hThread);
		m_hThread = NULL;
	}

	return TRUE;
}

/*!
	Check connection
    @return	BOOL TRUE : Connected	FALSE : Not connected
*/
BOOL CLiveCtrl::IsConnect(void)
{
	return IsConnectDevice();
}

/*!
	Set connection timeout
    @param[in] nTimeout:timeout
    @return None
*/
void CLiveCtrl::SetConnectTimeout(int nTimeout)
{
	m_nConnectTimeout = nTimeout;
}

/*!
	Set Non-communication disconnect timeout
    @param[in] nTimeout:timeout
    @return None
*/
void CLiveCtrl::SetRecvTimeout(int nTimeout)
{
	m_dwRecvTime = GetTickCount();
	m_nRecvTimeout = nTimeout;
}

/*!
	Register callback for liveview
    @param[in] pParam:argument
    @param[in] lpCallBack:callback function
    @return None
*/
void CLiveCtrl::SetLiveCallBack(LPVOID pParam, pCbFunc lpCallBack)
{
	EnterCriticalSection(m_pCSCb);
	m_pTarget = pParam;
	m_lpLiveCallBack = lpCallBack;
	LeaveCriticalSection(m_pCSCb);
}

/*!
	Send the packet of starting live view
    @param[in] nMode:���[�h LIV_TRANS_PUSH,LIV_TRANS_PULL
    @param[in] nImgType:Encoding type LIV_IMG_JPEG,LIV_IMG_BMP
    @param[in] nQuality:Compression quality
    @param[in] nBinning:Binning value
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveCtrl::SendStartReq(int nMode,int nImgType,int nQuality,int nBinning)
{
	if(nMode != LIV_TRANS_PUSH && nImgType != LIV_TRANS_PULL) return FALSE;
	if(nImgType != LIV_IMG_BMP && nImgType != LIV_IMG_JPEG) return FALSE;
	if(nImgType == LIV_IMG_JPEG && (nQuality < LIV_MIN_QUALITY || nQuality > LIV_MAX_QUALITY)) return FALSE;
	if(nBinning < LIV_MIN_BINNING || nBinning > LIV_MAX_BINNING) return FALSE;

	LPKT_LIVESTART tPktStart = {{LIV_PKTHEADER,LIV_PKTSSIZEA(LPKT_LIVESTART),LIV_PKTCMDLIVESTARTU},0,0,0,0};

	tPktStart.tHead.bCommand[0] = (unsigned char)LIV_PKTCMDLIVESTART;
	//tPktStart.tHead.bCommand[0] = (unsigned char)LIV_PKTCMDLIVESTARTU;
	tPktStart.bTransMode[0] = (unsigned char)nMode;
	tPktStart.bImageFormat[0] = (unsigned char)nImgType;
	tPktStart.bImageQuality[0] = (unsigned char)nQuality;
	tPktStart.bImageBining[0] = (unsigned char)nBinning;
	return Send((BYTE*)&tPktStart,sizeof(tPktStart));
}

/*!
	Send the paket of stopping live view
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveCtrl::SendEndReq(void)
{
	LPKT_LIVESTOP tPktStop = {{LIV_PKTHEADER,LIV_PKTSSIZEA(LPKT_LIVESTOP),LIV_PKTCMDLIVESTOP}};
	return Send((BYTE*)&tPktStop,sizeof(tPktStop));
}

/*!
	Send the packet of request image
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CLiveCtrl::SendImgReq(void)
{
	LPKT_IMGREQ tPktImgReq = {{LIV_PKTHEADER,LIV_PKTSSIZEA(LPKT_IMGREQ),LIV_PKTCMDIMGREQ}};
	return Send((BYTE*)&tPktImgReq,sizeof(tPktImgReq));
}

/*!
	Reserved
*/
BOOL CLiveCtrl::SendPixReq(void)
{
	LPKT_PIXELREQ tPktPixReq = {{LIV_PKTHEADER,LIV_PKTSSIZEA(LPKT_PIXELREQ),LIV_PKTCMDPIXELREQ}};
	return Send((BYTE*)&tPktPixReq,sizeof(tPktPixReq));
}


///////////////////////////////////////////////////
// private function
///////////////////////////////////////////////////
BOOL CLiveCtrl::Send(BYTE* pData, DWORD dwSize)
{
	int nRet;
	DWORD dwSz;

	dwSz = 0;
	while(dwSz < dwSize) {
		nRet = SendDevice(&pData[dwSz],dwSize-dwSz);
		if(nRet < 0) return FALSE;
		dwSz += nRet;
	}

	return TRUE;
}

void CLiveCtrl::RecvData(BYTE* pData,  DWORD dwSize)
{
	LPKT_RESPONSE tPktResp = {{LIV_PKTHEADER,LIV_PKTSSIZEA(LPKT_RESPONSE),LIV_PKTCMDRESP},0};

	LPKT_HEAD *pHead = (LPKT_HEAD*)pData;
	int nCommand = B2B(pHead->bCommand);
	tPktResp.bReCommand[0] = nCommand;

	if(nCommand == LIV_PKTCMDIMGSTART) {
		LPKT_IMGSTART *pInfo = (LPKT_IMGSTART*)pData;
		m_pRecvInfo->nMode = pInfo->bMode[0];
		m_pRecvInfo->nTrigerNumber = B2SHORT(pInfo->bTrigerNumber);
		m_pRecvInfo->nImageCont = pInfo->bImageCont[0];
		m_pRecvInfo->nBank = pInfo->bBank[0];
		m_pRecvInfo->nBstOk = pInfo->bBstOk[0];

		Send((BYTE*)&tPktResp,sizeof(tPktResp));

		EnterCriticalSection(m_pCSCb);
		if (m_lpLiveCallBack != NULL) {
			(*m_lpLiveCallBack)(m_pTarget, (LPVOID)m_pRecvInfo, CBST_RECVINFO);
		}
		LeaveCriticalSection(m_pCSCb);
	}
	else if(nCommand == LIV_PKTCMDIMGDATA) {
		m_pRecvImage->nCommand = nCommand;

		LPKT_IMGDATA1 *ptPktData1 = (LPKT_IMGDATA1*)pData;;
		m_pRecvImage->nImageNumber = ptPktData1->bImageNumber[0];
		m_pRecvImage->nDecodeResult = ptPktData1->bDecodeResult[0];
		m_pRecvImage->nCodeCount = ptPktData1->bCodeCount[0];
		if(m_pRecvImage->nCodeCount > CODE_MAX_COUNT) m_pRecvImage->nCodeCount = CODE_MAX_COUNT;

		int i,n;
		n = m_pRecvImage->nCodeCount;
		LPKT_CODE_POS *ptPktCodePos =  (LPKT_CODE_POS*)(pData+sizeof(LPKT_IMGDATA1));
		for(i=0;i<n;i++) {
			m_pRecvImage->tPoints[i].tVertex[0].x = B2SHORT(ptPktCodePos->bCodePosX1);
			m_pRecvImage->tPoints[i].tVertex[0].y = B2SHORT(ptPktCodePos->bCodePosY1);
			m_pRecvImage->tPoints[i].tVertex[1].x = B2SHORT(ptPktCodePos->bCodePosX2);
			m_pRecvImage->tPoints[i].tVertex[1].y = B2SHORT(ptPktCodePos->bCodePosY2);
			m_pRecvImage->tPoints[i].tVertex[2].x = B2SHORT(ptPktCodePos->bCodePosX3);
			m_pRecvImage->tPoints[i].tVertex[2].y = B2SHORT(ptPktCodePos->bCodePosY3);
			m_pRecvImage->tPoints[i].tVertex[3].x = B2SHORT(ptPktCodePos->bCodePosX4);
			m_pRecvImage->tPoints[i].tVertex[3].y = B2SHORT(ptPktCodePos->bCodePosY4);
			m_pRecvImage->tPoints[i].tCenter.x = B2SHORT(ptPktCodePos->bCodePosXC);
			m_pRecvImage->tPoints[i].tCenter.y = B2SHORT(ptPktCodePos->bCodePosYC);
			ptPktCodePos++;
		}

		LPKT_IMGDATA2 *ptPktData2 = (LPKT_IMGDATA2*)ptPktCodePos;
		m_pRecvImage->nImageFormat = ptPktData2->bImageFormat[0];
		m_pRecvImage->nImageBining = ptPktData2->bImageBining[0];
		m_pRecvImage->nImageWidth = B2SHORT(ptPktData2->bImageWidth);
		m_pRecvImage->nImageHeight = B2SHORT(ptPktData2->bImageHeight);
		m_pRecvImage->nImageLeft = B2SHORT(ptPktData2->bImageLeft);
		m_pRecvImage->nImageTop = B2SHORT(ptPktData2->bImageTop);
		m_pRecvImage->nImageSize  = B2INT(ptPktData2->bDataSize);
		m_pRecvImage->pImageData = ptPktData2->bData;

		Send((BYTE*)&tPktResp,sizeof(tPktResp));

		EnterCriticalSection(m_pCSCb);
		if (m_lpLiveCallBack != NULL) {
			(*m_lpLiveCallBack)(m_pTarget, m_pRecvImage, CBST_RECVDATA);
		}
		LeaveCriticalSection(m_pCSCb);
	}
	else if(nCommand == LIV_PKTCMDNOOP) {
		Send((BYTE*)&tPktResp,sizeof(tPktResp));
	}
	else if(nCommand == LIV_PKTCMDPIXELS) {
		LVSIZE tSize;
		LPKT_PIXELS *pPixInfo = (LPKT_PIXELS*)pData;
		tSize.w = B2SHORT(pPixInfo->bWidth);
		tSize.h = B2SHORT(pPixInfo->bHeight);

		Send((BYTE*)&tPktResp,sizeof(tPktResp));

		EnterCriticalSection(m_pCSCb);
		if (m_lpLiveCallBack != NULL) {
			(*m_lpLiveCallBack)(m_pTarget, &tSize, CBST_SIZE);
		}
		LeaveCriticalSection(m_pCSCb);
	}
}

UINT CLiveCtrl::RecvThread(void)
{
	RXMODE eMode;
	int nRes;
	int i,n,nFind;
	BOOL bSkipRecv;

	BYTE *pRecvBuf = m_pRecvBuffer;
	DWORD dwRecvTotal;
	DWORD dwPackSize;
	DWORD dwFindPos;
	BYTE bSubHead[] = LIV_PKTHEADER;

	nRes = WaitConnectDevice(m_nConnectTimeout);
	if(nRes == -1) goto RTHEND;	

	EnterCriticalSection(m_pCSCb);
	if (m_lpLiveCallBack != NULL) {
		(*m_lpLiveCallBack)(m_pTarget, NULL, CBST_CONNECT);
	}
	LeaveCriticalSection(m_pCSCb);

	dwRecvTotal = 0;
	dwPackSize = 0;
	dwFindPos = 0;
	m_dwRecvTime = GetTickCount();
	eMode = PKT_NORECV;

	bSkipRecv = FALSE;
	while (WaitForSingleObject(m_hBreak,0) == WAIT_TIMEOUT && IsConnectDevice() == TRUE ) {

		if(bSkipRecv == FALSE) {

			nRes = WaitRecvDevice(m_nRecvTimeout/10);

			if(nRes == -1) break;

			if(nRes == 0 && m_nRecvTimeout > 0) {
				if((GetTickCount() - m_dwRecvTime) > (DWORD)m_nRecvTimeout) {
					break;
				}
				continue;
			}

			nRes = RecvDevice(&pRecvBuf[dwRecvTotal],MAX_PACKET_SIZE - dwRecvTotal);
			if(nRes < 0) {
				break;
			}

			dwRecvTotal += nRes;
			if(dwRecvTotal == 0) {
				continue;
			}
			m_dwRecvTime = GetTickCount();

		}

		bSkipRecv = FALSE;

		nFind = -1;
		n = dwRecvTotal-LIV_PKTHEADERSIZE;
		if(eMode == PKT_RECVING && (DWORD)n >= dwPackSize) n = dwPackSize;
		for(i=dwFindPos;i<n;i++) {
			if(memcmp(&pRecvBuf[i],bSubHead,LIV_PKTHEADERSIZE) == 0) {
				nFind = i;
				i = i + 1;
				break;
			}
		}
		dwFindPos = i;
		if(nFind >= 0) {
			m_dwRecvStart = GetTickCount();

			dwRecvTotal -= nFind;
			dwFindPos -= nFind;
			if(nFind > 0 && dwRecvTotal > 0) {
				memcpy(&pRecvBuf[0],&pRecvBuf[nFind],dwRecvTotal);
			}
			eMode = PKT_FINDED;
		}

		if(eMode == PKT_FINDED && dwRecvTotal >= LIV_PKTHEADERSIZE + 4) {
			LPKT_HEAD *pHead = (LPKT_HEAD*)pRecvBuf;
			dwPackSize = B2DW(pHead->bPacketSize);
			dwPackSize += LIV_PKTHEADERSIZE;
			eMode = PKT_RECVING;
		}

		if(eMode == PKT_RECVING && dwRecvTotal >= dwPackSize) {

			RecvData(pRecvBuf, dwPackSize);

			dwRecvTotal -= dwPackSize;
			if(dwFindPos >= dwPackSize) dwFindPos -= dwPackSize;
			else dwFindPos = 0;
			if(dwRecvTotal > 0) {
				memcpy(&pRecvBuf[0],&pRecvBuf[dwPackSize],dwRecvTotal);
			}
			eMode = PKT_NORECV;
			dwPackSize = 0;

			if(dwRecvTotal >= LIV_PKTHEADERSIZE + 4) {
				bSkipRecv = TRUE;
			}
		}
	}

RTHEND:

	EnterCriticalSection(m_pCSCb);
	if (m_lpLiveCallBack != NULL) {
		(*m_lpLiveCallBack)(m_pTarget, NULL, CBST_DISCONNECT);
	}
	LeaveCriticalSection(m_pCSCb);

	return 0;
}
