#pragma once
#define LIVE_PORT			5920				//!< Port number for liveview
#define CONNCET_TIMEOUT		8000				//!< Default value of connection timeout
#define RECV_TIMEOUT		10000				//!< Default value of Non-communication disconnect timeout

#define MAX_READ_SIZE		(10000)				//!< Maximum size of reading data
#define IMG_MAX_WIDTH		1280
#define IMG_MAX_HEIGHT		1024
#define MAX_IMAGE_SIZE		(IMG_MAX_WIDTH * IMG_MAX_HEIGHT)
#define MAX_IMAGEBUF_SIZE	MAX_IMAGE_SIZE

#define LIV_PKTHEADER		{0x5B,0x53,0x4C,0x50,0x4B,0x54,0x21,0x5D,0xA4,0xAC,0xB3,0xAF,0xB4,0xAB,0xDE,0xA2}
#define LIV_PKTHEADERSIZE	(16)
#define LIV_PKTSSIZEV(a)	(sizeof(a)-LIV_PKTHEADERSIZE)
#define LIV_PKTSSIZEA(a)	{(LIV_PKTSSIZEV(a)>>24)&0xff,(LIV_PKTSSIZEV(a)>>16)&0xff,(LIV_PKTSSIZEV(a)>>8)&0xff,(LIV_PKTSSIZEV(a)>>0)&0xff}

//!< Packet type
#define LIV_PKTCMDIMGSTART	0x00				//!< Start sending image
#define LIV_PKTCMDIMGDATA	0x01				//!< Image data
#define LIV_PKTCMDNOOP		0x02				//!< NOOP
#define LIV_PKTCMDRESP		0x03				//!< Response
#define LIV_PKTCMDLIVESTART	0x04				//!< Start liveview
#define LIV_PKTCMDLIVESTARTU 0x14				//!< Start liveview
#define LIV_PKTCMDLIVESTOP	0x05				//!< Stop liveview
#define LIV_PKTCMDIMGREQ	0x06				//!< Request image
#define LIV_PKTCMDPIXELREQ	0x07				//!< Reserved
#define LIV_PKTCMDPIXELS	0x08				//!< Reserved

//!< Reading mode
enum {
	LIV_READ_NOTBURST= 0,		//!< 0:Not bust mode
	LIV_READ_BURST				//!< 1:Burst mode
};

//!< Decoede result
enum {
	LIV_DECODE_FAIL=0,			//!< 0:ERR
	LIV_DECODE_SUCCESS,			//!< 1:OK 
	LIV_DECODE_NONE				//!< :None 
};

//!< Transfer mode
enum {
	LIV_TRANS_PUSH=0,			//!< 0:Push
	LIV_TRANS_PULL				//!< 1:Pull
};

//!< Encoding type
enum {
	LIV_IMG_BMP=0,				//!< BMP
	LIV_IMG_JPEG				//!< JPEG
};

//!< Compression quality
#define LIV_MIN_QUALITY		1					//!< Minimum quality
#define LIV_MAX_QUALITY		10					//!< Maximum quality

//!< Binning value
#define LIV_MIN_BINNING		0					//!< Minimum binning
#define LIV_MAX_BINNING		4					//!< Maximum binning

//!< Packet structure
typedef struct _LPKT_HEAD {
	BYTE	bSubHead[LIV_PKTHEADERSIZE];		//!<
	BYTE	bPacketSize[4];						//!< size
	BYTE	bCommand[1];						//!< command id
} LPKT_HEAD;

//!< Packet structre of starting sending image
typedef struct _LPKT_IMGSTART {
	LPKT_HEAD tHead;
	BYTE	bMode[1];							//!< Reading mode
	BYTE	bTrigerNumber[2];					//!< Image number
	BYTE	bImageCont[1];						//!< Reserved
	BYTE	bBank[1];							//!< Bank number
	BYTE	bBstOk[1];							//!< Reserved
	BYTE	bReserve[1];						//!< Reserved
	BYTE	bReadTime[2];						//!< Reserved
	BYTE	bCaptureTime[2];					//!< Reserved
	BYTE	bDecodeTime[2];						//!< Reserved
	BYTE	bDataSize[2];						//!< Read data size
	BYTE	bData[1];							//!< Read data
} LPKT_IMGSTART;

//!< Packet structure of image data
typedef struct _LPKT_IMGDATA1 {
	LPKT_HEAD tHead;
	BYTE	bImageNumber[1];					//!< Reserved
	BYTE	bDecodeResult[1];					//!< Decode result
	BYTE	bCodeCount[1];						//!< Number of codes
} LPKT_IMGDATA1;

//!< Packet structure of coordinates portion of image data
typedef struct _LPKT_CODE_POS {
	BYTE	bCodePosX1[2];						//!< X1
	BYTE	bCodePosY1[2];						//!< Y1
	BYTE	bCodePosX2[2];						//!< X2
	BYTE	bCodePosY2[2];						//!< Y2
	BYTE	bCodePosX3[2];						//!< X3
	BYTE	bCodePosY3[2];						//!< Y3
	BYTE	bCodePosX4[2];						//!< X4
	BYTE	bCodePosY4[2];						//!< Y4
	BYTE	bCodePosXC[2];						//!< CX
	BYTE	bCodePosYC[2];						//!< CY
} LPKT_CODE_POS;

//!< Packet structure of data portion of image data
typedef struct _LPKT_IMGDATA2 {
	BYTE	bImageFormat[1];					//!< Encoding type
	BYTE	bImageBining[1];					//!< Binning value
	BYTE	bImageWidth[2];						//!< Image width
	BYTE	bImageHeight[2];					//!< Image height
	BYTE	bImageLeft[2];						//!< Minimum x-coordinate
	BYTE	bImageTop[2];						//!< Minimum y-coordinate
	BYTE	bDataSize[4];						//!< Image data size
	BYTE	bData[1];							//!< Image data
} LPKT_IMGDATA2;

//!< Packet structure of NOOP
typedef struct _LPKT_NOOP {
	LPKT_HEAD tHead;
} LPKT_NOOP;

//!< Packet structure of response
typedef struct _LPKT_RESPONSE {
	LPKT_HEAD tHead;
	BYTE	bReCommand[1];
} LPKT_RESPONSE;

//!< Packet structure of starting liveview
typedef struct _LPKT_LIVESTART {
	LPKT_HEAD tHead;
	BYTE	bTransMode[1];						//!< Transfer mode
	BYTE	bImageFormat[1];					//!< Encoding type
	BYTE	bImageQuality[1];					//!< Compression quality
	BYTE	bImageBining[1];					//!< Binning value
} LPKT_LIVESTART;

//!< Packet structure of stopping liveview
typedef struct _LPKT_LIVESTOP {
	LPKT_HEAD tHead;
} LPKT_LIVESTOP;

//!< Packet structure of request image
typedef struct _LPKT_IMGREQ {
	LPKT_HEAD tHead;
} LPKT_IMGREQ;

//!< Reserved
typedef struct _LPKT_PIXELREQ {
	LPKT_HEAD tHead;
} LPKT_PIXELREQ;

//!< Reserved
typedef struct _LPKT_PIXELS {
	LPKT_HEAD tHead;
	BYTE	bReserve[1];
	BYTE	bWidth[2];
	BYTE	bHeight[2];
} LPKT_PIXELS;

#define MAX_STARTPACKET_SIZE	(sizeof(LPKT_IMGSTART) + MAX_READ_SIZE)
#define MAX_DPACKET_SIZE		(sizeof(LPKT_IMGDATA1) + sizeof(LPKT_CODE_POS) * 128 + sizeof(LPKT_IMGDATA2) + MAX_IMAGEBUF_SIZE)
#define MAX_PACKET_SIZE			(MAX_DPACKET_SIZE+MAX_IMAGE_SIZE)

inline DWORD B2DW(BYTE *pD)
{
	return ((pD[0]<<24) | (pD[1]<<16) | (pD[2]<< 8) | (pD[3]<< 0));
}

inline int B2INT(BYTE *pD)
{
	return ((pD[0]<<24) | (pD[1]<<16) | (pD[2]<< 8) | (pD[3]<< 0));
}

inline int B2SHORT(BYTE *pD)
{
	return ((short)((pD[0]<< 8) | (pD[1]<< 0)));
}

inline BYTE B2B(BYTE *pD)
{
	return *pD;
}

inline void DW2B(BYTE *pD,DWORD data)
{
	pD[0] = (BYTE)((data >> 24));
	pD[1] = (BYTE)((data >> 16));
	pD[2] = (BYTE)((data >>  8));
	pD[3] = (BYTE)((data >>  0));
}
