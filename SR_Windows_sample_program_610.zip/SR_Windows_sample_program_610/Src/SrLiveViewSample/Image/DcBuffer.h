#pragma once

#define	BACK_COLOR			RGB(255,255,255)

class CDcBuffer
{
public:
	CDcBuffer(void);
	~CDcBuffer(void);

	void SetSize(int nWidth, int nHeight, BOOL bClear = TRUE);
	void SetBufferImage(CDcBuffer &cImageBuffer);
	virtual void ClearBufferImage(void);

	void SetBackColor(COLORREF colBak);

	void Destroy(void);

	void SetWnd(HWND hWnd) {m_hWnd = hWnd;}
	HWND GetWnd(void) {return m_hWnd;}

	int GetWidth(void) {return m_nWidth;}
	int GetHeight(void) {return m_nHeight;}

	virtual HDC GethDC(void) {return m_hDc;}

	virtual BOOL IsNull(void) {return (m_hDc == NULL);}

protected:
	HPEN		m_hBackPen;
	HBRUSH		m_hBackBrush;

	HWND		m_hWnd;
	HDC			m_hDc;
	HBITMAP		m_hBitmap;
	int			m_nWidth;
	int			m_nHeight;
};

