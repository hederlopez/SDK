#pragma once

#include "DcBuffer.h"

typedef enum {
	IMGM_TYPE_NONE = -1,
	IMGM_TYPE_BMP,
	IMGM_TYPE_JPEG,
	IMGM_TYPE_GRAY
} MITYPE;

class CMImage : public CDcBuffer
{
public:
	CMImage(void);
	~CMImage(void);

	BOOL SetMemImage(BYTE *pData,int nSize,int nWidth,int nHeight,MITYPE eType);
	BOOL SaveMemImage(LPCTSTR lpz);
	virtual void ClearBufferImage(void);

	BYTE *GetImageMem(void) {return m_pImageFile;};
	int GetImageSize(void) {return m_nFileSize;};
	MITYPE GetImageType(void) {return m_eType;};
	virtual void ClearImage(void);

	BOOL IsEmpty(void) {return(m_nFileSize <= 0 || m_pImageFile==NULL);}

	virtual HDC GethDC(void);
	virtual BOOL IsNew(void) {return m_bDecRequest;}
protected:
	void Decode(void);

	int Make256GrayBitmap(BYTE *pDstBuf,int nDstSize,int nWidth,int nHeight,BYTE *pSrcBuf);

	BOOL DecodeImage(BYTE *pDstBuf,int nDstSize);

	BYTE *m_pImageFile;
	int m_nMemSize;
	int m_nFileSize;
	MITYPE m_eType;
	BOOL m_bDecRequest;
};
