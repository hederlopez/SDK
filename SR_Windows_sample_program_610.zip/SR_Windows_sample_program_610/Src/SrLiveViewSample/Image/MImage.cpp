#include "StdAfx.h"
#include "MImage.h"
#include <stdio.h> 
#include <TCHAR.H>

/*!
	Constructor
    @return None
*/
CMImage::CMImage(void)
{
	m_nMemSize = 0;
	m_pImageFile = NULL;
	m_nFileSize = 0;
	m_eType = IMGM_TYPE_NONE;
	m_bDecRequest = FALSE;
}

/*!
	Destructor
    @return None
*/
CMImage::~CMImage(void)
{
	if(m_pImageFile != NULL) delete [] m_pImageFile;
}

/*!
   Set the image data
    @param[in] pData   : image data
    @param[in] nSize   : data size
    @param[in] nWidth  : width of the image
    @param[in] nHeight : height of the image
    @param[in] eType   : Image format(IMGM_TYPE_GRAY,IMGM_TYPE_JPEG,IMGM_TYPE_BMP)
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CMImage::SetMemImage(BYTE *pData,int nSize,int nWidth,int nHeight,MITYPE eType)
{
	int nFileSize;

	if(pData == NULL || nSize <= 0 || eType == IMGM_TYPE_NONE) {
		ClearImage();
		return FALSE;
	}

	if(eType == IMGM_TYPE_GRAY) {
		nFileSize = (((nWidth + 3) / 4) * 4 * nHeight) + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD)*256;
	}
	else {
		nFileSize = nSize;
	}

	if(nFileSize > m_nMemSize) {
		m_nMemSize = nFileSize + 256;
		m_nFileSize = 0;
		if(m_pImageFile != NULL) delete [] m_pImageFile;
		m_pImageFile  = new BYTE [m_nMemSize];
		if(m_pImageFile == NULL) {
			m_nMemSize = 0;
			return FALSE;
		}
	}

	if(eType == IMGM_TYPE_GRAY) {
		m_nFileSize = Make256GrayBitmap(m_pImageFile,m_nMemSize,nWidth,nHeight,pData);
		eType = IMGM_TYPE_BMP;
	}
	else {
		memcpy(m_pImageFile,pData,nSize);
		m_nFileSize = nSize;
	}
	m_eType = eType;

	m_bDecRequest = TRUE;

	return TRUE;
}

/*!
   Save the image data
    @param[in] lpczFileName : file name
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CMImage::SaveMemImage(LPCTSTR lpczFileName)
{
	if(m_nFileSize == 0) return FALSE;

	FILE *fp = NULL;
	int nWSz;
#if defined(_tfopen_s)
	errno_t tErr = _tfopen_s(&fp ,lpczFileName, _T("wb"));
	if(tErr != 0) return FALSE;
#else
	fp = _tfopen(lpczFileName, _T("wb"));
#endif
	if(fp != NULL) {
		nWSz = (int)fwrite(m_pImageFile,1,m_nFileSize,fp);
		fclose(fp);
	}

	return (nWSz == m_nFileSize);
}

/*!
   Clear the image
    @return None
*/
void CMImage::ClearBufferImage(void)
{
	m_bDecRequest = FALSE;
	CDcBuffer::ClearBufferImage();
}

/*!
   Clear the data
    @return None
*/
void CMImage::ClearImage(void)
{
	Destroy();
	m_nFileSize=0;
	m_bDecRequest=FALSE;
}

/*!
   Get the handle of the device context
    @return device context
*/
HDC CMImage::GethDC(void)
{
	Decode();
	return m_hDc;
}

/*!
   Decode
    @return None
*/
void CMImage::Decode(void)
{
	if(m_bDecRequest == TRUE) {
		if(m_pImageFile != NULL && m_nFileSize > 0) {
			DecodeImage(m_pImageFile,m_nFileSize);
		}
		m_bDecRequest = FALSE;
	}
}

/*!
   Create the bitmap data from 256 gray image
    @param[in] pDstBuf  : gray image data
    @param[in] nDstSize : the size
    @param[in] nWidth   : the width
    @param[in] nHeight  : the height
    @param[in] pSrcBuf  : the image buffer
    @return	Bitmap size
*/
int CMImage::Make256GrayBitmap(BYTE *pDstBuf,int nDstSize,int nWidth,int nHeight,BYTE *pSrcBuf)
{
	int i;
	int nWidth4,nFileSize,nHeadersSize,nDataSize;
	BYTE				*pFileImage;
	BITMAPFILEHEADER	*pFileHeader;
	BITMAPINFOHEADER	*pInfoHeader;
	RGBQUAD				*pRGBQuad;
	BYTE				*pData;

	nHeadersSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + sizeof(RGBQUAD)*256;
	nWidth4 = ((nWidth+3)/4)*4;
	nDataSize = nWidth4 * nHeight;
	nFileSize = nHeadersSize + nDataSize;

	if(nFileSize > nDstSize) return 0;
	pFileImage = pDstBuf;
	memset(pFileImage,0,nFileSize);

	pFileHeader = (BITMAPFILEHEADER *)pFileImage;
	pInfoHeader = (BITMAPINFOHEADER *)(pFileImage+sizeof(BITMAPFILEHEADER));
	pRGBQuad = (RGBQUAD *)(pFileImage+sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER));
	pData = pFileImage + nHeadersSize;

	pFileHeader->bfType =*((WORD*)"BM");
	pFileHeader->bfSize = nFileSize;
	pFileHeader->bfOffBits = nHeadersSize;

	pInfoHeader->biSize = sizeof(BITMAPINFOHEADER);
	pInfoHeader->biWidth = nWidth;
	pInfoHeader->biHeight = nHeight;
	pInfoHeader->biPlanes = 1;
	pInfoHeader->biBitCount = 8;
	pInfoHeader->biCompression = BI_RGB;
	pInfoHeader->biSizeImage = nDataSize;

	for(i=0;i<256;i++) {
		pRGBQuad[i].rgbBlue = i;
		pRGBQuad[i].rgbGreen = i;
		pRGBQuad[i].rgbRed = i;
	}

	BYTE *pSrc,*pDst;
	pSrc = pSrcBuf;
	pDst = pData + (nWidth4 * (nHeight - 1));
	for(i=0;i<nHeight;i++) {
		memcpy(pDst,pSrc,nWidth);
		pSrc += nWidth;
		pDst -= nWidth4;
	}

	return nFileSize;
}

#if defined(UNDER_CE)
#include "Imaging.h"
#include "initguid.h"
#include "imgguids.h"
/*!
   Decode the image data to device context
    @param[in] pDstBu f : image data
    @param[in] nDstSize : image size
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CMImage::DecodeImage(BYTE *pDstBuf,int nDstSize)
{
	IImage*				pImage	 = NULL;
	HRESULT				result	 = S_OK;
	HRESULT				hrCoInit = S_OK;
	ImageInfo			iiImgInfo;
	IImagingFactory*	pFactory = NULL;

//	hrCoInit = ::CoInitializeEx( NULL, COINIT_MULTITHREADED );
	hrCoInit = ::CoInitializeEx( NULL, COINIT_APARTMENTTHREADED );

	result = ::CoCreateInstance( CLSID_ImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_IImagingFactory, reinterpret_cast<LPVOID*>( &pFactory ) );
	if ( FAILED( result ) ) {
		if( SUCCEEDED( hrCoInit ) ) ::CoUninitialize();
		return FALSE;
	}

	result = pFactory->CreateImageFromBuffer(pDstBuf,nDstSize,BufferDisposalFlagNone,&pImage);
	if ( FAILED( result ) ) {
		pFactory->Release();
		if( SUCCEEDED( hrCoInit ) ) ::CoUninitialize();
		return FALSE;
	}

	result = pImage->GetImageInfo( &iiImgInfo );
	if ( FAILED( result ) ) {
		pImage->Release();
		pFactory->Release();
		if( SUCCEEDED( hrCoInit ) ) ::CoUninitialize();
		return FALSE;
	}
#if 0
	IBitmapImage* pBitmap= NULL;
	//pFactory->CreateBitmapFromImage(pImage, 0, 0, PixelFormatDontCare, InterpolationHintDefault, &pBitmap);
	pFactory->CreateBitmapFromImage(pImage, 0, 0, PixelFormatDontCare, InterpolationHintDefault, &pBitmap);
	pImage->Release();
	if(pBitmap == NULL) {
		pFactory->Release();
		if( SUCCEEDED( hrCoInit ) ) ::CoUninitialize();
		return FALSE;
	}
	BitmapData bitmapData;
	//pBitmap->LockBits(NULL, ImageLockModeRead, iiImgInfo.PixelFormat, &bitmapData);
	pBitmap->LockBits(NULL, ImageLockModeRead, PixelFormat24bppRGB, &bitmapData);
	if ( bitmapData.Stride < 0 ) bitmapData.Stride *= -1;

	HBITMAP hBitmap;
	hBitmap = ::CreateBitmap(bitmapData.Width, bitmapData.Height, 1, (bitmapData.Stride/bitmapData.Width)*8, bitmapData.Scan0);

	pBitmap->UnlockBits(&bitmapData);

	pBitmap->Release();
	pFactory->Release();

	if( SUCCEEDED( hrCoInit ) ) ::CoUninitialize();

	SetSize(bitmapData.Width,bitmapData.Height,FALSE);
	HDC hdc = ::CreateCompatibleDC(m_hDc);
	HBITMAP hOld = (HBITMAP)::SelectObject(hdc,hBitmap);
	::BitBlt(m_hDc,0,0,bitmapData.Width,bitmapData.Height,hdc,0,0,SRCCOPY);
	::SelectObject(hdc,hOld);
	::DeleteObject(hBitmap);
	::DeleteDC(hdc);
#else
	SetSize(iiImgInfo.Width,iiImgInfo.Height,FALSE);

	RECT tRc = {0,0,iiImgInfo.Width,iiImgInfo.Height};
	result = pImage->Draw(m_hDc,&tRc,NULL);

	pImage->Release();
	pFactory->Release();

	if( SUCCEEDED( hrCoInit ) ) ::CoUninitialize();

	if ( FAILED( result ) ) {
		return FALSE;
	}
#endif
	return TRUE;
}
#else
#include <atlimage.h>
/*!
   Decode the image data to device context
    @param[in] pDstBu f : image data
    @param[in] nDstSize : image size
    @return	BOOL TRUE:Success	FALSE:Fail
*/
BOOL CMImage::DecodeImage(BYTE *pDstBuf,int nDstSize)
{
	CImage cImg;

	BYTE *pImageFile;
	IStream *pIStream;
	HGLOBAL hImageFile;
	HRESULT hr;
	hImageFile = (HGLOBAL)GlobalAlloc(GMEM_MOVEABLE, nDstSize);
	pImageFile = (BYTE *)GlobalLock(hImageFile);
	memcpy(pImageFile,pDstBuf,nDstSize);
	::GlobalUnlock(hImageFile);
	hr = ::CreateStreamOnHGlobal(hImageFile,TRUE,&pIStream);

	if(FAILED(hr)) {
		::GlobalFree(hImageFile);
		return FALSE;
	}

	try{
		hr = cImg.Load(pIStream);
		if(FAILED(hr)) {
			pIStream->Release();
			return FALSE;
		}
	}
	catch(...) {
		pIStream->Release();
		return FALSE;
	}

	pIStream->Release();

	SetSize(cImg.GetWidth(),cImg.GetHeight(),FALSE);

	cImg.BitBlt(m_hDc,0,0);
	return TRUE;
}
#endif
