#include "stdafx.h"
#include "DcBuffer.h"

/*!
	Constructor
    @return None
*/
CDcBuffer::CDcBuffer(void)
{
	m_hWnd = NULL;
	m_hBitmap = NULL;
	m_nWidth = -1;
	m_nHeight = -1;
	m_hDc = NULL;
	m_hBackPen = ::CreatePen(PS_SOLID,1,BACK_COLOR);
	m_hBackBrush = CreateSolidBrush(BACK_COLOR);
}

/*!
	Destructor
    @return None
*/
CDcBuffer::~CDcBuffer(void)
{
	Destroy();
	if(m_hBackPen != NULL) {
		::DeleteObject(m_hBackPen);
		m_hBackPen = NULL;
	}
	if(m_hBackBrush != NULL) {
		::DeleteObject(m_hBackBrush);
		m_hBackBrush = NULL;
	}
}

/*!
   Set the size of image buffer
    @param[in] nWidth  : width of the image
    @param[in] nHeight : height of the image
    @param[in] bClear  : clear if created
    @return None
*/
void CDcBuffer::SetSize(int nWidth, int nHeight, BOOL bClear)
{
	if(nWidth <= 0 || nHeight <= 0) return;
	if(m_hDc != NULL && (m_nWidth != nWidth || m_nHeight != nHeight)) {
		Destroy();
	}
	if(m_hDc == NULL) {
		HDC hdc = ::GetDC(m_hWnd);
		m_hDc = ::CreateCompatibleDC(hdc);
		if(m_hDc == NULL) {
			::ReleaseDC(m_hWnd,hdc);
			return;
		}
#if defined(UNDER_CE)
		::SetStretchBltMode(m_hDc,COLORONCOLOR);
#else
		::SetStretchBltMode(m_hDc,HALFTONE);
#endif
#if 1
		BITMAPINFO tBmpInfo;
		ZeroMemory(&tBmpInfo, sizeof(BITMAPINFO));
		tBmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		tBmpInfo.bmiHeader.biWidth = nWidth;
		tBmpInfo.bmiHeader.biHeight = nHeight;
		tBmpInfo.bmiHeader.biPlanes = 1;
		tBmpInfo.bmiHeader.biBitCount = GetDeviceCaps(hdc,BITSPIXEL);
		tBmpInfo.bmiHeader.biCompression = BI_RGB;
		m_hBitmap = ::CreateDIBSection( hdc, &tBmpInfo, DIB_RGB_COLORS, NULL, NULL, NULL);
		if(m_hBitmap == NULL) {
			TRACE(_T("CreateDIBSection Error %d\n"),GetLastError());
			::ReleaseDC(m_hWnd,hdc);
			return;
		}
#else
		m_hBitmap = CreateCompatibleBitmap(hdc, nWidth, nHeight);
		if(m_hBitmap == NULL) {
			TRACE(_T("CreateCompatibleBitmap Error %d\n"),GetLastError());
			return;
		}
#endif
		::SelectObject(m_hDc , m_hBitmap);
		::ReleaseDC(m_hWnd,hdc);

		m_nWidth = nWidth;
		m_nHeight = nHeight;
		if(bClear) ClearBufferImage();
	}
}

/*!
   Transfer image from the image buffer class
    @param[in] cImgBuf : sourc of the image
    @return ����
*/
void CDcBuffer::SetBufferImage(CDcBuffer &cImgBuf)
{
	if(m_hDc == NULL) return;

	if(cImgBuf.GethDC() != NULL) {
		if(cImgBuf.GetWidth() == m_nWidth && cImgBuf.GetHeight() == m_nHeight) {
			::BitBlt(m_hDc, 0, 0, m_nWidth, m_nHeight,
				cImgBuf.GethDC(), 0, 0, SRCCOPY);
		}
		else {
			::StretchBlt(m_hDc, 0, 0, m_nWidth, m_nHeight,
				cImgBuf.GethDC() , 0, 0, cImgBuf.GetWidth(), cImgBuf.GetHeight(), SRCCOPY);
		}
	}
	else {
		ClearBufferImage();
	}
}

/*!
   Clear image
    @return None
*/
void CDcBuffer::ClearBufferImage(void)
{
	if(m_nWidth <= 0 || m_nHeight <= 0) return;
	if(m_hDc == NULL) return;

	HPEN hOldPen = (HPEN)::SelectObject(m_hDc,m_hBackPen);
	HBRUSH hOldBrush = (HBRUSH)::SelectObject(m_hDc,m_hBackBrush);
	::Rectangle(m_hDc,0,0,m_nWidth-1,m_nHeight-1);
	::SelectObject(m_hDc,hOldPen);
	::SelectObject(m_hDc,hOldBrush);
}

/*!
   Set the background color
    @param[in] colBak : background color
    @return None
*/
void CDcBuffer::SetBackColor(COLORREF colBak)
{
	if(m_hBackPen != NULL) {
		::DeleteObject(m_hBackPen);
		m_hBackPen = NULL;
	}
	m_hBackPen = ::CreatePen(PS_SOLID,1,colBak);

	if(m_hBackBrush != NULL) {
		::DeleteObject(m_hBackBrush);
		m_hBackBrush = NULL;
	}
	m_hBackBrush = CreateSolidBrush(colBak);
}

/*!
   Destory image
    @return None
*/
void CDcBuffer::Destroy(void)
{
	if(m_hDc != NULL) {
		::DeleteDC(m_hDc);
		m_hDc = NULL;
		if(m_hBitmap != NULL) {
			::DeleteObject(m_hBitmap);
			m_hBitmap = NULL;
		}
	}
}
