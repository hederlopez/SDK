#pragma once
#include "MImage.h"

class CFrameImage : public CMImage
{
public:
	CFrameImage(void) {m_nImageX = m_nImageY = m_nFrameWidth = m_nFrameHeight = 0;}
	~CFrameImage(void) {}

	void SetFrame(int x,int y,int w,int h)
	{
		m_nImageX = x;
		m_nImageY = y;
		m_nFrameWidth = w;
		m_nFrameHeight = h;
	}

	virtual void ClearImage(void)
	{
		m_nImageX = m_nImageY = m_nFrameWidth = m_nFrameHeight = 0;
		CMImage::ClearImage();
	}

	int GetFrameWidth(void){return m_nFrameWidth;}
	int GetFrameHeight(void){return m_nFrameHeight;}
	int GetPosX(void){return m_nImageX;}
	int GetPosY(void){return m_nImageY;}

protected:
	int		m_nImageX;
	int		m_nImageY;
	int		m_nFrameWidth;
	int		m_nFrameHeight;
};
