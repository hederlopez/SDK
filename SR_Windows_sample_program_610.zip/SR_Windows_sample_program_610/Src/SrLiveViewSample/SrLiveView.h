#pragma once
#include "LiveView/LiveCtrl.h"
#include "LiveView/LiveTcpCtrl.h"
#include "LiveData/LiveImage.h"
#include "LiveData/LiveInfo.h"
#include "UdpCtrl/UdpCtrl.h"
#include "UdpCtrl/MonUdpCtrl.h"

#define	CHECK_CMD				"READER2\r"			//!< Command for detection of readers
#define	CHECK_CMD_LEN			(sizeof(CHECK_CMD)-1)
#define	CHECK_RESULT			"OK,READER2,"
#define	CHECK_RES_LEN			(sizeof(CHECK_RESULT)-1)
#define	LV_MAX_TYPELEN			16

#define	WM_LIVELIEW				(WM_USER+0x2000)	//!< LiveView message
#define	WM_DEVICEON				(WM_LIVELIEW+1)		//!< Device discovery message

#define	TM_TRYDEVCHECK			(1+0x2000)			//!< Target detection check timer
#define	TM_PULLIMAGE			(2+0x2000)			//!< Image transmission request delay timer

#define TIME_CHECK_DEVICE		3000				//!< Target detection check period
#define TIME_PULL_WAIT			(1000/30)			//!< Image transmission request delay time
#define TIME_PULL_TIMEOUT		200					//!< Image transmission request retransmission time

#define	SR750_IMG_WIDTH			752
#define	SR750_IMG_HEIGHT		480
#define	SR750_IMG_BINNING_MAX	4
#define	SR1000_IMG_WIDTH		1280
#define	SR1000_IMG_HEIGHT		1024
#define	SR1000_IMG_BINNING_MAX	4
#define	SR2000_IMG_WIDTH		2048
#define	SR2000_IMG_HEIGHT		1536
#define	SR2000_IMG_BINNING_MAX	4
#define IMG_BINNING_DEVNONE		0
#define IMG_BINNING_DEV2		1
#define IMG_BINNING_DEV3		2
#define IMG_BINNING_DEV4		3

#define	MAX_LVIEW				4					//!< Maximum number of connections

class CSrLiveView;

//!< LiveView management structure
typedef struct _LVIEW
{
	BOOL			bUse;			//!< In use flag
	HWND			hWnd;			//!< Drawing window handle
	unsigned long	ulAddr;			//!< Destination address
	FARPROC			fncOrgWnd;		//!< Procedure of drawing window
	CLiveCtrl		*pLiveCtrl;		//!< LiveView control
	CLiveInfo		*pLiveInfo;		//!< Reading information
	CLiveImage		*pLiveImage;	//!< Image data
	CDcBuffer		*pPaintBuffer;	//!< Drawing buffer
	CUdpCtrl		*pUdpCtrl;		//!< UDP control
	LPCRITICAL_SECTION pCSLock;		//!< Registry/Destroy exclusive lock
	char			szType[LV_MAX_TYPELEN];	//!< Model name
} LVIEW;


//!< LiveView management class
class CSrLiveView
{
public:
	CSrLiveView(void);
	~CSrLiveView(void);

	int CreateLiveView(HWND hWnd, unsigned long ulAddr);
	BOOL ReleaseLiveView(int nId);

	int GetLviewId(HWND hWnd);
	int GetLviewId(unsigned long ulAddr);
	int GetLviewEmptyId(void);

	void OnDeviceChange(HWND hWnd, WPARAM wParam, LPARAM lParam);
	void OnLiveView(HWND hWnd, WPARAM wParam, LPARAM lParam);
	void OnPaint(HWND hWnd, WPARAM wParam, LPARAM lParam);
	void OnTimer(HWND hWnd, WPARAM wParam, LPARAM lParam);
	void OnSize(HWND hWnd, WPARAM wParam, LPARAM lParam);

	FARPROC GetfncOrgWnd(int i) {return m_LView[i].fncOrgWnd;}

	void Lock(void) {EnterCriticalSection(&m_tCSLock);}
	void Unlock(void) {LeaveCriticalSection(&m_tCSLock);}

public:
     static CSrLiveView* getInstance(void){if( !s_pInstance ) s_pInstance = new CSrLiveView();return s_pInstance;}
     static void deleteInstance(void){if( s_pInstance ) delete s_pInstance;	s_pInstance = NULL;}

private:
     static  CSrLiveView*  s_pInstance;

protected:
	static void CALLBACK UdpCallBack(LPVOID lpParam, struct sockaddr_in *pAddr, BYTE *lpData, DWORD dwSize);
	static void CALLBACK  LiveCallBack(LPVOID lpParam, LPVOID lpData, CBST eEvent);
	static LRESULT CALLBACK SubProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

	CRITICAL_SECTION m_tCSLock;

	LVIEW		m_LView[MAX_LVIEW];
	int			m_nLView;

	CMonUdpCtrl	*m_pMontor;
};
