function readformatEvent()					
							--�ǂݎ�茋��(OK/NG/ERROR)�ɉ����ĕ���
	local r_data = result()
	local data = readResult():readData()

	if r_data == 0 then		--OK
		return "OK:"..data
	elseif r_data == 1 then	--�ƍ�NG
		return "NG:"..data
	elseif r_data == 2 then	--READ ERROR
		return "ERROR:"..data
	end
	
	return "result has no return"
	
end