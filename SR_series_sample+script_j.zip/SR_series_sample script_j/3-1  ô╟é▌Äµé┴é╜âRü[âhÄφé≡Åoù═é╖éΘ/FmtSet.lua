function readformatEvent()
	local data = readResult():symbolType()		--�R�[�h����i�[
	if data == 1 then							--�R�[�h�했�ɏ�������
		return "QR"
	elseif data == 2 then
		return "DataMatrix"
	elseif data == 5 then
		return "GS1 DataBar"
	elseif data == 6 then
		return "CODE39"
	elseif data == 7 then
		return "ITF"
	elseif data == 9 then
		return "Codabar"
	elseif data == 10 then
		return "JAN/EAN/UPC"
	elseif data == 11 then
		return "CODE128"
	elseif data == 0 then
		return "no data"
	end

	return "other"
end

