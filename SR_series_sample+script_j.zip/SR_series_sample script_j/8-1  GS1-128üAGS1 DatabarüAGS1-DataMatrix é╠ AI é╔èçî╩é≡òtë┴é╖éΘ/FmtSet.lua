-- GS1 AI���ʎq����
--  g_mode
--   0: AI���ʎq�Ɋ��ʂ����ďo��
--   1: �f�[�^���݂̂��o��
--   2: FNC1������u��
local g_mode = 0

local SEPARATOR = ","	-- �f�[�^���̂ݏo�͎��̋�؂蕶��

local FNC1_CHAR = ":" -- FNC1�u������

-- �R�[�h��ԍ�
local GS1_QR = 1
local GS1_DM = 2
local GS1_DATA_BAR = 5
local GS1_128 = 11

local GS_CHAR = "\29"

function readformatEvent()
	local data = readResult():readData()
	local id_pos = {}
	local id_len = {}
	local id_len2 = {}
	local body_len = {}
	local id_num = 1
	local start_pos = 0
	local next_pos

	-- �R�[�h��`�F�b�N
	code = readResult():symbolType()
	while true do
		if (code == GS1_QR) then
			break;
		end
		if (code == GS1_DM) then
			break;
		end
		if (code == GS1_DATA_BAR) then
			break;
		end
		if (code == GS1_128) then
			break;
		end
		return data	-- �ΏۊO�R�[�h
	end

	-- AI���ʎq�̉��
	while true do
		id_len[id_num], id_len2[id_num], body_len[id_num], next_pos = getAI(data, start_pos)
		if (next_pos == nil) then
			break
		end
		id_pos[id_num] = start_pos
		id_num = id_num + 1
		start_pos = next_pos
	end

	if (id_num == 1) then -- AI���ʎq������
		return data
	end

	local pos
	local result_data = {}
	local j
	if (g_mode == 0) then -- AI���ʎq�Ɋ��ʂ�����
		for i = 1, id_num - 1, 1 do
			j = (i - 1) * 4
			pos = id_pos[i] + 1
			result_data[j + 1] = "("
			result_data[j + 2] = mid(data, pos, id_len2[i])
			result_data[j + 3] = ")"
			pos = pos + id_len2[i]
			result_data[j + 4] = mid(data, pos, body_len[i])
		end
	elseif (g_mode == 1) then -- �f�[�^���̂ݏo��
		for i = 1, id_num - 1, 1 do
			j = (i - 1) * 2
			pos = id_pos[i] + 1 + id_len2[i]
			result_data[j + 1] = mid(data, pos, body_len[i])
			if (i ~= id_num - 1) then
				result_data[j + 2] = SEPARATOR
			end
		end
	else -- FNC1��u��
		for i = 1, id_num - 1, 1 do
			j = (i - 1) * 3
			pos = id_pos[i] + 1
			result_data[j + 1] = mid(data, pos, id_len2[i])
			pos = pos + id_len2[i]
			result_data[j + 2] = mid(data, pos, body_len[i])
			if (i ~= id_num - 1) then
				result_data[j + 3] = FNC1_CHAR
			end
		end
	end

	return table.concat(result_data)
end

function getAI(data, start_pos)
	local gs_pos
	local gs_pos2
	local id
	local id_len
	local id_len2
	local data_len
	local data_len2
	local next_pos
	local body_len

	-- GS�ʒu���o
	gs_pos, gs_pos2 = string.find(data, GS_CHAR, start_pos+1)
	if (gs_pos == nil) then
		gs_pos = string.len(data)
	else
		gs_pos = gs_pos - 1
	end

	-- ID����
	id = 0
	while true do
		local i   = id * 5
		local ai  = ai_info[i + 1]
		id_len    = ai_info[i + 2]
		id_len2   = ai_info[i + 3]
		data_len  = ai_info[i + 4]
		data_len2 = ai_info[i + 5]

		if (ai == 0) then
			return nil,nil,nil,nil
		end
		if (ai == mid(data, start_pos+1, id_len)) then
			break
		end
		id = id + 1
	end

	local gs_len = gs_pos - (start_pos + id_len2)

	if (data_len2 == -1) then -- �Œ蒷�̂�
		if (data_len > gs_len) then -- GS���Œ蒷�����Ɋ܂܂�鎞
			return nil,nil,nil,nil
		end
		body_len = data_len
		next_pos = start_pos + id_len2 + data_len
		if (data_len == gs_len) then -- �Œ蒷+GS
			next_pos  = next_pos + 1
		end
	elseif (data_len == -1) and (data_len2 > 0) then -- �ϒ�
		if (data_len2 < gs_len) then -- GS���ϒ��ő�T�C�Y�܂łɊ܂܂�Ȃ���
			return nil,nil,nil,nil
		end
		body_len = gs_len
		next_pos = gs_pos + 1
	elseif (data_len > 0) and (data_len2 > 0) then -- �Œ蒷+�ϒ�
		if (data_len > gs_len) then -- GS���Œ蒷�����Ɋ܂܂�鎞
			return nil,nil,nil,nil
		end
		if (data_len + data_len2 < gs_len) then -- GS���ϒ��ő�T�C�Y�܂łɊ܂܂�Ȃ���
			return nil,nil,nil,nil
		end
		body_len = gs_len
		next_pos = gs_pos + 1
	else -- �ϒ�������(�S�̂ł͌Œ蒷)
		if (data_len ~= gs_len) then
			return nil,nil,nil,nil
		end
		body_len = gs_len
		next_pos = gs_pos + 1
	end

	return id_len, id_len2, body_len, next_pos
end

ai_info = {
--------------------------------------------------------------------------------------------
--	AI		AI����		AI����		�Œ蒷		�ϒ�
--			size		size		size		�ő�size
--------------------------------------------------------------------------------------------
	"00",		2,		2,		18,		-1,	-- n2+n18
	"01",		2,		2,		14,		-1,	-- n2+n14
	"02",		2,		2,		14,		-1,	-- n2+n14
	"10",		2,		2,		-1,		20,	-- (n2+an...20)
	"11",		2,		2,		6,		-1,	-- n2+n6
	"12",		2,		2,		6,		-1,	-- n2+n6
	"13",		2,		2,		6,		-1,	-- n2+n6
	"15",		2,		2,		6,		-1,	-- n2+n6
	"17",		2,		2,		6,		-1,	-- n2+n6
	"20",		2,		2,		2,		-1,	-- n2+n2
	"21",		2,		2,		-1,		20,	-- (n2+an...20)
	"22",		2,		2,		-1,		29,	-- (n2+an...29)
	"240",		3,		3,		-1,		30,	-- (n3+an...30)
	"241",		3,		3,		-1,		30,	-- (n3+an...30)
	"242",		3,		3,		-1,		6,	-- (n3+n...6)
	"250",		3,		3,		-1,		30,	-- (n3+ an...30)
	"251",		3,		3,		-1,		30,	-- (n3+ an...30)
	"253",		3,		3,		13,		17,	-- (n3+n13+n...17)
	"254",		3,		3,		-1,		20,	-- (n3+an...20)
	"30",		2,		2,		-1,		8,	-- (n2+n...8)
	"310",		3,		4,		6,		-1,	-- n4+n6
	"311",		3,		4,		6,		-1,	-- n4+n6
	"312",		3,		4,		6,		-1,	-- n4+n6
	"313",		3,		4,		6,		-1,	-- n4+n6
	"314",		3,		4,		6,		-1,	-- n4+n6
	"315",		3,		4,		6,		-1,	-- n4+n6
	"316",		3,		4,		6,		-1,	-- n4+n6
	"320",		3,		4,		6,		-1,	-- n4+n6
	"321",		3,		4,		6,		-1,	-- n4+n6
	"322",		3,		4,		6,		-1,	-- n4+n6
	"323",		3,		4,		6,		-1,	-- n4+n6
	"324",		3,		4,		6,		-1,	-- n4+n6
	"325",		3,		4,		6,		-1,	-- n4+n6
	"326",		3,		4,		6,		-1,	-- n4+n6
	"327",		3,		4,		6,		-1,	-- n4+n6
	"328",		3,		4,		6,		-1,	-- n4+n6
	"329",		3,		4,		6,		-1,	-- n4+n6
	"330",		3,		4,		6,		-1,	-- n4+n6
	"331",		3,		4,		6,		-1,	-- n4+n6
	"332",		3,		4,		6,		-1,	-- n4+n6
	"333",		3,		4,		6,		-1,	-- n4+n6
	"334",		3,		4,		6,		-1,	-- n4+n6
	"335",		3,		4,		6,		-1,	-- n4+n6
	"336",		3,		4,		6,		-1,	-- n4+n6
	"337",		3,		4,		6,		-1,	-- n4+n6
	"340",		3,		4,		6,		-1,	-- n4+n6
	"341",		3,		4,		6,		-1,	-- n4+n6
	"342",		3,		4,		6,		-1,	-- n4+n6
	"343",		3,		4,		6,		-1,	-- n4+n6
	"344",		3,		4,		6,		-1,	-- n4+n6
	"345",		3,		4,		6,		-1,	-- n4+n6
	"346",		3,		4,		6,		-1,	-- n4+n6
	"347",		3,		4,		6,		-1,	-- n4+n6
	"348",		3,		4,		6,		-1,	-- n4+n6
	"349",		3,		4,		6,		-1,	-- n4+n6
	"350",		3,		4,		6,		-1,	-- n4+n6
	"351",		3,		4,		6,		-1,	-- n4+n6
	"352",		3,		4,		6,		-1,	-- n4+n6
	"353",		3,		4,		6,		-1,	-- n4+n6
	"354",		3,		4,		6,		-1,	-- n4+n6
	"355",		3,		4,		6,		-1,	-- n4+n6
	"356",		3,		4,		6,		-1,	-- n4+n6
	"357",		3,		4,		6,		-1,	-- n4+n6
	"360",		3,		4,		6,		-1,	-- n4+n6
	"361",		3,		4,		6,		-1,	-- n4+n6
	"362",		3,		4,		6,		-1,	-- n4+n6
	"363",		3,		4,		6,		-1,	-- n4+n6
	"364",		3,		4,		6,		-1,	-- n4+n6
	"365",		3,		4,		6,		-1,	-- n4+n6
	"366",		3,		4,		6,		-1,	-- n4+n6
	"367",		3,		4,		6,		-1,	-- n4+n6
	"368",		3,		4,		6,		-1,	-- n4+n6
	"369",		3,		4,		6,		-1,	-- n4+n6
	"37",		2,		2,		-1,		8,	-- (n2+n...8)
	"390",		3,		4,		-1,		15,	-- (n4+n...15)
	"391",		3,		4,		3,		15,	-- (n4+n3+n...15)
	"392",		3,		4,		-1,		15,	-- (n4+n...15)
	"393",		3,		4,		3,		15,	-- (n4+n3+n...15)
	"400",		3,		3,		-1,		30,	-- (n3+an...30)
	"401",		3,		3,		-1,		30,	-- (n3+an...30)
	"402",		3,		3,		17,		0,	-- (n3+n17)
	"403",		3,		3,		-1,		30,	-- (n3+an...30)
	"410",		3,		3,		13,		-1,	-- n3+n13
	"411",		3,		3,		13,		-1,	-- n3+n13
	"412",		3,		3,		13,		-1,	-- n3+n13
	"413",		3,		3,		13,		-1,	-- n3+n13
	"414",		3,		3,		13,		-1,	-- n3+n13
	"415",		3,		3,		13,		-1,	-- n3+n13
	"420",		3,		3,		-1,		20,	-- (n3+an...20)
	"421",		3,		3,		3,		9,	-- (n3+n3+an...9)
	"422",		3,		3,		3,		0,	-- (n3+n3)
	"423",		3,		3,		3,		12,	-- (n3+n3+n...12)
	"424",		3,		3,		3,		0,	-- (n3+n3)
	"425",		3,		3,		3,		0,	-- (n3+n3)
	"426",		3,		3,		3,		0,	-- (n3+n3)
	"7001",		4,		4,		13,		0,	-- (n4+n13)
	"7002",		4,		4,		-1,		30,	-- (n4+an...30)
	"7003",		4,		4,		10,		0,	-- (n4+n10)
	"7004",		4,		4,		-1,		4,	-- (n4+n...4)
	"703",		3,		4,		3,		27,	-- (n4+n3+an...27)
	"8001",		4,		4,		14,		0,	-- (n4+n14)
	"8002",		4,		4,		-1,		20,	-- (n4+an...20)
	"8003",		4,		4,		14,		16,	-- (n4+n14+an...16)
	"8004",		4,		4,		-1,		30,	-- (n4+an...30)
	"8005",		4,		4,		6,		0,	-- (n4+n6)
	"8006",		4,		4,		18,		0,	-- (n4+n14+n2+n2)
	"8007",		4,		4,		-1,		30,	-- (n4+an...30)
	"8008",		4,		4,		8,		4,	-- (n4+n8+n...4)
	"8018",		4,		4,		18,		0,	-- (n4+n18)
	"8020",		4,		4,		-1,		25,	-- (n4+an...25)
	"8100",		4,		4,		6,		0,	-- (n4+n1+n5)
	"8101",		4,		4,		10,		0,	-- (n4+n1+n5+n4)
	"8102",		4,		4,		2,		0,	-- (n4+n1+n1)
	"8110",		4,		4,		-1,		30,	-- (n4+an..30)
	"8200",		4,		4,		-1,		70,	-- (n4+an..70)
	"90",		2,		2,		-1,		30,	-- (n2+an...30)
	"91",		2,		2,		-1,		30,	-- (n2+an...30)
	"92",		2,		2,		-1,		30,	-- (n2+an...30)
	"93",		2,		2,		-1,		30,	-- (n2+an...30)
	"94",		2,		2,		-1,		30,	-- (n2+an...30)
	"95",		2,		2,		-1,		30,	-- (n2+an...30)
	"96",		2,		2,		-1,		30,	-- (n2+an...30)
	"97",		2,		2,		-1,		30,	-- (n2+an...30)
	"98",		2,		2,		-1,		30,	-- (n2+an...30)
	"99",		2,		2,		-1,		30,	-- (n2+an...30)
	0,			0,		0,		0,		0
}
