local g_latestData = ""
function readformatEvent()
	local r_data = result()					--(OK/ERROR)�ɉ����ĕ���
	local readData = readResult():readData()	--�ǂݎ��f�[�^
	if r_data == 0 then						--OK
		if g_latestData == readData then
			return ""
		end
		g_latestData = readData
		outonEvent(1)
		return readData
	elseif r_data == 2 then					--ERROR
		outonEvent(2)
		return "ERROR"
	end
end